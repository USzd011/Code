"""
轻量神经记忆网络 — 每个神经元 = 一个记忆细胞
Spiking Neural Memory · 4核/3.6G 优化版
"""
import json
import time
import hashlib
import math
import os
from threading import Lock
from collections import defaultdict

# ============================================================
# 文本 → 神经元指纹（内容相似性哈希）
# ============================================================
class NeuralFingerprint:
    """MinHash 中文分词 + Jaccard 相似度"""
    def __init__(self, num_hashes=64):
        self.num_hashes = num_hashes

    def _tokenize(self, text):
        """简单中文分词：按字符+2-gram"""
        text = text.lower()
        chars = []
        for ch in text:
            if '\u4e00' <= ch <= '\u9fff' or ch.isalnum():
                chars.append(ch)

        tokens = set(chars)  # 单字特征
        for i in range(len(chars) - 1):
            tokens.add(chars[i] + chars[i + 1])  # 双字特征
        return tokens

    def fingerprint(self, text):
        tokens = self._tokenize(text)
        if not tokens:
            return [0] * self.num_hashes

        fp = []
        for i in range(self.num_hashes):
            seed = i * 2654435761 + 0x9E3779B9
            min_hash = 2 ** 64
            for token in tokens:
                h = hashlib.sha256((token + str(seed)).encode()).hexdigest()
                val = int(h[:16], 16)
                if val < min_hash:
                    min_hash = val
            fp.append(min_hash)
        return fp

    def similarity(self, fp1, fp2):
        if not fp1 or not fp2:
            return 0.0
        same = sum(1 for a, b in zip(fp1, fp2) if a == b)
        return same / len(fp1)

fingerprint_engine = NeuralFingerprint()


# ============================================================
# 神经元
# ============================================================
class Neuron:
    def __init__(self, content, category="general", threshold=0.65, decay_rate=0.08):
        self.id = hashlib.md5((content + str(time.time())).encode()).hexdigest()[:16]
        self.content = content
        self.category = category
        self.fingerprint = fingerprint_engine.fingerprint(content)

        # 电生理状态
        self.activation = 0.0       # 当前膜电位 0.0 ~ 1.0
        self.resting_potential = -0.1  # 静息电位
        self.threshold = 0.5           # 激发阈值（比0.65更灵敏）
        self.decay_rate = decay_rate # 电位衰减率
        self.last_fired = 0          # 上次激发时间戳
        self.fire_count = 0          # 激发总次数

        # 突触连接 {neuron_id: weight}
        self.synapses = {}

        # 元数据
        self.created_at = time.time()
        self.last_accessed = time.time()
        self.energy = 1.0  # 神经元能量（长期不用会衰减）

    def receive_signal(self, signal_strength):
        """接收突触信号，更新膜电位"""
        self.activation = min(1.0, self.activation + signal_strength)
        self.last_accessed = time.time()

    def step_decay(self):
        """时间步进：膜电位自然衰减"""
        elapsed = time.time() - self.last_accessed
        if elapsed > 60:
            decay = self.decay_rate * (elapsed / 60)
            self.activation = max(0.0, self.activation - decay)
            # 长期不用的神经元能量降低
            self.energy = max(0.1, self.energy - 0.01 * (elapsed / 3600))

    def should_fire(self):
        """检查是否达到激发阈值"""
        return self.activation >= self.threshold

    def fire(self):
        """激发：发放脉冲到连接的突触"""
        self.last_fired = time.time()
        self.fire_count += 1
        self.activation = 0.0  # 激发后重置（不应期）
        self.energy = min(1.0, self.energy + 0.05)  # 激发增强能量
        return self.synapses.items()  # 返回连接列表用于传播

    def to_dict(self):
        return {
            "id": self.id,
            "content": self.content[:200],
            "category": self.category,
            "fingerprint": self.fingerprint,
            "activation": round(self.activation, 3),
            "threshold": self.threshold,
            "fire_count": self.fire_count,
            "synapses": self.synapses,
            "energy": round(self.energy, 3),
            "created_at": self.created_at,
        }


# ============================================================
# 神经记忆网络
# ============================================================
class NeuralMemory:
    def __init__(self, data_path="data/neural_memory.json"):
        self.data_path = data_path
        self.lock = Lock()
        self.neurons = {}     # {id: Neuron}
        self.activation_q = [] # 当前激活扩散队列
        self.iteration = 0
        self.total_fires = 0

        # 学习参数
        self.hebbian_lr = 0.15   # 赫布学习率
        self.ltd_rate = 0.02     # 长期抑制率
        self.max_synapses = 20   # 单个神经元最大突触数
        self.min_similarity = 0.03  # 新记忆与已有神经元建连最低相似度
        self.category_bonus = 0.08  # 同类别神经元额外连接权重

        os.makedirs(os.path.dirname(data_path) or '.', exist_ok=True)
        self._load()

    # ----- 核心操作 -----

    def add_memory(self, content, category="general"):
        """存入一个新记忆 → 创建一个新的神经元"""
        with self.lock:
            neuron = Neuron(content, category)
            self.neurons[neuron.id] = neuron

            # 查找相似神经元建立初始突触连接
            self._initialize_synapses(neuron)

            # 新神经元自动激发一次（短时记忆强化）
            neuron.activation = neuron.threshold * 0.9
            self.iteration += 1

            return neuron.id

    def _text_match(self, query, content):
        """文本级联匹配：精确匹配 → 字符包含 → 关键词共现"""
        q = query.lower()
        c = content.lower()
        # 精确匹配
        if q in c:
            return 0.8
        # 查询中的每个字是否都出现在内容中
        q_chars = set(ch for ch in q if '\u4e00' <= ch <= '\u9fff')
        if q_chars:
            c_chars = set(ch for ch in c if '\u4e00' <= ch <= '\u9fff')
            overlap = len(q_chars & c_chars) / len(q_chars)
            if overlap >= 0.8:
                return 0.4 * overlap
        return 0.0

    def retrieve(self, query, top_k=5):
        """检索记忆 → 激活扩散 + 相似度排序"""
        with self.lock:
            q_fp = fingerprint_engine.fingerprint(query)

            # Step 1: 候选神经元（指纹相似度 + 文本匹配双重召回）
            candidates = []
            seen_ids = set()
            for n in self.neurons.values():
                sim = fingerprint_engine.similarity(q_fp, n.fingerprint)
                txt = self._text_match(query, n.content)
                score = max(sim, txt)
                if score > 0.01:
                    candidates.append((n.id, score))
                    seen_ids.add(n.id)

            # 无指纹匹配时：全文扫描
            if not candidates:
                for n in self.neurons.values():
                    if any(kw in n.content for kw in query.split()):
                        candidates.append((n.id, 0.1))

            if not candidates:
                return []

            candidates.sort(key=lambda x: -x[1])

            # Step 2: 激活种子神经元
            seed_ids = []
            for nid, score in candidates[:5]:
                if nid in self.neurons:
                    # 按匹配强度比例激活
                    self.neurons[nid].activation = min(1.0, score * 1.2 + 0.1)
                    seed_ids.append(nid)

            # Step 3: 激活扩散
            activated = self._spread_activation(
                seed_ids=seed_ids[:3],
                max_depth=4
            )

            # Step 4: 综合评分
            results = []
            seed_set = set(c[0] for c in candidates[:5])
            for nid in activated:
                n = self.neurons.get(nid)
                if not n:
                    continue
                sim_score = max(
                    fingerprint_engine.similarity(q_fp, n.fingerprint),
                    self._text_match(query, n.content)
                )
                act_score = min(1.0, n.activation)
                fire_boost = min(0.5, n.fire_count * 0.02)
                association = sim_score * 0.4 + act_score * 0.4 + fire_boost * 0.2
                results.append({
                    "id": n.id,
                    "content": n.content,
                    "category": n.category,
                    "score": round(association, 3),
                    "activation": round(n.activation, 3),
                    "fires": n.fire_count,
                    "is_seed": nid in seed_set,
                })

            results.sort(key=lambda x: -x["score"])
            return results[:top_k]

    def think(self, seed_query):
        """主动思考：从种子查询开始激活扩散，返回激活神经元链"""
        with self.lock:
            q_fp = fingerprint_engine.fingerprint(seed_query)
            candidates = []
            for n in self.neurons.values():
                sim = fingerprint_engine.similarity(q_fp, n.fingerprint)
                txt = self._text_match(seed_query, n.content)
                score = max(sim, txt)
                if score > 0.01:
                    candidates.append((n.id, score))
                    self.neurons[n.id].activation = min(1.0, score * 2.0 + 0.2)

            if not candidates:
                return []

            candidates.sort(key=lambda x: -x[1])

            # 深度激活扩散（思考深度更大）
            activated_chain = self._spread_activation(
                seed_ids=[cid for cid, _ in candidates[:3]],
                max_depth=5
            )

            # 记录这次思考
            self.iteration += 1

            # 返回思考链
            chain = []
            for nid in activated_chain:
                n = self.neurons.get(nid)
                if n and n.activation > 0.01:
                    chain.append({
                        "id": n.id,
                        "content": n.content[:100],
                        "category": n.category,
                        "activation": round(n.activation, 3),
                    })
            return chain

    def learn(self, content, category="general"):
        """学习新内容 → 创建神经元 + 赫布强化"""
        nid = self.add_memory(content, category)

        # 学习：强化新神经元与已连接神经元的突触
        with self.lock:
            n = self.neurons.get(nid)
            if n and n.synapses:
                for connected_id in n.synapses:
                    self._hebbian_learn(n.id, connected_id)

        return nid

    def stats(self):
        """网络统计"""
        with self.lock:
            total = len(self.neurons)
            active = sum(1 for n in self.neurons.values() if n.activation > 0.1)
            total_synapses = sum(len(n.synapses) for n in self.neurons.values())
            avg_synapses = total_synapses / max(1, total)
            high_energy = sum(1 for n in self.neurons.values() if n.energy > 0.7)
            return {
                "neurons": total,
                "active_neurons": active,
                "total_synapses": total_synapses,
                "avg_synapses": round(avg_synapses, 1),
                "total_fires": self.total_fires,
                "iteration": self.iteration,
                "high_energy_neurons": high_energy,
            }

    def step(self):
        """时间步进：所有神经元衰减 + 长期抑制（学习/清理）"""
        with self.lock:
            for n in self.neurons.values():
                n.step_decay()
                # 长期不激发 → 抑制连接
                if time.time() - n.last_fired > 3600:
                    for conn_id in list(n.synapses.keys()):
                        w = n.synapses[conn_id]
                        if w < self.ltd_rate:
                            del n.synapses[conn_id]
                        else:
                            n.synapses[conn_id] = w - self.ltd_rate

            # 清理低能量神经元（长期不用）
            old_count = len(self.neurons)
            to_remove = [nid for nid, n in self.neurons.items()
                        if n.energy < 0.15 and time.time() - n.created_at > 86400]
            for nid in to_remove:
                del self.neurons[nid]
            for n in self.neurons.values():
                for rid in to_remove:
                    n.synapses.pop(rid, None)

            if to_remove:
                self._save()

    # ----- 内部：生物学习机制 -----

    def _initialize_synapses(self, new_neuron):
        """新神经元：寻找相似已有神经元建连"""
        candidates = []
        for existing in self.neurons.values():
            if existing.id == new_neuron.id:
                continue
            sim = fingerprint_engine.similarity(new_neuron.fingerprint, existing.fingerprint)
            bonus = self.category_bonus if existing.category == new_neuron.category else 0
            if sim + bonus >= self.min_similarity:
                candidates.append((existing.id, sim))

        candidates.sort(key=lambda x: -x[1])
        for cid, sim in candidates[:self.max_synapses]:
            weight = min(sim * 1.5, 0.5)  # 初始权重
            new_neuron.synapses[cid] = weight
            # 双向连接
            if cid in self.neurons:
                self.neurons[cid].synapses[new_neuron.id] = min(weight * 0.8, 0.4)

    def _spread_activation(self, seed_ids, max_depth=3):
        """激活扩散算法"""
        # 初始化：种子神经元激活到1.0
        for sid in seed_ids:
            if sid in self.neurons:
                self.neurons[sid].activation = 1.0

        activated_order = []
        fired_this_round = set(seed_ids)
        propagation_boost = 5.0  # 信号传播增强系数

        for depth in range(max_depth):
            next_fire = set()
            for nid in fired_this_round:
                n = self.neurons.get(nid)
                if not n or not n.should_fire():
                    continue
                # 激发
                connections = n.fire()
                self.total_fires += 1
                if nid not in activated_order:
                    activated_order.append(nid)

                # 传播到连接的神经元
                for conn_id, weight in connections:
                    conn = self.neurons.get(conn_id)
                    if not conn:
                        continue
                    # 增强信号：权重×增强系数×(1-衰减) + 同类别加成
                    signal = weight * propagation_boost * (1.0 - n.decay_rate)
                    if n.category == conn.category:
                        signal *= 1.3  # 同类别信号更易传导
                    conn.receive_signal(signal)
                    next_fire.add(conn_id)

            if not next_fire:
                break
            fired_this_round = next_fire

        return activated_order

    def _hebbian_learn(self, nid_a, nid_b):
        """赫布学习：一起激发的神经元，连接增强"""
        a = self.neurons.get(nid_a)
        b = self.neurons.get(nid_b)
        if not a or not b:
            return
        # 双向强化
        for src, tgt, init_val in [(a, b, a.synapses.get(b.id, 0)),
                                    (b, a, b.synapses.get(a.id, 0))]:
            if tgt.id in src.synapses:
                src.synapses[tgt.id] = min(1.0, src.synapses[tgt.id] * (1 + self.hebbian_lr))

    # ----- 持久化 -----

    def _load(self):
        try:
            with open(self.data_path) as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return

        for nd in data.get("neurons", []):
            n = Neuron.__new__(Neuron)
            n.id = nd["id"]
            n.content = nd["content"]
            n.category = nd.get("category", "general")
            n.fingerprint = nd.get("fingerprint")
            if not n.fingerprint:
                n.fingerprint = fingerprint_engine.fingerprint(n.content)
            n.activation = nd.get("activation", 0.0)
            n.threshold = nd.get("threshold", 0.65)
            n.decay_rate = nd.get("decay_rate", 0.08)
            n.last_fired = nd.get("last_fired", 0)
            n.fire_count = nd.get("fire_count", 0)
            n.synapses = nd.get("synapses", {})
            n.created_at = nd.get("created_at", time.time())
            n.last_accessed = nd.get("last_accessed", time.time())
            n.energy = nd.get("energy", 1.0)
            self.neurons[n.id] = n

        self.iteration = data.get("iteration", 0)
        self.total_fires = data.get("total_fires", 0)

    def _save(self):
        data = {
            "neurons": [n.to_dict() for n in self.neurons.values()],
            "iteration": self.iteration,
            "total_fires": self.total_fires,
            "saved_at": time.time(),
        }
        with open(self.data_path, "w") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)

    def save(self):
        with self.lock:
            self._save()

    def prune_unused(self, max_age_days=7):
        """修剪长期不用的神经元"""
        with self.lock:
            now = time.time()
            cutoff = now - max_age_days * 86400
            to_prune = [nid for nid, n in self.neurons.items()
                       if n.created_at < cutoff and n.energy < 0.3]
            for nid in to_prune:
                del self.neurons[nid]
            for n in self.neurons.values():
                for pid in to_prune:
                    n.synapses.pop(pid, None)
            return len(to_prune)
