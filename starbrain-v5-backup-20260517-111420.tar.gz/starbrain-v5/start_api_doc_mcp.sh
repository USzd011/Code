#!/bin/bash
# API文档生成MCP工具 - 启动脚本
cd /root/.openclaw/workspace/starbrain-v5
python3 -c "
import sys
sys.argv = ['api_doc_mcp_server']
from api_doc_mcp_server.main import main
main()
" > /root/.openclaw/workspace/starbrain-v5/logs/api_doc_mcp.log 2>&1
