"""
星辰大脑 v5.0 - 主系统集成
将 MCTS / 技能评估 / 算力节点 / 二十八宿 统一接入
"""
import os, sys, json, time, logging, threading
from typing import Optional

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.extend([
    BASE,
    os.path.join(BASE, "compute-node"),
    os.path.join(BASE, "prototypes"),
    os.path.join(BASE, "services"),
])

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('StarBrain')


class StarBrain:
    """星辰大脑 v5.0 主系统"""

    def __init__(self):
        from compute_node import ComputeNode
        self.node = ComputeNode({"max_workers": 4})
        log.info("=" * 50)
        log.info("🔱 星辰大脑 v5.0 主系统初始化")
        log.info("=" * 50)

    def start(self):
        """启动所有子系统"""
        log.info("🚀 星辰大脑启动中...")
        self.node.start()

        # 注册所有业务处理器
        self._register_business_handlers()

        # 启动状态汇报线程
        self._report_thread = threading.Thread(target=self._report_loop, daemon=True)
        self._report_thread.start()

        log.info("✅ 星辰大脑已上线")
        self._print_banner()
        return self

    def _register_business_handlers(self):
        """注册所有业务处理器"""
        from workers.worker_pool import register_handler
        from prototypes.mcts_prototype import MCTSEngine, GameState
        from prototypes.skill_evaluator import SkillEvaluator

        @register_handler("mcts_decision")
        def handle_mcts(payload):
            """MCTS推演决策"""
            state = GameState(
                revenue=payload.get("revenue", 0),
                conversion=payload.get("conversion", 0),
                cost=payload.get("cost", 0),
                risk=payload.get("risk", 0),
            )
            engine = MCTSEngine({"iterations": 3000})
            result = engine.search(state)
            return {
                "best_action": result.best_action.value,
                "score": result.best_score,
                "simulations": engine.iterations,
                "time_ms": round(result.time * 1000, 1),
            }

        @register_handler("skill_evaluate")
        def handle_evaluate(payload):
            """技能评估"""
            evaluator = SkillEvaluator()
            skill_id = payload.get("skill_id", "unknown")
            usage_count = payload.get("usage_count", 1)
            result = evaluator.evaluate_skill(skill_id, usage_count)
            return {
                "skill_id": skill_id,
                "can_upgrade": result.get("can_upgrade", False),
                "score": result.get("score", 0),
                "needs_elimination": result.get("needs_elimination", False),
            }

        @register_handler("douyin_product_selection")
        def handle_douyin_select(payload):
            """抖音选品"""
            category = payload.get("category", "通用")
            log.info(f"  🛒 抖音选品: {category}")
            return {
                "platform": "抖音",
                "category": category,
                "status": "analysing",
                "message": "已启动选品分析",
            }

        @register_handler("toutiao_article")
        def handle_toutiao_article(payload):
            """头条文章生成"""
            topic = payload.get("topic", "AI")
            log.info(f"  📝 头条文章: {topic}")
            return {
                "platform": "头条",
                "topic": topic,
                "status": "generating",
            }

        @register_handler("domain_route")
        def handle_domain_route(payload):
            """二十八宿路由"""
            DOMAIN_MAP = {
                "抖音": "宿1-抖音商品", "快手": "宿2-快手商品",
                "头条": "宿3-头条内容", "达人": "宿4-达人资源",
                "用户": "宿5-用户画像", "竞品": "宿6-竞品分析",
                "趋势": "宿7-趋势预测", "风险": "宿8-风险控制",
            }
            task = payload.get("task", "")
            for keyword, domain in DOMAIN_MAP.items():
                if keyword in task:
                    return {"domain": domain, "task": task}
            return {"domain": "通用", "task": task}

        handlers = len(list(self.node.worker_pool.TASK_HANDLERS.keys()))
        log.info(f"📋 已注册 {handlers} 个任务处理器")

    def _print_banner(self):
        log.info("")
        log.info("🔱 星辰大脑 v5.0 · 运行中")
        log.info(f"  地址: http://10.1.4.16:8899")
        log.info(f"  API:  GET /status → 完整状态")
        log.info(f"        POST /task → 提交任务")
        log.info("")

    def _report_loop(self):
        """每60秒汇报状态"""
        while self.node.running:
            time.sleep(60)
            status = self.node.status()
            log.info(f"📊 状态 | "
                     f"完成:{status['node']['tasks']['completed']} | "
                     f"排队:{status['node']['tasks']['queued']} | "
                     f"运行:{status['node']['tasks']['running']} | "
                     f"内存: {status['resources']['current']['memory']['available_mb']:.0f}MB空闲")

    def stop(self):
        self.node.stop()

    def submit(self, task_type: str, payload: dict, priority: int = 2) -> dict:
        return self.node.submit(task_type, payload, priority)

    def status(self) -> dict:
        return self.node.status()


if __name__ == "__main__":
    brain = StarBrain()
    brain.start()

    # 测试完整链路：MCTS决策
    result = brain.submit("mcts_decision", {"revenue": 100, "conversion": 0.05})
    print(f"🎯 MCTS决策结果: {result}")

    time.sleep(1)
    print(json.dumps(brain.status(), indent=2, ensure_ascii=False)[:500])

    brain.stop()
    print("完成")
