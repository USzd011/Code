#!/usr/bin/env python3
"""
⭐ 腾云大脑 - 身体指令集
用法: brain <命令> [参数]
"""
import sys, json, os, time, hashlib

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)


def cmd_think(query: str):
    """思考: 检索记忆+推理"""
    from brain_cortex import get_cortex_engine
    engine = get_cortex_engine()
    r = engine.think(query)
    return {"answer": r["answer"], "retrieved": r["retrieved"]}


def cmd_learn(topic: str):
    """学习: 主动学一个主题"""
    from brain_cortex import get_cortex_engine
    engine = get_cortex_engine()
    r = engine.learn(topic)
    return {"topic": r.get("topic", topic),
            "status": r.get("status", "learned"),
            "subtopics": r.get("subtopics", [])}


def cmd_memory(query: str, domain: str = ""):
    """搜索记忆"""
    from light_cortex import LightVectorStore
    v = LightVectorStore()
    if domain:
        results = v.search_by_domain(domain)
    else:
        results = v.search(query)
    return {"count": len(results), "results": [
        {"content": r["content"][:100], "domain": r.get("domain", "?"), "score": r.get("score", 0)}
        for r in results[:5]
    ]}


def cmd_store(content: str, domain: str = "通用"):
    """存储记忆"""
    from light_cortex import LightVectorStore
    v = LightVectorStore()
    v.store(content, domain=domain)
    return {"stored": True, "total": v.stats()["total"]}


def cmd_mcts(revenue: str = "100", conversion: str = "0.05", cost: str = "50", risk: str = "0.1"):
    """MCTS推演决策"""
    sys.path.insert(0, os.path.join(BASE, "prototypes"))
    from mcts_prototype import MCTSEngine, GameState
    engine = MCTSEngine(max_iterations=1000)
    state = GameState(revenue=float(revenue), conversion=float(conversion),
                      cost=float(cost), risk=float(risk))
    result = engine.search(state)
    return {
        "action": result["best_action"],
        "top": [f"#{p['rank']} {p['action']} ({p['confidence']}%)" for p in result.get("top3_plans", [])],
        "time_s": round(result.get("time", 0), 3),
    }


def cmd_evolve():
    """自我进化检查"""
    from brain_cortex import get_cortex_engine
    engine = get_cortex_engine()
    stats = engine.stats()
    return {
        "memories": stats["vector_memory"]["total"],
        "api_calls": stats["api_calls"],
        "learned_topics": stats["learned_topics"],
        "topics": stats["topics"],
    }


def cmd_stats():
    """完整状态"""
    from brain_cortex import get_cortex_engine
    from light_cortex import LightVectorStore
    engine = get_cortex_engine()
    v = LightVectorStore()
    s = engine.stats()
    s["vector_memory"]["storage_kb"] = v.stats().get("db_size_kb", 0)
    return s


def cmd_enrich(task: str, goal: str = ""):
    """任务增强: 注入记忆+推理"""
    from brain_cortex import get_cortex_engine
    engine = get_cortex_engine()
    payload = {"goal": goal or task}
    r = engine.enrich_task(task, payload)
    return {
        "memories_loaded": r.get("_context_memories", 0),
        "advice": r.get("_cortex_advice", "无")[:200],
        "payload": payload,
    }


def cmd_route(text: str):
    """二十八宿路由"""
    DOMAINS = {
        "宿1-抖音": ["抖音", "选品", "爆款", "带货"],
        "宿2-快手": ["快手", "小店"],
        "宿3-头条": ["头条", "文章", "写作"],
        "宿4-达人": ["达人", "匹配", "合作"],
        "宿5-用户": ["用户", "画像", "粉丝"],
        "宿6-竞品": ["竞品", "竞争", "市场"],
        "宿7-趋势": ["趋势", "预测", "热点"],
        "宿8-风控": ["风险", "合规", "安全"],
    }
    for domain, keywords in DOMAINS.items():
        for kw in keywords:
            if kw in text:
                return {"domain": domain, "text": text}
    return {"domain": "通用", "text": text}



def cmd_nmem(query: str = ""):
    """神经记忆网络：检索或查询状态"""
    from neural_memory import NeuralMemory
    nm = NeuralMemory(os.path.join(BASE, "data/neural_memory.json"))
    if query:
        r = nm.retrieve(query, 5)
        return {
            "query": query,
            "results": [{"content": x["content"][:80], "score": x["score"],
                         "activation": x.get("activation", 0)} for x in r]
        }
    return {"status": nm.stats()}


def cmd_nlearn(content: str):
    """神经记忆学习：存入一个新神经元"""
    from neural_memory import NeuralMemory
    nm = NeuralMemory(os.path.join(BASE, "data/neural_memory.json"))
    nid = nm.learn(content)
    nm.save()
    n = nm.neurons.get(nid)
    return {"neuron_id": nid, "synapses": len(n.synapses) if n else 0}


def cmd_nthink(query: str):
    """神经网络思考：激活扩散"""
    from neural_memory import NeuralMemory
    nm = NeuralMemory(os.path.join(BASE, "data/neural_memory.json"))
    chain = nm.think(query)
    return {
        "query": query,
        "thought_chain": [
            {"content": c["content"][:50], "activation": c["activation"]}
            for c in chain
        ]
    }


def cmd_nperceive():
    """感知系统状态"""
    from neural_memory import NeuralMemory
    nm = NeuralMemory(os.path.join(BASE, "data/neural_memory.json"))
    s = nm.stats()
    # 检查守护进程
    heartbeat = os.path.join(BASE, "data", "perception.heartbeat")
    running = os.path.exists(heartbeat) and (time.time() - os.path.getmtime(heartbeat)) < 120
    return {
        "running": running,
        "neurons": s["neurons"],
        "synapses": s["total_synapses"],
        "avg_synapses": s["avg_synapses"],
        "total_fires": s["total_fires"],
        "memory_file": "data/neural_memory.json",
    }


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "stats"
    args = sys.argv[2:]
    commands = {
        "think": cmd_think,
        "learn": cmd_learn,
        "mem": cmd_memory,
        "store": cmd_store,
        "mcts": cmd_mcts,
        "evolve": cmd_evolve,
        "stats": cmd_stats,
        "enrich": cmd_enrich,
        "route": cmd_route,
        "nmem": cmd_nmem,
        "nlearn": cmd_nlearn,
        "nthink": cmd_nthink,
        "nperceive": cmd_nperceive,
    }

    if cmd not in commands:
        print(f"命令: {', '.join(commands.keys())}")
        sys.exit(1)

    result = commands[cmd](*args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
