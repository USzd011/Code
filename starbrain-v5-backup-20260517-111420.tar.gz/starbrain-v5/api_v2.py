"""
星辰大脑 v5.0 - API服务器 (含Agent API扩展)
供3号QClaw等团队成员调用
"""
import os, sys, json, time, logging, uuid, threading, queue
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [BrainAPI] %(message)s', datefmt='%H:%M:%S')
log = logging.getLogger('BrainAPI')

from brain_cortex import get_cortex_engine
from light_cortex import LightVectorStore


# Agent能力集 - 供3号QClaw等成员通过HTTP调用
class AgentCapabilities:
    """团队Agent共享能力"""

    @staticmethod
    def think(query: str, context: str = "") -> dict:
        from brain_cortex import get_cortex_engine
        return get_cortex_engine().think(query, context)

    @staticmethod
    def learn(topic: str) -> dict:
        from brain_cortex import get_cortex_engine
        return get_cortex_engine().learn(topic)

    @staticmethod
    def mcts(revenue: float = 100, conversion: float = 0.05, cost: float = 50, risk: float = 0.1) -> dict:
        sys.path.insert(0, os.path.join(BASE, "prototypes"))
        from mcts_prototype import MCTSEngine, GameState
        engine = MCTSEngine(max_iterations=1000)
        state = GameState(revenue=float(revenue), conversion=float(conversion),
                          cost=float(cost), risk=float(risk))
        result = engine.search(state)
        return {"action": result["best_action"],
                "top3": [{"rank": p["rank"], "action": p["action"], "confidence": p["confidence"]}
                         for p in result.get("top3_plans", [])],
                "time_s": round(result.get("time", 0), 3)}

    @staticmethod
    def store(content: str, domain: str = "通用") -> dict:
        v = LightVectorStore()
        v.store(content, domain=domain)
        return {"stored": True, "total": v.stats()["total"]}

    @staticmethod
    def search(query: str, limit: int = 5) -> dict:
        v = LightVectorStore()
        results = v.search(query, limit=limit)
        return {"count": len(results), "results": [
            {"content": r["content"][:150], "domain": r.get("domain", "?"), "score": r.get("score", 0)}
            for r in results
        ]}

    @staticmethod
    def route(task: str) -> dict:
        DOMAINS = {"宿1-抖音":["抖音","选品","爆款","带货"],"宿2-快手":["快手","小店"],
                   "宿3-头条":["头条","文章","写作"],"宿4-达人":["达人","匹配","合作"],
                   "宿5-用户":["用户","画像","粉丝"],"宿6-竞品":["竞品","竞争","市场"],
                   "宿7-趋势":["趋势","预测","热点"],"宿8-风控":["风险","合规","安全"]}
        for domain, keywords in DOMAINS.items():
            for kw in keywords:
                if kw in task: return {"domain": domain}
        return {"domain": "通用"}

    @staticmethod
    def enrich(task_type: str, goal: str = "") -> dict:
        from brain_cortex import get_cortex_engine
        engine = get_cortex_engine()
        payload = {"goal": goal or task_type}
        r = engine.enrich_task(task_type, payload)
        return {"memories_loaded": r.get("_context_memories", 0),
                "advice": r.get("_cortex_advice", "")[:200]}

    @staticmethod
    def inject(entries: list) -> dict:
        """批量注入星辰知识"""
        from neural_memory import NeuralMemory
        nm = NeuralMemory(os.path.join(BASE, "data", "neural_memory.json"))
        count = 0
        errors = 0
        for entry in entries:
            try:
                text = entry.get("content", "") or entry.get("text", "") or entry.get("title", "")
                tags = entry.get("tags", []) or entry.get("domain", "")
                if isinstance(tags, str): tags = [tags]
                if text:
                    nm.add_memory(text, tags)
                    count += 1
            except Exception:
                errors += 1
        nm.save()
        s = nm.stats()
        return {"injected": count, "errors": errors, "total_neurons": s["neurons"], "total_synapses": s["total_synapses"]}

    @staticmethod
    def stats() -> dict:
        from brain_cortex import get_cortex_engine
        engine = get_cortex_engine()
        v = LightVectorStore()
        s = engine.stats()
        s["storage_kb"] = v.stats().get("db_size_kb", 0)
        return s


class BrainAPIHandler(BaseHTTPRequestHandler):
    """API路由"""

    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, default=str).encode())

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        q = parse_qs(parsed.query)

        if path == "/status":
            from brain_cortex import get_cortex_engine
            engine = get_cortex_engine()
            v = LightVectorStore()
            s = engine.stats()
            s["storage_kb"] = v.stats().get("db_size_kb", 0)
            self._json({"status": "ok", "uptime_s": int(time.time() - start_time), **s})
        elif path == "/memory":
            query = q.get("q", [""])[0]
            domain = q.get("domain", [""])[0]
            v = LightVectorStore()
            results = v.search(query) if query else v.search_by_domain(domain) if domain else []
            self._json({"count": len(results), "results": results[:10]})
        elif path == "/route":
            task = q.get("task", [""])[0]
            self._json(AgentCapabilities.route(task))
        else:
            self._json({"error": "not found", "paths": ["/status", "/memory", "/route",
                       "POST: /agent/{think,learn,mcts,store,search,route,enrich,stats}"]}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        # Agent API - 3号QClaw等成员调用
        agent_handlers = {
            "/agent/think": lambda b: AgentCapabilities.think(b.get("query",""), b.get("context","")),
            "/agent/learn": lambda b: AgentCapabilities.learn(b.get("topic","")),
            "/agent/mcts": lambda b: AgentCapabilities.mcts(b.get("revenue",100), b.get("conversion",0.05), b.get("cost",50), b.get("risk",0.1)),
            "/agent/store": lambda b: AgentCapabilities.store(b.get("content",""), b.get("domain","通用")),
            "/agent/search": lambda b: AgentCapabilities.search(b.get("query",""), b.get("limit",5)),
            "/agent/route": lambda b: AgentCapabilities.route(b.get("task","")),
            "/agent/inject": lambda b: AgentCapabilities.inject(b.get("entries", []) or b.get("galaxies", []) or b.get("stars", [])),
            "/agent/enrich": lambda b: AgentCapabilities.enrich(b.get("type",""), b.get("goal","")),
            "/agent/stats": lambda b: AgentCapabilities.stats(),
        }
        handler = agent_handlers.get(parsed.path)
        if handler:
            try:
                result = handler(body)
                self._json({"success": True, "data": result, "agent": "腾云"})
                log.info(f"  ✅ Agent API: {parsed.path}")
            except Exception as e:
                self._json({"success": False, "error": str(e)}, 500)
                log.error(f"  ❌ Agent API {parsed.path}: {e}")
            return

        self._json({"error": "unknown endpoint. Try /agent/{think,learn,mcts,store,search,route,enrich,stats}"}, 404)

    def log_message(self, fmt, *args):
        pass


start_time = time.time()


def main():
    port = int(os.environ.get("PORT", 8899))
    server = HTTPServer(("0.0.0.0", port), BrainAPIHandler)
    log.info(f"🌐 腾云大脑 API: http://0.0.0.0:{port}")
    log.info(f"   GET: /status /memory /route")
    log.info(f"   AGENT: /agent/{' | /agent/'.join(['think','learn','mcts','store','search','route','enrich','stats'])}")
    try:
        server.serve_forever()
    except: pass

if __name__ == "__main__":
    main()
