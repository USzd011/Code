"""
星辰大脑 v5.0 - REST API 服务器
轻量版，单进程 threading，可 PM2 托管
"""
import os, sys, json, time, logging
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [API] %(message)s', datefmt='%H:%M:%S')
log = logging.getLogger('API')

from brain import start_brain, route_domain
from star_memory import get_memory


# 启动大脑
compute = start_brain()
mem = get_memory()


class BrainAPIHandler(BaseHTTPRequestHandler):
    """星辰大脑 REST API"""

    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, default=str).encode())

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/status":
            s = compute.status()
            s["memory"] = mem.stats()
            self._json(s)
        elif path == "/skills":
            self._json(compute.registry.list())
        elif path == "/domains":
            self._json({k: v for k, v in [
                ("宿1-抖音商品", ["选品", "分析", "爆款"]),
                ("宿2-快手商品", ["商品", "上架", "库存"]),
                ("宿3-头条内容", ["文章", "写作", "热点"]),
                ("宿4-达人资源", ["达人", "匹配", "KOL"]),
                ("宿5-用户画像", ["用户", "画像", "受众"]),
                ("宿6-竞品分析", ["竞品", "竞争", "对比"]),
                ("宿7-趋势预测", ["趋势", "预测", "热点"]),
                ("宿8-风险控制", ["风险", "合规", "安全"]),
            ]})
        elif path == "/memory":
            q = parse_qs(parsed.query)
            query = q.get("q", [""])[0]
            domain = q.get("domain", [""])[0]
            if domain:
                results = mem.search_by_domain(domain)
            else:
                results = mem.search(query)
            self._json({"results": results[:20], "count": len(results)})
        elif path == "/route":
            q = parse_qs(parsed.query)
            task = q.get("task", [""])[0]
            self._json({"task": task, "domain": route_domain(task)})
        else:
            self._json({"error": "unknown path", "paths": ["/status", "/skills", "/domains", "/memory", "/route"]}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        if parsed.path == "/task":
            task_type = body.get("type", "ping")
            payload = body.get("payload", {})
            result = compute.submit(task_type, payload)
            self._json(result)
        elif parsed.path == "/collect":
            results = compute.collect()
            self._json({"results": results})
        elif parsed.path == "/memory":
            mem.store(
                content=body.get("content", ""),
                source=body.get("source", "api"),
                domain=body.get("domain", "通用"),
                tags=body.get("tags", ""),
            )
            self._json({"stored": True})
        else:
            self._json({"error": "not found"}, 404)

    def log_message(self, fmt, *args):
        pass  # 静默


def main():
    port = int(os.environ.get("PORT", 8899))
    server = HTTPServer(("0.0.0.0", port), BrainAPIHandler)
    log.info(f"🌐 星辰大脑 API: http://0.0.0.0:{port}")
    log.info(f"   GET  /status   - 完整状态")
    log.info(f"   GET  /skills   - 处理器列表")
    log.info(f"   GET  /domains  - 八宿域信息")
    log.info(f"   GET  /memory?q=xxx - 搜索记忆")
    log.info(f"   GET  /route?task=xxx - 域路由")
    log.info(f"   POST /task     - 提交任务")
    log.info(f"   POST /memory   - 存储记忆")
    log.info(f"   POST /collect  - 收结果")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


if __name__ == "__main__":
    main()

# ===== Agent API 扩展 =====
class AgentAPIHandler:
    """给3号QClaw等团队成员调用的Agent API"""

    @staticmethod
    def handle(path: str, body: dict) -> dict:
        from agents_api import AgentAPI

        routes = {
            "/agent/think": lambda b: AgentAPI.think(b.get("query",""), b.get("context","")),
            "/agent/learn": lambda b: AgentAPI.learn(b.get("topic","")),
            "/agent/mcts": lambda b: AgentAPI.mcts(b.get("revenue",0), b.get("conversion",0), b.get("cost",0), b.get("risk",0)),
            "/agent/store": lambda b: AgentAPI.store(b.get("content",""), b.get("domain","通用")),
            "/agent/search": lambda b: AgentAPI.search(b.get("query",""), b.get("limit",5)),
            "/agent/route": lambda b: AgentAPI.route(b.get("task","")),
            "/agent/enrich": lambda b: AgentAPI.enrich(b.get("type",""), b.get("payload",{})),
        }
        handler = routes.get(path)
        if handler:
            try: return handler(body)
            except Exception as e: return {"error": str(e)}
        return None


# 覆盖原来的do_POST以支持Agent API
_orig_do_POST = BrainAPIHandler.do_POST

def _new_do_POST(self):
    parsed = urlparse(self.path)
    length = int(self.headers.get("Content-Length", 0))
    body = json.loads(self.rfile.read(length)) if length else {}

    # Agent API 路由
    if parsed.path.startswith("/agent/"):
        result = AgentAPIHandler.handle(parsed.path, body)
        if result:
            self._json({"success": True, "data": result})
            return
        self._json({"error": "unknown agent endpoint"}, 404)
        return

    # 原有逻辑
    if parsed.path == "/task":
        task_type = body.get("type", "ping")
        payload = body.get("payload", {})
        self._json(compute.submit(task_type, payload))
    elif parsed.path == "/collect":
        self._json({"results": compute.collect()})
    elif parsed.path == "/memory":
        mem.store(content=body.get("content",""), source=body.get("source","api"),
                  domain=body.get("domain","通用"), tags=body.get("tags",""))
        self._json({"stored": True})
    else:
        self._json({"error": "not found"}, 404)

BrainAPIHandler.do_POST = _new_do_POST
