"""
星辰大脑 - 轻量记忆存储
SQLite + FTS5 全文搜索 + 简单向量模拟
"""

import sqlite3, json, time, os, re, hashlib, threading
from typing import Optional


class StarMemory:
    """记忆存储引擎"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), "data", "star_memory.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._local = threading.local()
        self._init_db()

    def _get_conn(self):
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self.db_path)
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn

    def _init_db(self):
        conn = self._get_conn()
        conn.executescript("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memories USING fts5(
                content, source, domain, tags,
                tokenize='unicode61'
            );
            CREATE TABLE IF NOT EXISTS memory_meta (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_hash TEXT UNIQUE,
                created_at REAL,
                accessed_at REAL,
                access_count INTEGER DEFAULT 0,
                domain TEXT,
                source TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_domain ON memory_meta(domain);
        """)
        conn.commit()

    def store(self, content: str, source: str = "memory",
              domain: str = "通用", tags: str = "") -> int:
        """存储记忆"""
        content_hash = hashlib.md5(content.encode()).hexdigest()
        conn = self._get_conn()
        now = time.time()

        # 查重复
        existing = conn.execute(
            "SELECT id FROM memory_meta WHERE content_hash=?",
            (content_hash,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE memory_meta SET accessed_at=?, access_count=access_count+1 WHERE id=?",
                (now, existing["id"]))
            conn.commit()
            return existing["id"]

        conn.execute("""
            INSERT INTO memory_meta (content_hash, created_at, accessed_at, domain, source)
            VALUES (?, ?, ?, ?, ?)
        """, (content_hash, now, now, domain, source))
        row_id = conn.execute("SELECT last_insert_rowid() as id").fetchone()["id"]

        conn.execute("""
            INSERT INTO memories (rowid, content, source, domain, tags)
            VALUES (?, ?, ?, ?, ?)
        """, (row_id, content, source, domain, tags))
        conn.commit()
        return row_id

    def search(self, query: str, limit: int = 10) -> list:
        """搜索记忆"""
        conn = self._get_conn()
        # 清理查询词
        clean = re.sub(r'[^\w\u4e00-\u9fff]', ' ', query)
        if not clean.strip():
            return []

        try:
            rows = conn.execute("""
                SELECT m.rowid, m.content, m.source, m.domain, m.tags,
                       meta.created_at, meta.access_count
                FROM memories m
                JOIN memory_meta meta ON m.rowid = meta.id
                WHERE memories MATCH ?
                ORDER BY rank
                LIMIT ?
            """, (clean, limit)).fetchall()
        except sqlite3.OperationalError:
            return []

        results = []
        for r in rows:
            results.append({
                "id": r["rowid"],
                "content": r["content"][:200],
                "source": r["source"],
                "domain": r["domain"],
                "created": r["created_at"],
                "access_count": r["access_count"],
            })
        return results

    def search_by_domain(self, domain: str, limit: int = 20) -> list:
        """按域搜索"""
        conn = self._get_conn()
        rows = conn.execute("""
            SELECT id, content_hash, created_at, access_count, domain, source
            FROM memory_meta WHERE domain=? ORDER BY created_at DESC LIMIT ?
        """, (domain, limit)).fetchall()
        return [dict(r) for r in rows]

    def stats(self) -> dict:
        conn = self._get_conn()
        total = conn.execute("SELECT COUNT(*) as c FROM memory_meta").fetchone()["c"]
        domains = conn.execute(
            "SELECT domain, COUNT(*) as c FROM memory_meta GROUP BY domain"
        ).fetchall()
        return {"total": total, "domains": {r["domain"]: r["c"] for r in domains}}


# 全局实例
_memory = None


def get_memory() -> StarMemory:
    global _memory
    if _memory is None:
        _memory = StarMemory()
    return _memory
