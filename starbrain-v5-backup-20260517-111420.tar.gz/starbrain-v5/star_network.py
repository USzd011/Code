"""
星辰大脑 v5.0 - L8 网络层
紫微星阵 (战略决策) + 都天星斗大阵 (容错自愈)
"""
import os, sys, json, time, logging, threading, subprocess
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

log = logging.getLogger('StarNet')


class StrategicLayer:
    """紫微星阵 — 战略决策"""

    def __init__(self, brain):
        self.brain = brain
        self.strategies = []
        self._load_strategies()

    def _load_strategies(self):
        self.strategies = [
            {
                "name": "首次启动",
                "condition": lambda s: s["total_tasks"] == 0,
                "action": "运行早会, 确认每日目标",
                "priority": 1,
            },
            {
                "name": "任务积压",
                "condition": lambda s: s["queued_tasks"] > 10,
                "action": "增加Worker, 优先处理高优先级",
                "priority": 2,
            },
            {
                "name": "资源紧张",
                "condition": lambda s: s["memory_used"] > 85,
                "action": "限流, 清理缓存, 降低并行度",
                "priority": 1,
            },
            {
                "name": "技能空转",
                "condition": lambda s: s["unused_skills"] > 50 and s["total_tasks"] > 20,
                "action": "执行自进化, 评估并淘汰无用技能",
                "priority": 3,
            },
            {
                "name": "夜间维护",
                "condition": lambda s: datetime.now().hour >= 2 and datetime.now().hour <= 4,
                "action": "整理记忆, 压缩数据库, 生成报表",
                "priority": 4,
            },
        ]

    def decide(self, state: dict) -> list:
        """战略决策"""
        actions = []
        for s in self.strategies:
            try:
                if s["condition"](state):
                    actions.append({"strategy": s["name"], "action": s["action"]})
            except:
                pass
        return actions

    def run(self):
        """持续决策循环"""
        while self.brain.running:
            time.sleep(60)
            status = self.brain.status()
            state = {
                "total_tasks": status.get("tasks", {}).get("completed", 0),
                "queued_tasks": status.get("tasks", {}).get("queued", 0),
                "memory_used": int(json.loads(os.popen("free -m | grep Mem").read().split()[2])),
                "unused_skills": 0,
            }
            actions = self.decide(state)
            if actions:
                log.info(f"♛ 紫微决策: {actions[0]['strategy']} → {actions[0]['action']}")


class FaultTolerance:
    """都天星斗大阵 — 容错自愈"""

    def __init__(self, brain):
        self.brain = brain

    def check_and_heal(self) -> list:
        """检查并自愈"""
        issues = []
        status = self.brain.status()
        workers = status.get("workers", {})
        if workers.get("alive", 0) < workers.get("total", 0):
            issues.append(f"Worker死亡: {workers['alive']}/{workers['total']}")
            # 重启死去的Worker (当前threading版无此问题)

        # 检查磁盘
        disk = os.statvfs("/")
        avail = disk.f_bavail * disk.f_frsize / (1024**3)
        if avail < 2:
            issues.append(f"磁盘不足: {avail:.1f}G")

        # 检查内存
        mem = os.popen("free -m | grep Mem").read().strip().split()
        if len(mem) >= 3:
            used_pct = int(mem[2]) / int(mem[1]) * 100
            if used_pct > 90:
                issues.append(f"内存紧张: {used_pct:.0f}%")

        for issue in issues:
            log.warning(f"🛡 自愈检测: {issue}")

        return issues


# ===== 系统监控 =====
class SystemMonitor:
    """系统监控器"""

    def __init__(self, brain):
        self.brain = brain
        self.start_time = time.time()

    def get_state(self) -> dict:
        """完整系统状态"""
        brain_status = self.brain.status()
        workers = brain_status.get("workers", {})
        tasks = brain_status.get("tasks", {})

        mem = os.popen("free -m | grep Mem").read().strip().split()
        mem_used_pct = int(mem[2]) / int(mem[1]) * 100 if len(mem) >= 3 else 0

        disk = os.statvfs("/")
        disk_avail = disk.f_bavail * disk.f_frsize / (1024**3)
        disk_total = disk.f_blocks * disk.f_frsize / (1024**3)
        disk_pct = (disk_total - disk_avail) / disk_total * 100

        return {
            "system": {
                "started": datetime.fromtimestamp(self.start_time).strftime("%H:%M:%S"),
                "uptime_min": int((time.time() - self.start_time) / 60),
                "memory_used_pct": round(mem_used_pct, 1),
                "disk_avail_gb": round(disk_avail, 1),
                "disk_pct": round(disk_pct, 1),
            },
            "brain": {
                "workers": f"{workers.get('alive', 0)}/{workers.get('total', 0)}",
                "tasks_completed": tasks.get("completed", 0),
                "tasks_queued": tasks.get("queued", 0),
                "handlers": len(brain_status.get("handlers", [])),
            },
        }
