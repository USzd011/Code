# OpenClaw 完整学习笔记

> **学习时间：** 2026-05-09 12:25

---

## 一、OpenClaw 核心概念

### 什么是OpenClaw？

**定义：** 自托管网关，连接多渠道（Discord、飞书、Telegram、WhatsApp等）到AI智能体

**核心特点：**
- 自托管：运行在自己的硬件上
- 多渠道：一个Gateway服务多个平台
- 智能体原生：支持工具调用、会话、记忆、多智能体路由
- 开源：MIT许可证

---

## 二、架构理解

### Gateway架构

```
渠道 + 插件 → Gateway → Pi智能体
                 → CLI
                 → Web控制UI
                 → macOS应用
                 → iOS/Android节点
```

### 核心组件

| 组件 | 说明 |
|------|------|
| Gateway | 单一真相来源，管理会话、路由、渠道连接 |
| Channels | Discord、飞书、Telegram、WhatsApp等 |
| Nodes | iOS/Android节点，支持Canvas、相机、语音 |
| Sessions | 会话管理，支持多智能体路由 |
| Memory | 记忆系统，支持多种引擎 |

---

## 三、渠道支持

### 内置渠道

- Discord
- Google Chat
- iMessage
- Matrix
- Microsoft Teams
- Signal
- Slack
- Telegram
- WhatsApp
- Zalo

### 插件渠道

- Nostr
- Twitch
- IRC
- LINE
- Mattermost
- Nextcloud Talk
- Synology Chat
- QQ Bot
- WeChat
- Yuanbao

---

## 四、核心能力

### 1. 多渠道网关
- 单Gateway进程服务所有渠道
- 统一消息格式
- 跨渠道路由

### 2. 多智能体路由
- 按智能体隔离会话
- 按工作空间隔离
- 按发送者隔离

### 3. 媒体支持
- 图片发送/接收
- 音频/语音
- 文档

### 4. Web控制UI
- 浏览器仪表盘
- 聊天、配置、会话管理
- 节点管理

### 5. 移动节点
- iOS/Android配对
- Canvas支持
- 相机集成
- 语音工作流

---

## 五、关键概念

### 会话管理

- 每智能体独立会话
- 会话持久化
- 会话修剪

### 记忆系统

- 内置记忆引擎
- Honcho记忆
- QMD记忆引擎
- 记忆搜索

### 智能体运行时

- 主运行时
- 子智能体
- ACP运行时

### 工具系统

- 工具调用
- 工具策略
- 沙箱执行

---

## 六、CLI命令

### 核心命令

| 命令 | 说明 |
|------|------|
| `openclaw onboard` | 初始化配置 |
| `openclaw gateway` | 网关管理 |
| `openclaw dashboard` | 打开控制UI |
| `openclaw sessions` | 会话管理 |
| `openclaw skills` | 技能管理 |
| `openclaw memory` | 记忆管理 |
| `openclaw nodes` | 节点管理 |
| `openclaw channels` | 渠道管理 |

---

## 七、配置系统

### 配置文件

**位置：** `~/.openclaw/openclaw.json`

### 主要配置项

```json
{
  channels: {
    whatsapp: {
      allowFrom: ["+15555550123"],
      groups: { "*": { requireMention: true } }
    }
  },
  messages: {
    groupChat: { mentionPatterns: ["@openclaw"] }
  },
  agents: {
    // 智能体配置
  },
  memory: {
    // 记忆配置
  }
}
```

---

## 八、自动化系统

### 定时任务

- Cron作业
- 后台任务
- 任务流

### 钩子

- 事件钩子
- 消息钩子
- 自定义钩子

### 常驻指令

- 持久化指令
- 自动执行

---

## 九、安全机制

### 认证

- Token认证
- OAuth支持
- 签名验证

### 权限控制

- AllowFrom白名单
- 群组提及规则
- 操作员权限

### 沙箱

- 工具沙箱
- 命令沙箱
- 提升权限

---

## 十、部署选项

### 安装方式

- Node.js安装
- Docker部署
- Kubernetes
- 云平台（Fly.io、Railway等）

### 远程访问

- SSH访问
- Tailscale
- Bonjour发现

---

## 十一、技能系统

### 技能格式

- SKILL.md定义
- 能力描述
- 触发条件

### 技能管理

- 安装技能
- 更新技能
- 自定义技能

---

## 十二、记忆引擎

### 内置引擎

- MEMORY.md
- memory/*.md
- 记忆搜索

### Honcho记忆

- 外部记忆服务
- 持久化存储

### QMD引擎

- 量化记忆
- 压缩存储

---

## 十三、下一步学习

1. 深入理解会话管理
2. 研究多智能体路由
3. 掌握技能开发
4. 探索记忆引擎
5. 学习插件开发

---

_学习时间: 2026-05-09 12:25_