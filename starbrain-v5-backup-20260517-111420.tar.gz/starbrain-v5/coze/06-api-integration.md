# API集成能力

> 更新时间: 2026-05-09

---

## 一、API概述

### 1.1 扣子API能力

扣子平台提供完整的开放API，支持：

```yaml
api_capabilities:
  # Bot管理
  bot_management:
    - 创建Bot
    - 更新Bot
    - 删除Bot
    - 发布Bot
    - Bot列表
  
  # 对话接口
  conversation:
    - 发起对话
    - 流式响应
    - 历史记录
    - 对话管理
  
  # 知识库
  knowledge_base:
    - 创建知识库
    - 上传文档
    - 检索知识
    - 管理文档
  
  # 工作流
  workflow:
    - 执行工作流
    - 查询状态
    - 获取结果
  
  # 文件管理
  file:
    - 上传文件
    - 下载文件
    - 文件列表
```

### 1.2 API认证

```yaml
authentication:
  # 个人访问令牌(PAT)
  pat:
    description: "个人访问令牌，用于API调用"
    create: "设置 → 个人访问令牌 → 创建令牌"
    format: "pat_xxxxxxxxxxxxxxxx"
    permissions:
      - "bot:read"
      - "bot:write"
      - "conversation:write"
  
  # OAuth 2.0
  oauth:
    description: "OAuth授权，用于第三方应用"
    flow: "授权码模式"
    endpoints:
      authorize: "https://www.coze.cn/open/oauth/authorize"
      token: "https://www.coze.cn/open/oauth/token"
    scopes:
      - "bot:read"
      - "bot:write"
      - "conversation:write"
```

---

## 二、API接口详解

### 2.1 对话API

#### 发起对话

```http
POST /v3/chat
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "bot_id": "bot_xxxxxxxxxxxxxxxx",
  "user_id": "user_123",
  "stream": true,
  "additional_messages": [
    {
      "role": "user",
      "content": "你好，请介绍一下扣子平台",
      "content_type": "text"
    }
  ]
}
```

#### 响应格式

```json
// 非流式响应
{
  "code": 0,
  "msg": "success",
  "data": {
    "id": "chat_xxxxxxxxxxxxxxxx",
    "conversation_id": "conv_xxxxxxxxxxxxxxxx",
    "messages": [
      {
        "id": "msg_xxxxxxxxxxxxxxxx",
        "role": "assistant",
        "content": "扣子是字节跳动推出的AI Agent平台...",
        "content_type": "text"
      }
    ],
    "usage": {
      "token_count": 150,
      "input_tokens": 20,
      "output_tokens": 130
    }
  }
}

// 流式响应 (SSE)
data: {"event": "conversation.message.delta", "data": {"content": "扣子"}}
data: {"event": "conversation.message.delta", "data": {"content": "是"}}
data: {"event": "conversation.message.completed", "data": {...}}
data: [DONE]
```

#### 多轮对话

```http
POST /v3/chat
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "bot_id": "bot_xxxxxxxxxxxxxxxx",
  "user_id": "user_123",
  "conversation_id": "conv_xxxxxxxxxxxxxxxx",
  "additional_messages": [
    {
      "role": "user",
      "content": "它有哪些主要功能？",
      "content_type": "text"
    }
  ]
}
```

### 2.2 Bot管理API

#### 创建Bot

```http
POST /v1/bot/create
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "name": "智能客服",
  "description": "企业智能客服助手",
  "icon_url": "https://example.com/icon.png",
  "model": "doubao-pro-32k",
  "prompt_info": {
    "prompt": "你是一个专业的客服助手..."
  },
  "knowledge": [
    {
      "knowledge_id": "kb_xxxxxxxxxxxxxxxx"
    }
  ],
  "skills": [
    {
      "skill_id": "skill_web_search"
    }
  ]
}
```

#### 更新Bot

```http
POST /v1/bot/update
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "bot_id": "bot_xxxxxxxxxxxxxxxx",
  "name": "智能客服Pro",
  "description": "升级版智能客服助手"
}
```

#### 发布Bot

```http
POST /v1/bot/publish
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "bot_id": "bot_xxxxxxxxxxxxxxxx",
  "connector_ids": ["api", "wechat"]
}
```

### 2.3 知识库API

#### 创建知识库

```http
POST /v1/knowledge/create
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "name": "产品手册",
  "description": "公司产品使用手册",
  "type": "document"
}
```

#### 上传文档

```http
POST /v1/knowledge/document/upload
Content-Type: multipart/form-data
Authorization: Bearer {access_token}

{
  "knowledge_id": "kb_xxxxxxxxxxxxxxxx",
  "file": "<binary>"
}
```

#### 检索知识

```http
POST /v1/knowledge/search
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "knowledge_id": "kb_xxxxxxxxxxxxxxxx",
  "query": "如何使用扣子平台创建Bot？",
  "top_k": 5
}
```

### 2.4 工作流API

#### 执行工作流

```http
POST /v1/workflow/run
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "workflow_id": "wf_xxxxxxxxxxxxxxxx",
  "parameters": {
    "input_text": "分析这段文本",
    "options": {
      "language": "zh"
    }
  }
}
```

#### 查询工作流状态

```http
GET /v1/workflow/run/{run_id}
Authorization: Bearer {access_token}
```

### 2.5 文件API

#### 上传文件

```http
POST /v1/files/upload
Content-Type: multipart/form-data
Authorization: Bearer {access_token}

{
  "file": "<binary>",
  "purpose": "chat"
}
```

#### 下载文件

```http
GET /v1/files/{file_id}/content
Authorization: Bearer {access_token}
```

---

## 三、SDK使用

### 3.1 Python SDK

#### 安装

```bash
pip install coze
```

#### 初始化

```python
from coze import Coze

# 初始化客户端
client = Coze(api_key="pat_xxxxxxxxxxxxxxxx")

# 或使用环境变量
# export COZE_API_KEY=pat_xxxxxxxxxxxxxxxx
# client = Coze()
```

#### 对话示例

```python
from coze import Coze

client = Coze(api_key="pat_xxxxxxxxxxxxxxxx")

# 创建对话
chat = client.chat.create(
    bot_id="bot_xxxxxxxxxxxxxxxx",
    user_id="user_123",
    additional_messages=[
        {
            "role": "user",
            "content": "你好，请介绍一下扣子平台",
            "content_type": "text"
        }
    ]
)

# 获取响应
print(chat.messages[0].content)

# 流式响应
stream = client.chat.create(
    bot_id="bot_xxxxxxxxxxxxxxxx",
    user_id="user_123",
    stream=True,
    additional_messages=[
        {
            "role": "user",
            "content": "你好",
            "content_type": "text"
        }
    ]
)

for event in stream:
    if event.event == "conversation.message.delta":
        print(event.data.content, end="")
```

#### Bot管理示例

```python
# 创建Bot
bot = client.bot.create(
    name="智能客服",
    description="企业智能客服助手",
    model="doubao-pro-32k",
    prompt_info={
        "prompt": "你是一个专业的客服助手..."
    }
)

# 更新Bot
client.bot.update(
    bot_id=bot.id,
    name="智能客服Pro"
)

# 发布Bot
client.bot.publish(
    bot_id=bot.id,
    connector_ids=["api", "wechat"]
)
```

### 3.2 JavaScript/TypeScript SDK

#### 安装

```bash
npm install coze-api
```

#### 初始化

```typescript
import { CozeAPI } from 'coze-api';

const client = new CozeAPI({
  apiKey: 'pat_xxxxxxxxxxxxxxxx',
});
```

#### 对话示例

```typescript
// 创建对话
const chat = await client.chat.create({
  bot_id: 'bot_xxxxxxxxxxxxxxxx',
  user_id: 'user_123',
  additional_messages: [
    {
      role: 'user',
      content: '你好，请介绍一下扣子平台',
      content_type: 'text',
    },
  ],
});

console.log(chat.messages[0].content);

// 流式响应
const stream = await client.chat.create({
  bot_id: 'bot_xxxxxxxxxxxxxxxx',
  user_id: 'user_123',
  stream: true,
  additional_messages: [
    {
      role: 'user',
      content: '你好',
      content_type: 'text',
    },
  ],
});

for await (const event of stream) {
  if (event.event === 'conversation.message.delta') {
    process.stdout.write(event.data.content);
  }
}
```

### 3.3 HTTP客户端示例

```python
import requests
import json

API_KEY = "pat_xxxxxxxxxxxxxxxx"
BASE_URL = "https://api.coze.cn"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# 发起对话
def chat(bot_id, user_id, message):
    url = f"{BASE_URL}/v3/chat"
    payload = {
        "bot_id": bot_id,
        "user_id": user_id,
        "additional_messages": [
            {
                "role": "user",
                "content": message,
                "content_type": "text"
            }
        ]
    }
    
    response = requests.post(url, headers=headers, json=payload)
    return response.json()

# 流式对话
def chat_stream(bot_id, user_id, message):
    url = f"{BASE_URL}/v3/chat"
    payload = {
        "bot_id": bot_id,
        "user_id": user_id,
        "stream": True,
        "additional_messages": [
            {
                "role": "user",
                "content": message,
                "content_type": "text"
            }
        ]
    }
    
    with requests.post(url, headers=headers, json=payload, stream=True) as response:
        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8')
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        break
                    yield json.loads(data)
```

---

## 四、Webhook集成

### 4.1 Webhook配置

```yaml
webhook:
  # 配置Webhook接收地址
  url: "https://your-server.com/webhook/coze"
  
  # 事件订阅
  events:
    - "conversation.message.completed"
    - "workflow.run.completed"
    - "bot.published"
  
  # 安全验证
  security:
    secret: "your_webhook_secret"
    verify_signature: true
```

### 4.2 Webhook事件

```json
// 对话完成事件
{
  "event": "conversation.message.completed",
  "timestamp": 1704067200000,
  "data": {
    "conversation_id": "conv_xxxxxxxxxxxxxxxx",
    "message_id": "msg_xxxxxxxxxxxxxxxx",
    "bot_id": "bot_xxxxxxxxxxxxxxxx",
    "user_id": "user_123",
    "content": "这是Bot的回复内容",
    "content_type": "text"
  }
}

// 工作流完成事件
{
  "event": "workflow.run.completed",
  "timestamp": 1704067200000,
  "data": {
    "run_id": "run_xxxxxxxxxxxxxxxx",
    "workflow_id": "wf_xxxxxxxxxxxxxxxx",
    "status": "success",
    "output": {
      "result": "处理完成"
    }
  }
}
```

### 4.3 Webhook处理示例

```python
from flask import Flask, request, jsonify
import hmac
import hashlib

app = Flask(__name__)
WEBHOOK_SECRET = "your_webhook_secret"

def verify_signature(payload, signature):
    expected = hmac.new(
        WEBHOOK_SECRET.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected}", signature)

@app.route('/webhook/coze', methods=['POST'])
def handle_webhook():
    # 验证签名
    signature = request.headers.get('X-Coze-Signature')
    if not verify_signature(request.data, signature):
        return jsonify({"error": "Invalid signature"}), 401
    
    # 处理事件
    event = request.json
    event_type = event.get('event')
    
    if event_type == 'conversation.message.completed':
        handle_message_completed(event['data'])
    elif event_type == 'workflow.run.completed':
        handle_workflow_completed(event['data'])
    
    return jsonify({"status": "ok"}), 200

def handle_message_completed(data):
    print(f"Message completed: {data['message_id']}")
    # 处理逻辑...

def handle_workflow_completed(data):
    print(f"Workflow completed: {data['run_id']}")
    # 处理逻辑...
```

---

## 五、第三方集成

### 5.1 飞书集成

```yaml
feishu_integration:
  # 创建飞书机器人
  steps:
    1. 在扣子平台创建Bot
    2. 发布到飞书渠道
    3. 获取飞书App ID和App Secret
    4. 配置飞书机器人
  
  # 消息格式
  message_types:
    - text
    - image
    - card
    - interactive
```

### 5.2 微信集成

```yaml
wechat_integration:
  # 公众号接入
  official_account:
    steps:
      1. 创建Bot并发布到微信公众号
      2. 获取AppID和AppSecret
      3. 配置服务器地址
      4. 设置消息加解密
  
  # 小程序接入
  mini_program:
    steps:
      1. 创建Bot并发布到微信小程序
      2. 集成小程序SDK
      3. 配置用户授权
```

### 5.3 钉钉集成

```yaml
dingtalk_integration:
  # 创建钉钉机器人
  steps:
    1. 创建Bot并发布到钉钉
    2. 获取钉钉AppKey和AppSecret
    3. 配置机器人权限
    4. 设置消息回调
```

---

## 六、API最佳实践

### 6.1 错误处理

```python
from coze import Coze, APIError, RateLimitError

client = Coze(api_key="pat_xxxxxxxxxxxxxxxx")

try:
    chat = client.chat.create(
        bot_id="bot_xxxxxxxxxxxxxxxx",
        user_id="user_123",
        additional_messages=[...]
    )
except RateLimitError as e:
    print(f"Rate limit exceeded, retry after {e.retry_after} seconds")
except APIError as e:
    print(f"API error: {e.message}, code: {e.code}")
```

### 6.2 重试策略

```python
import time
from functools import wraps

def retry(max_attempts=3, delay=1, backoff=2):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    if attempts >= max_attempts:
                        raise
                    time.sleep(delay * (backoff ** (attempts - 1)))
        return wrapper
    return decorator

@retry(max_attempts=3, delay=1)
def call_api():
    # API调用
    pass
```

### 6.3 并发控制

```python
import asyncio
from asyncio import Semaphore

async def process_concurrent(requests, max_concurrent=10):
    semaphore = Semaphore(max_concurrent)
    
    async def process_with_limit(request):
        async with semaphore:
            return await process_request(request)
    
    tasks = [process_with_limit(req) for req in requests]
    return await asyncio.gather(*tasks)
```

### 6.4 缓存策略

```python
from functools import lru_cache
import hashlib

@lru_cache(maxsize=1000)
def cached_knowledge_search(knowledge_id, query_hash):
    # 知识库检索
    return client.knowledge.search(
        knowledge_id=knowledge_id,
        query=query
    )

def search_with_cache(knowledge_id, query):
    query_hash = hashlib.md5(query.encode()).hexdigest()
    return cached_knowledge_search(knowledge_id, query_hash)
```

---

## 七、API限制

### 7.1 速率限制

```yaml
rate_limits:
  # 对话API
  chat:
    requests_per_minute: 60
    tokens_per_minute: 60000
  
  # Bot管理API
  bot:
    requests_per_minute: 30
  
  # 知识库API
  knowledge:
    requests_per_minute: 100
  
  # 文件API
  file:
    upload_size_limit: 50MB
    requests_per_minute: 20
```

### 7.2 配额限制

```yaml
quotas:
  # 免费版
  free:
    bot_count: 5
    conversations_per_day: 100
    knowledge_base_size: 100MB
  
  # 专业版
  pro:
    bot_count: 20
    conversations_per_day: 1000
    knowledge_base_size: 1GB
  
  # 企业版
  enterprise:
    bot_count: unlimited
    conversations_per_day: unlimited
    knowledge_base_size: unlimited
```

---

## 八、总结

扣子API提供完整的集成能力：

- ✅ **RESTful API**: 标准HTTP接口
- ✅ **多语言SDK**: Python/JavaScript/Java
- ✅ **Webhook**: 事件推送机制
- ✅ **第三方集成**: 飞书/微信/钉钉

关键成功因素：
1. 合理的错误处理
2. 适当的重试策略
3. 有效的并发控制
4. 智能的缓存策略