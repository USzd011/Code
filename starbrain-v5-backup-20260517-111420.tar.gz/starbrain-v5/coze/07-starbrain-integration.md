# 与星辰大脑对接方案

> 更新时间: 2026-05-09

---

## 一、星辰大脑概述

### 1.1 什么是星辰大脑

星辰大脑是自研的AI智能体框架，具备：

```yaml
starbrain_features:
  - 多模型支持          # 支持多种LLM
  - 技能系统            # 可扩展技能
  - 记忆系统            # 长短期记忆
  - 工作流引擎          # 流程编排
  - 知识库管理          # 知识增强
  - 多渠道接入          # 多平台支持
```

### 1.2 对接目标

```
星辰大脑 + 扣子平台对接目标:
┌─────────────────────────────────────────────────────────┐
│  🎯 能力互补                                             │
│     星辰大脑: 深度定制、私有化、灵活控制                  │
│     扣子平台: 快速开发、生态集成、多渠道发布              │
│                                                          │
│  🔄 双向赋能                                             │
│     星辰大脑 → 扣子: 导出技能、工作流、知识库             │
│     扣子 → 星辰大脑: 导入模板、插件、最佳实践             │
│                                                          │
│  🌐 场景协同                                             │
│     内部场景: 星辰大脑私有化部署                         │
│     外部场景: 扣子平台快速发布                           │
└─────────────────────────────────────────────────────────┘
```

---

## 二、对接架构

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                      应用层                                  │
│  ┌──────────────────┐          ┌──────────────────┐        │
│  │   星辰大脑        │          │   扣子平台        │        │
│  │  ┌────────────┐  │          │  ┌────────────┐  │        │
│  │  │ Bot引擎    │  │          │  │ Bot引擎    │  │        │
│  │  ├────────────┤  │          │  ├────────────┤  │        │
│  │  │ 技能系统   │  │          │  │ 技能系统   │  │        │
│  │  ├────────────┤  │          │  ├────────────┤  │        │
│  │  │ 工作流     │  │          │  │ 工作流     │  │        │
│  │  ├────────────┤  │          │  ├────────────┤  │        │
│  │  │ 知识库     │  │          │  │ 知识库     │  │        │
│  │  └────────────┘  │          │  └────────────┘  │        │
│  └──────────────────┘          └──────────────────┘        │
└─────────────────────────────────────────────────────────────┘
                    │                    │
                    └────────┬───────────┘
                             │
┌─────────────────────────────────────────────────────────────┐
│                      对接层                                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              统一接口层                              │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐            │   │
│  │  │ 技能转换 │ │ 工作流转换│ │ 知识库同步│            │   │
│  │  └──────────┘ └──────────┘ └──────────┘            │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                             │
┌─────────────────────────────────────────────────────────────┐
│                      数据层                                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐      │
│  │ 技能定义 │ │ 工作流定义│ │ 知识库   │ │ 配置     │      │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘      │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 对接方式

```yaml
integration_modes:
  # 方式1: API对接
  api:
    description: "通过扣子API调用星辰大脑"
    use_case: "星辰大脑作为后端服务"
    pros:
      - 灵活控制
      - 私有化部署
    cons:
      - 需要开发
      - 维护成本
  
  # 方式2: 导入导出
  import_export:
    description: "技能、工作流、知识库互导"
    use_case: "资源共享、快速迁移"
    pros:
      - 操作简单
      - 快速复用
    cons:
      - 格式转换
      - 兼容性问题
  
  # 方式3: 混合模式
  hybrid:
    description: "核心用星辰大脑，边缘用扣子"
    use_case: "企业内部+外部服务"
    pros:
      - 最佳平衡
      - 场景适配
    cons:
      - 架构复杂
```

---

## 三、技能对接

### 3.1 技能格式转换

#### 星辰大脑技能格式

```yaml
# 星辰大脑技能定义
skill:
  id: "skill_001"
  name: "数据分析"
  description: "分析数据并生成报告"
  
  # 输入定义
  inputs:
    - name: "data"
      type: "file"
      required: true
    - name: "type"
      type: "string"
      enum: ["summary", "trend"]
  
  # 输出定义
  outputs:
    - name: "report"
      type: "markdown"
    - name: "charts"
      type: "image[]"
  
  # 执行逻辑
  executor:
    type: "python"
    code: |
      import pandas as pd
      # 分析逻辑...
      return report, charts
```

#### 扣子技能格式

```yaml
# 扣子技能定义
skill:
  name: "数据分析"
  description: "分析数据并生成报告"
  
  # 输入参数
  inputs:
    - name: "data"
      type: "file"
      required: true
      description: "数据文件"
    - name: "type"
      type: "string"
      required: false
      default: "summary"
      enum: ["summary", "trend"]
  
  # 执行逻辑（工作流）
  workflow:
    nodes:
      - type: "code"
        language: "python"
        code: |
          import pandas as pd
          # 分析逻辑...
  
  # 输出
  outputs:
    - name: "report"
      type: "markdown"
    - name: "charts"
      type: "image[]"
```

### 3.2 技能转换器

```python
class SkillConverter:
    """星辰大脑 ↔ 扣子 技能转换器"""
    
    def to_coze(self, starbrain_skill):
        """星辰大脑技能 → 扣子技能"""
        return {
            "name": starbrain_skill["name"],
            "description": starbrain_skill["description"],
            "inputs": self._convert_inputs(starbrain_skill["inputs"]),
            "workflow": self._convert_executor(starbrain_skill["executor"]),
            "outputs": self._convert_outputs(starbrain_skill["outputs"])
        }
    
    def from_coze(self, coze_skill):
        """扣子技能 → 星辰大脑技能"""
        return {
            "id": self._generate_id(),
            "name": coze_skill["name"],
            "description": coze_skill["description"],
            "inputs": self._convert_inputs_back(coze_skill["inputs"]),
            "executor": self._convert_workflow(coze_skill["workflow"]),
            "outputs": self._convert_outputs_back(coze_skill["outputs"])
        }
    
    def _convert_inputs(self, inputs):
        """转换输入参数"""
        return [
            {
                "name": inp["name"],
                "type": inp["type"],
                "required": inp.get("required", False),
                "description": inp.get("description", "")
            }
            for inp in inputs
        ]
    
    def _convert_executor(self, executor):
        """转换执行逻辑为工作流"""
        if executor["type"] == "python":
            return {
                "nodes": [
                    {
                        "type": "code",
                        "language": "python",
                        "code": executor["code"]
                    }
                ]
            }
        # 其他类型转换...
```

### 3.3 技能同步

```python
class SkillSync:
    """技能双向同步"""
    
    def __init__(self, starbrain_client, coze_client):
        self.starbrain = starbrain_client
        self.coze = coze_client
        self.converter = SkillConverter()
    
    def sync_to_coze(self, skill_ids):
        """同步星辰大脑技能到扣子"""
        for skill_id in skill_ids:
            # 获取星辰大脑技能
            skill = self.starbrain.get_skill(skill_id)
            
            # 转换为扣子格式
            coze_skill = self.converter.to_coze(skill)
            
            # 创建扣子技能
            result = self.coze.create_skill(coze_skill)
            
            # 记录映射关系
            self._save_mapping(skill_id, result["id"])
    
    def sync_from_coze(self, skill_ids):
        """从扣子同步技能到星辰大脑"""
        for skill_id in skill_ids:
            # 获取扣子技能
            skill = self.coze.get_skill(skill_id)
            
            # 转换为星辰大脑格式
            starbrain_skill = self.converter.from_coze(skill)
            
            # 创建星辰大脑技能
            result = self.starbrain.create_skill(starbrain_skill)
            
            # 记录映射关系
            self._save_mapping(result["id"], skill_id)
```

---

## 四、工作流对接

### 4.1 工作流格式转换

#### 星辰大脑工作流

```yaml
workflow:
  id: "wf_001"
  name: "智能问答"
  
  nodes:
    - id: "start"
      type: "start"
      inputs: ["question"]
    
    - id: "intent"
      type: "llm"
      config:
        model: "gpt-4"
        prompt: "识别意图: {{start.question}}"
    
    - id: "knowledge"
      type: "knowledge"
      config:
        kb_id: "kb_001"
        query: "{{start.question}}"
    
    - id: "answer"
      type: "llm"
      config:
        prompt: |
          基于知识回答: {{knowledge.result}}
          问题: {{start.question}}
    
    - id: "end"
      type: "end"
      outputs: ["answer.response"]
  
  edges:
    - {from: "start", to: "intent"}
    - {from: "intent", to: "knowledge"}
    - {from: "knowledge", to: "answer"}
    - {from: "answer", to: "end"}
```

### 4.2 工作流转换器

```python
class WorkflowConverter:
    """工作流转换器"""
    
    def to_coze(self, starbrain_workflow):
        """星辰大脑工作流 → 扣子工作流"""
        coze_workflow = {
            "name": starbrain_workflow["name"],
            "nodes": [],
            "edges": []
        }
        
        # 转换节点
        for node in starbrain_workflow["nodes"]:
            coze_node = self._convert_node(node)
            coze_workflow["nodes"].append(coze_node)
        
        # 转换连线
        coze_workflow["edges"] = starbrain_workflow["edges"]
        
        return coze_workflow
    
    def _convert_node(self, node):
        """转换单个节点"""
        type_mapping = {
            "start": "start",
            "end": "end",
            "llm": "llm",
            "knowledge": "knowledge",
            "code": "code",
            "http": "http",
            "condition": "condition",
            "loop": "loop"
        }
        
        return {
            "id": node["id"],
            "type": type_mapping.get(node["type"], node["type"]),
            "config": node.get("config", {}),
            "inputs": node.get("inputs", []),
            "outputs": node.get("outputs", [])
        }
```

---

## 五、知识库对接

### 5.1 知识库同步方案

```python
class KnowledgeSync:
    """知识库同步"""
    
    def __init__(self, starbrain_client, coze_client):
        self.starbrain = starbrain_client
        self.coze = coze_client
    
    def sync_to_coze(self, kb_id):
        """同步星辰大脑知识库到扣子"""
        # 获取星辰大脑知识库
        kb = self.starbrain.get_knowledge_base(kb_id)
        
        # 创建扣子知识库
        coze_kb = self.coze.create_knowledge_base({
            "name": kb["name"],
            "description": kb["description"],
            "type": "document"
        })
        
        # 同步文档
        for doc in kb["documents"]:
            # 导出文档
            content = self.starbrain.export_document(doc["id"])
            
            # 上传到扣子
            self.coze.upload_document(coze_kb["id"], content)
        
        return coze_kb
    
    def sync_from_coze(self, kb_id):
        """从扣子同步知识库到星辰大脑"""
        # 获取扣子知识库
        kb = self.coze.get_knowledge_base(kb_id)
        
        # 创建星辰大脑知识库
        starbrain_kb = self.starbrain.create_knowledge_base({
            "name": kb["name"],
            "description": kb["description"]
        })
        
        # 同步文档
        documents = self.coze.list_documents(kb_id)
        for doc in documents:
            # 下载文档
            content = self.coze.download_document(doc["id"])
            
            # 导入到星辰大脑
            self.starbrain.import_document(starbrain_kb["id"], content)
        
        return starbrain_kb
```

### 5.2 增量同步

```python
class IncrementalSync:
    """增量同步"""
    
    def __init__(self, starbrain_client, coze_client):
        self.starbrain = starbrain_client
        self.coze = coze_client
    
    def sync_updates(self, last_sync_time):
        """同步增量更新"""
        # 获取更新记录
        updates = self.starbrain.get_updates(since=last_sync_time)
        
        for update in updates:
            if update["type"] == "document":
                self._sync_document(update)
            elif update["type"] == "knowledge_base":
                self._sync_knowledge_base(update)
    
    def _sync_document(self, update):
        """同步文档更新"""
        if update["action"] == "create":
            # 新增文档
            content = self.starbrain.get_document(update["id"])
            self.coze.upload_document(update["kb_id"], content)
        
        elif update["action"] == "update":
            # 更新文档
            content = self.starbrain.get_document(update["id"])
            self.coze.update_document(update["coze_id"], content)
        
        elif update["action"] == "delete":
            # 删除文档
            self.coze.delete_document(update["coze_id"])
```

---

## 六、API对接方案

### 6.1 星辰大脑作为后端

```yaml
# 扣子Bot配置星辰大脑API
bot_config:
  name: "星辰大脑Bot"
  
  # 使用扣子的HTTP节点调用星辰大脑API
  workflow:
    nodes:
      - type: "start"
        inputs: ["question"]
      
      - type: "http"
        name: "调用星辰大脑"
        config:
          method: "POST"
          url: "https://starbrain.example.com/api/v1/chat"
          headers:
            Authorization: "Bearer ${STARBRAIN_TOKEN}"
          body:
            query: "{{start.question}}"
            user_id: "{{user_id}}"
      
      - type: "end"
        outputs: ["http.response"]
```

### 6.2 扣子作为前端

```python
# 星辰大脑调用扣子API
class CozeIntegration:
    def __init__(self, api_key):
        self.client = Coze(api_key=api_key)
    
    def call_coze_bot(self, bot_id, user_id, message):
        """调用扣子Bot"""
        chat = self.client.chat.create(
            bot_id=bot_id,
            user_id=user_id,
            additional_messages=[
                {
                    "role": "user",
                    "content": message,
                    "content_type": "text"
                }
            ]
        )
        return chat.messages[0].content
    
    def execute_coze_workflow(self, workflow_id, params):
        """执行扣子工作流"""
        result = self.client.workflow.run(
            workflow_id=workflow_id,
            parameters=params
        )
        return result["output"]
```

---

## 七、场景方案

### 7.1 企业内部场景

```yaml
enterprise_internal:
  # 使用星辰大脑私有化部署
  deployment:
    platform: "starbrain"
    reason:
      - 数据安全
      - 定制需求
      - 成本控制
  
  # 架构
  architecture:
    frontend: "企业内部系统"
    backend: "星辰大脑私有化"
    knowledge: "内部知识库"
```

### 7.2 外部服务场景

```yaml
external_service:
  # 使用扣子平台快速发布
  deployment:
    platform: "coze"
    reason:
      - 快速上线
      - 多渠道发布
      - 生态集成
  
  # 架构
  architecture:
    channels:
      - 微信公众号
      - 飞书机器人
      - API服务
    backend: "扣子Bot"
    knowledge: "扣子知识库"
```

### 7.3 混合场景

```yaml
hybrid_scenario:
  # 核心用星辰大脑，边缘用扣子
  architecture:
    # 内部核心系统
    core:
      platform: "starbrain"
      components:
        - 核心业务逻辑
        - 敏感数据处理
        - 内部知识库
    
    # 外部服务
    edge:
      platform: "coze"
      components:
        - 客户服务Bot
        - 公开知识问答
        - 多渠道接入
    
    # 数据同步
    sync:
      - 内部知识 → 扣子知识库
      - 技能模板 → 扣子技能
      - 工作流 → 扣子工作流
```

---

## 八、实施步骤

### 8.1 对接实施计划

```yaml
implementation_plan:
  # Phase 1: 基础对接
  phase_1:
    duration: "2周"
    tasks:
      - 搭建对接架构
      - 实现技能转换器
      - 实现工作流转换器
      - 测试基础功能
  
  # Phase 2: 知识库同步
  phase_2:
    duration: "1周"
    tasks:
      - 实现知识库同步
      - 增量同步机制
      - 数据一致性验证
  
  # Phase 3: API对接
  phase_3:
    duration: "1周"
    tasks:
      - 星辰大脑API适配
      - 扣子API集成
      - 联调测试
  
  # Phase 4: 场景落地
  phase_4:
    duration: "2周"
    tasks:
      - 企业内部场景部署
      - 外部服务发布
      - 监控告警
      - 文档完善
```

### 8.2 技术要求

```yaml
technical_requirements:
  # 星辰大脑侧
  starbrain:
    - 提供RESTful API
    - 支持技能/工作流导出
    - 支持知识库导出
    - 提供Webhook回调
  
  # 扣子平台侧
  coze:
    - API访问权限
    - 技能创建权限
    - 工作流创建权限
    - 知识库管理权限
  
  # 网络要求
  network:
    - 星辰大脑API可访问
    - 扣子API可访问
    - 稳定的网络连接
```

---

## 九、总结

星辰大脑与扣子平台对接方案：

- ✅ **能力互补**: 各自优势最大化
- ✅ **双向赋能**: 技能、工作流、知识库互通
- ✅ **场景协同**: 内部私有化 + 外部快速发布
- ✅ **灵活架构**: API对接、导入导出、混合模式

关键成功因素：
1. 清晰的对接架构
2. 完善的转换机制
3. 可靠的同步策略
4. 合理的场景划分