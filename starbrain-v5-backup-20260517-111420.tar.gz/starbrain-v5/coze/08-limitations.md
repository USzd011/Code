# 平台限制与规避方法

> 更新时间: 2026-05-09

---

## 一、平台限制总览

### 1.1 免费版限制

```yaml
free_tier_limits:
  # Bot限制
  bot:
    count: 5                    # Bot数量
    conversations_per_day: 100  # 每日对话次数
    message_length: 2000        # 单条消息长度
  
  # 知识库限制
  knowledge_base:
    count: 3                    # 知识库数量
    total_size: 100MB           # 总容量
    file_size: 10MB             # 单文件大小
    documents: 100              # 文档数量
  
  # 工作流限制
  workflow:
    count: 5                    # 工作流数量
    nodes_per_workflow: 20      # 每个工作流节点数
    executions_per_day: 50      # 每日执行次数
  
  # 技能限制
  skill:
    custom_skills: 10           # 自定义技能数
  
  # 发布限制
  publish:
    channels: ["api"]           # 发布渠道
    api_calls_per_day: 1000     # API调用次数
```

### 1.2 专业版限制

```yaml
pro_tier_limits:
  bot:
    count: 20
    conversations_per_day: 1000
    message_length: 8000
  
  knowledge_base:
    count: 10
    total_size: 1GB
    file_size: 50MB
    documents: 1000
  
  workflow:
    count: 20
    nodes_per_workflow: 50
    executions_per_day: 500
  
  skill:
    custom_skills: 50
  
  publish:
    channels: ["api", "wechat", "feishu", "dingtalk"]
    api_calls_per_day: 10000
```

### 1.3 企业版限制

```yaml
enterprise_tier_limits:
  bot:
    count: "unlimited"
    conversations_per_day: "unlimited"
    message_length: 32000
  
  knowledge_base:
    count: "unlimited"
    total_size: "unlimited"
    file_size: 100MB
    documents: "unlimited"
  
  workflow:
    count: "unlimited"
    nodes_per_workflow: 100
    executions_per_day: "unlimited"
  
  skill:
    custom_skills: "unlimited"
  
  publish:
    channels: "all"
    api_calls_per_day: "unlimited"
  
  # 企业专属
  enterprise_only:
    - 私有化部署
    - SSO单点登录
    - 数据隔离
    - 审计日志
    - 专属模型
    - 定制开发
```

---

## 二、技术限制

### 2.1 模型限制

```yaml
model_limits:
  # Token限制
  token:
    input_max: 128000           # 最大输入Token
    output_max: 4096            # 最大输出Token
    context_window: 128000      # 上下文窗口
  
  # 并发限制
  concurrency:
    requests_per_second: 10     # 每秒请求数
    concurrent_chats: 5         # 并发对话数
  
  # 响应限制
  response:
    timeout: 60                 # 超时时间(秒)
    stream_timeout: 300         # 流式超时(秒)
```

### 2.2 工作流限制

```yaml
workflow_limits:
  # 节点限制
  nodes:
    max_count: 50               # 最大节点数
    max_depth: 10               # 最大嵌套深度
  
  # 执行限制
  execution:
    max_duration: 300           # 最大执行时间(秒)
    max_iterations: 1000        # 循环最大迭代次数
  
  # 变量限制
  variables:
    max_count: 100              # 最大变量数
    max_size: "1MB"             # 单变量最大大小
```

### 2.3 知识库限制

```yaml
knowledge_base_limits:
  # 检索限制
  retrieval:
    max_results: 20             # 最大返回结果数
    query_length: 1000          # 查询最大长度
  
  # 文档限制
  document:
    max_pages: 500              # PDF最大页数
    max_chars: 1000000          # 单文档最大字符数
  
  # 更新限制
  update:
    batch_size: 100             # 批量操作数量
    sync_interval: 3600         # 同步间隔(秒)
```

---

## 三、限制规避方法

### 3.1 对话次数限制

#### 问题
```yaml
problem:
  limit: "免费版每日100次对话"
  impact: "无法满足高频使用需求"
```

#### 规避方案

```yaml
solutions:
  # 方案1: 升级套餐
  upgrade:
    action: "升级到专业版或企业版"
    benefit: "大幅提升对话次数"
    cost: "付费"
  
  # 方案2: 多Bot分流
  multi_bot:
    action: "创建多个Bot分散流量"
    benefit: "成倍增加对话次数"
    limit: "免费版最多5个Bot = 500次/天"
    implementation: |
      1. 创建多个功能相似的Bot
      2. 实现负载均衡逻辑
      3. 根据使用量动态切换
  
  # 方案3: 缓存策略
  caching:
    action: "缓存常见问题答案"
    benefit: "减少实际对话次数"
    implementation: |
      1. 识别高频问题
      2. 建立本地缓存
      3. 缓存命中直接返回
      4. 未命中再调用API
  
  # 方案4: 混合部署
  hybrid:
    action: "扣子+自建服务混合"
    benefit: "突破平台限制"
    implementation: |
      1. 核心功能用扣子
      2. 高频功能自建
      3. 智能路由选择
```

### 3.2 知识库容量限制

#### 问题
```yaml
problem:
  limit: "免费版100MB知识库容量"
  impact: "无法存储大量文档"
```

#### 规避方案

```yaml
solutions:
  # 方案1: 文档压缩
  compression:
    action: "压缩文档内容"
    methods:
      - 移除图片和格式
      - 提取关键信息
      - 文本压缩算法
    benefit: "减少50-80%容量"
  
  # 方案2: 分库存储
  multi_kb:
    action: "创建多个知识库"
    benefit: "总容量 = 单库容量 × 库数量"
    implementation: |
      1. 按主题拆分知识库
      2. 根据问题类型选择知识库
      3. 合并检索结果
  
  # 方案3: 外部知识源
  external:
    action: "使用外部知识源"
    options:
      - 数据库直连
      - API实时获取
      - 搜索引擎检索
    benefit: "不受平台容量限制"
  
  # 方案4: 按需加载
  lazy_loading:
    action: "按需加载知识"
    implementation: |
      1. 只存储索引信息
      2. 实际内容存外部
      3. 检索时动态获取
```

### 3.3 工作流节点限制

#### 问题
```yaml
problem:
  limit: "免费版每工作流20个节点"
  impact: "无法实现复杂流程"
```

#### 规避方案

```yaml
solutions:
  # 方案1: 子工作流拆分
  subworkflow:
    action: "拆分为多个子工作流"
    benefit: "突破单工作流节点限制"
    implementation: |
      1. 识别独立功能模块
      2. 创建子工作流
      3. 主工作流调用子工作流
  
  # 方案2: 节点合并
  merge_nodes:
    action: "合并相似节点"
    methods:
      - 合并多个LLM节点为一个
      - 使用代码节点替代多节点
      - 条件判断合并
    benefit: "减少节点数量"
  
  # 方案3: 外部编排
  external_orchestration:
    action: "外部系统编排"
    implementation: |
      1. 扣子工作流作为原子操作
      2. 外部系统负责编排
      3. 通过API调用工作流
    benefit: "无节点数量限制"
```

### 3.4 API调用限制

#### 问题
```yaml
problem:
  limit: "免费版每日1000次API调用"
  impact: "无法支撑高并发应用"
```

#### 规避方案

```yaml
solutions:
  # 方案1: 批量请求
  batch:
    action: "合并多个请求为批量请求"
    benefit: "减少API调用次数"
    implementation: |
      1. 收集多个请求
      2. 批量发送
      3. 分发响应
  
  # 方案2: 智能缓存
  cache:
    action: "缓存API响应"
    config:
      ttl: 3600               # 缓存时间
      strategy: "LRU"         # 缓存策略
    benefit: "大幅减少重复调用"
  
  # 方案3: 降级方案
  fallback:
    action: "超限后降级处理"
    implementation: |
      1. 监控API调用量
      2. 接近限制时预警
      3. 超限后使用备用方案
      4. 如: 返回缓存结果、简化响应
  
  # 方案4: 多账号分流
  multi_account:
    action: "使用多个账号"
    benefit: "成倍增加调用次数"
    attention: "需遵守平台规则"
```

### 3.5 模型Token限制

#### 问题
```yaml
problem:
  limit: "单次对话128K Token"
  impact: "无法处理超长文档"
```

#### 规避方案

```yaml
solutions:
  # 方案1: 文档分段
  chunking:
    action: "分段处理长文档"
    implementation: |
      1. 将文档分段
      2. 逐段处理
      3. 合并结果
    benefit: "突破Token限制"
  
  # 方案2: 摘要压缩
  summarization:
    action: "先摘要再处理"
    implementation: |
      1. 对长文档生成摘要
      2. 基于摘要进行处理
      3. 需要时再获取原文
    benefit: "大幅减少Token使用"
  
  # 方案3: 检索增强
  rag:
    action: "检索增强生成"
    implementation: |
      1. 建立向量索引
      2. 检索相关片段
      3. 只传递相关内容
    benefit: "只使用必要Token"
  
  # 方案4: 选择性加载
  selective:
    action: "按需加载内容"
    implementation: |
      1. 分析用户问题
      2. 确定需要的内容范围
      3. 只加载相关部分
```

---

## 四、功能限制规避

### 4.1 发布渠道限制

```yaml
problem:
  limit: "免费版只能API发布"
  impact: "无法直接接入微信、飞书等"

solutions:
  # 方案1: 自建接入层
  self_built:
    action: "自建消息接入层"
    implementation: |
      1. 开发微信/飞书消息接收服务
      2. 调用扣子API处理
      3. 返回处理结果
    benefit: "突破渠道限制"
  
  # 方案2: 使用企业版
  enterprise:
    action: "升级企业版"
    benefit: "支持所有渠道"
```

### 4.2 私有化部署限制

```yaml
problem:
  limit: "免费版/专业版不支持私有化"
  impact: "数据安全要求高的场景无法使用"

solutions:
  # 方案1: 企业版
  enterprise:
    action: "购买企业版"
    benefit: "支持私有化部署"
  
  # 方案2: 混合架构
  hybrid:
    action: "敏感数据本地处理"
    implementation: |
      1. 敏感数据本地处理
      2. 非敏感数据用扣子
      3. 数据脱敏后上传
  
  # 方案3: 开源替代
  open_source:
    action: "使用开源替代方案"
    options:
      - Dify
      - FastGPT
      - LangChain
    benefit: "完全自主可控"
```

---

## 五、性能优化

### 5.1 响应速度优化

```yaml
optimization:
  # 减少延迟
  reduce_latency:
    - 使用更快的模型
    - 减少知识库检索数量
    - 优化工作流节点数
    - 启用缓存
  
  # 并行处理
  parallel:
    - 识别可并行节点
    - 使用并行执行
    - 异步处理非关键步骤
  
  # 预处理
  preprocessing:
    - 预计算常见结果
    - 预加载常用知识
    - 预生成模板响应
```

### 5.2 资源使用优化

```yaml
resource_optimization:
  # Token优化
  token:
    - 精简提示词
    - 使用更短的示例
    - 按需加载知识
  
  # 存储优化
  storage:
    - 定期清理无用数据
    - 压缩存储内容
    - 归档历史数据
  
  # 计算优化
  compute:
    - 复用计算结果
    - 延迟计算
    - 批量处理
```

---

## 六、监控与告警

### 6.1 使用量监控

```python
class UsageMonitor:
    """使用量监控"""
    
    def __init__(self, limits):
        self.limits = limits
        self.usage = {
            "conversations": 0,
            "api_calls": 0,
            "workflow_executions": 0
        }
    
    def track(self, metric, increment=1):
        """跟踪使用量"""
        self.usage[metric] += increment
        
        # 检查是否接近限制
        percentage = self.usage[metric] / self.limits[metric] * 100
        if percentage >= 80:
            self.alert(f"{metric} 使用量已达 {percentage:.1f}%")
    
    def alert(self, message):
        """发送告警"""
        # 发送告警通知
        print(f"⚠️ 告警: {message}")
```

### 6.2 自动降级

```python
class AutoFallback:
    """自动降级"""
    
    def __init__(self, primary, fallback, limits):
        self.primary = primary
        self.fallback = fallback
        self.limits = limits
        self.usage = 0
    
    def call(self, *args, **kwargs):
        """智能调用"""
        # 检查是否超限
        if self.usage >= self.limits["daily"] * 0.9:
            # 使用降级方案
            return self.fallback(*args, **kwargs)
        
        # 正常调用
        self.usage += 1
        return self.primary(*args, **kwargs)
```

---

## 七、最佳实践

### 7.1 限制管理策略

```yaml
limit_management:
  # 监控先行
  monitor_first:
    - 实时监控使用量
    - 设置预警阈值
    - 提前规划扩容
  
  # 多级预案
  multi_level_plan:
    - Level 1: 优化使用
    - Level 2: 缓存降级
    - Level 3: 多账号分流
    - Level 4: 升级套餐
  
  # 成本优化
  cost_optimization:
    - 识别高消耗操作
    - 优化高频操作
    - 合理使用免费额度
```

### 7.2 规避原则

```markdown
✅ 合理规避:
- 优化使用效率
- 使用平台提供的机制
- 合理配置资源

❌ 避免行为:
- 恶意绕过限制
- 滥用多账号
- 违反服务条款
```

---

## 八、总结

扣子平台限制与规避：

- ✅ **了解限制**: 清楚各项限制条件
- ✅ **合理规避**: 在规则范围内优化
- ✅ **监控预警**: 实时监控使用情况
- ✅ **降级预案**: 准备好降级方案

关键原则：
1. 先优化，再扩容
2. 监控先行，预警及时
3. 合规使用，避免违规
4. 成本效益，平衡投入