# 工作流编排能力详解

> 更新时间: 2026-05-09

---

## 一、工作流概述

### 1.1 什么是工作流

工作流(Workflow)是扣子平台的可视化流程编排工具，通过拖拽节点的方式构建自动化流程。

```
工作流 = 节点 + 连线 + 变量
```

### 1.2 工作流特点

```yaml
features:
  - 可视化编排        # 拖拽式设计
  - 节点丰富          # 20+内置节点
  - 变量传递          # 节点间数据流转
  - 条件分支          # If-Else逻辑
  - 循环处理          # 迭代执行
  - 错误处理          # 异常捕获
  - 调试工具          # 实时调试
  - 版本管理          # 多版本控制
```

### 1.3 应用场景

```
工作流典型场景:
┌─────────────────────────────────────────────────────────┐
│  📊 数据处理流程                                         │
│     数据获取 → 清洗 → 分析 → 可视化 → 报告生成           │
│                                                          │
│  🤖 智能客服流程                                         │
│     意图识别 → 知识检索 → 答案生成 → 满意度调查          │
│                                                          │
│  📝 内容生成流程                                         │
│     主题分析 → 大纲生成 → 内容撰写 → 审核修改            │
│                                                          │
│  🔔 自动化通知流程                                       │
│     定时触发 → 数据检查 → 条件判断 → 消息推送            │
└─────────────────────────────────────────────────────────┘
```

---

## 二、节点类型详解

### 2.1 开始节点 (Start)

```yaml
node:
  type: "start"
  name: "开始"
  description: "工作流入口，定义输入参数"
  
  # 输入参数定义
  inputs:
    - name: "user_query"
      type: "string"
      required: true
      description: "用户问题"
    
    - name: "user_id"
      type: "string"
      required: false
      description: "用户ID"
  
  # 输出
  outputs:
    - "{{start.user_query}}"
    - "{{start.user_id}}"
```

### 2.2 LLM节点 (大模型调用)

```yaml
node:
  type: "llm"
  name: "LLM处理"
  description: "调用大语言模型"
  
  # 模型配置
  config:
    model: "doubao-pro-32k"
    temperature: 0.7
    max_tokens: 2000
  
  # 提示词模板
  prompt: |
    你是一个专业的客服助手。
    
    用户问题: {{start.user_query}}
    
    请根据以下知识库内容回答:
    {{knowledge.result}}
    
    回答要求:
    1. 准确回答用户问题
    2. 语气友好专业
    3. 如果不确定，诚实告知
  
  # 输出
  outputs:
    - name: "response"
      type: "string"
```

### 2.3 知识库节点 (知识检索)

```yaml
node:
  type: "knowledge"
  name: "知识检索"
  description: "从知识库检索相关信息"
  
  # 知识库配置
  config:
    knowledge_base_id: "kb_123456"
    retrieval_mode: "hybrid"  # keyword/semantic/hybrid
    top_k: 5
    score_threshold: 0.7
  
  # 查询输入
  query: "{{start.user_query}}"
  
  # 输出
  outputs:
    - name: "result"
      type: "array"
      description: "检索结果列表"
    - name: "context"
      type: "string"
      description: "拼接后的上下文"
```

### 2.4 条件节点 (If-Else)

```yaml
node:
  type: "condition"
  name: "条件判断"
  description: "根据条件分支执行"
  
  # 条件表达式
  conditions:
    - id: "branch_1"
      expression: "{{intent.type}} == 'order_query'"
      label: "订单查询"
    
    - id: "branch_2"
      expression: "{{intent.type}} == 'refund'"
      label: "退款申请"
    
    - id: "branch_else"
      expression: "default"
      label: "其他"
  
  # 分支连接
  branches:
    branch_1: "order_workflow"
    branch_2: "refund_workflow"
    branch_else: "general_qa"
```

### 2.5 循环节点 (Loop)

```yaml
node:
  type: "loop"
  name: "循环处理"
  description: "迭代处理数组数据"
  
  # 循环配置
  config:
    iterate_over: "{{data.items}}"  # 要遍历的数组
    item_name: "item"                # 循环变量名
    index_name: "index"              # 索引变量名
    max_iterations: 100              # 最大迭代次数
  
  # 循环体（子节点）
  body:
    - type: "llm"
      prompt: "处理第{{index}}项: {{item}}"
    
    - type: "code"
      code: |
        result = process_item(item)
        return result
  
  # 输出
  outputs:
    - name: "results"
      type: "array"
      description: "所有迭代结果"
```

### 2.6 代码节点 (Code Execution)

```yaml
node:
  type: "code"
  name: "代码执行"
  description: "运行Python/JavaScript代码"
  
  # 语言选择
  language: "python"  # python/javascript
  
  # 代码内容
  code: |
    import json
    from datetime import datetime
    
    # 获取输入
    user_query = "{{start.user_query}}"
    
    # 处理逻辑
    result = {
        "query": user_query,
        "timestamp": datetime.now().isoformat(),
        "length": len(user_query)
    }
    
    # 返回结果
    return json.dumps(result, ensure_ascii=False)
  
  # 输入变量
  inputs:
    user_query: "{{start.user_query}}"
  
  # 输出
  outputs:
    - name: "result"
      type: "object"
```

### 2.7 HTTP节点 (API调用)

```yaml
node:
  type: "http"
  name: "API调用"
  description: "发送HTTP请求"
  
  # 请求配置
  config:
    method: "POST"
    url: "https://api.example.com/v1/process"
    timeout: 30
  
  # 请求头
  headers:
    Content-Type: "application/json"
    Authorization: "Bearer ${API_KEY}"
  
  # 请求体
  body:
    query: "{{start.user_query}}"
    user_id: "{{start.user_id}}"
  
  # 响应处理
  response:
    path: "$.data.result"  # JSONPath提取
    variable: "api_result"
  
  # 错误处理
  error_handling:
    retry: 3
    fallback: "默认响应"
```

### 2.8 插件节点 (Plugin)

```yaml
node:
  type: "plugin"
  name: "插件调用"
  description: "调用已安装的插件"
  
  # 插件配置
  plugin_id: "weather_plugin"
  action: "get_weather"
  
  # 输入参数
  params:
    city: "{{start.city}}"
    units: "metric"
  
  # 输出
  outputs:
    - name: "weather_info"
      type: "object"
```

### 2.9 工具节点 (Tool)

```yaml
node:
  type: "tool"
  name: "内置工具"
  description: "使用平台内置工具"
  
  # 工具选择
  tool: "text_splitter"  # 文本分割工具
  
  # 工具参数
  params:
    text: "{{document.content}}"
    chunk_size: 500
    overlap: 50
  
  # 输出
  outputs:
    - name: "chunks"
      type: "array"
```

### 2.10 子工作流节点 (Subworkflow)

```yaml
node:
  type: "subworkflow"
  name: "子工作流"
  description: "调用其他工作流"
  
  # 工作流配置
  workflow_id: "wf_report_generation"
  
  # 输入映射
  input_mapping:
    data: "{{start.data}}"
    template: "{{start.template}}"
  
  # 输出映射
  output_mapping:
    report: "{{subworkflow.report}}"
```

### 2.11 变量节点 (Variable)

```yaml
node:
  type: "variable"
  name: "变量设置"
  description: "设置或修改变量"
  
  # 变量操作
  operations:
    - action: "set"
      name: "processed_count"
      value: 0
    
    - action: "increment"
      name: "processed_count"
      value: 1
    
    - action: "append"
      name: "result_list"
      value: "{{item}}"
```

### 2.12 消息节点 (Message)

```yaml
node:
  type: "message"
  name: "发送消息"
  description: "向用户发送消息"
  
  # 消息配置
  message_type: "text"  # text/image/card
  
  # 文本消息
  content: |
    处理完成！
    
    结果: {{result.summary}}
    
    如需详细报告，请回复"详细报告"。
  
  # 卡片消息
  card:
    title: "处理结果"
    content: "{{result.summary}}"
    buttons:
      - text: "查看详情"
        action: "show_detail"
```

### 2.13 结束节点 (End)

```yaml
node:
  type: "end"
  name: "结束"
  description: "工作流出口，定义输出结果"
  
  # 输出定义
  outputs:
    - name: "response"
      value: "{{llm.response}}"
    
    - name: "sources"
      value: "{{knowledge.result}}"
    
    - name: "metadata"
      value:
        processing_time: "{{workflow.duration}}"
        node_count: "{{workflow.node_count}}"
```

---

## 三、变量系统

### 3.1 变量类型

```yaml
variable_types:
  # 基础类型
  - string          # 字符串
  - number          # 数字
  - boolean         # 布尔值
  - array           # 数组
  - object          # 对象
  
  # 特殊类型
  - file            # 文件
  - image           # 图片
  - any             # 任意类型
```

### 3.2 变量作用域

```yaml
variable_scopes:
  # 全局变量
  global:
    - "{{env.API_KEY}}"        # 环境变量
    - "{{config.model}}"       # 配置变量
  
  # 工作流变量
  workflow:
    - "{{workflow.id}}"        # 工作流ID
    - "{{workflow.duration}}"  # 执行时长
  
  # 节点变量
  node:
    - "{{start.user_query}}"   # 开始节点输出
    - "{{llm.response}}"       # LLM节点输出
    - "{{code.result}}"        # 代码节点输出
  
  # 循环变量
  loop:
    - "{{item}}"               # 当前项
    - "{{index}}"              # 当前索引
```

### 3.3 变量表达式

```yaml
variable_expressions:
  # 简单引用
  simple: "{{node.output}}"
  
  # 属性访问
  property: "{{node.output.field}}"
  
  # 数组访问
  array: "{{node.output[0]}}"
  
  # 条件表达式
  condition: "{{node.value > 10 ? 'large' : 'small'}}"
  
  # 字符串拼接
  concat: "结果: {{node.result}}, 耗时: {{node.time}}ms"
  
  # 函数调用
  function: "{{upper(node.output)}}"
```

---

## 四、工作流示例

### 4.1 智能问答工作流

```yaml
workflow:
  name: "智能问答"
  description: "基于知识库的智能问答流程"
  
  nodes:
    # 1. 开始节点
    - id: "start"
      type: "start"
      inputs:
        - name: "question"
          type: "string"
          required: true
    
    # 2. 意图识别
    - id: "intent"
      type: "llm"
      prompt: |
        分析用户问题的意图，返回JSON格式:
        {"intent": "知识查询|闲聊|任务执行", "confidence": 0.9}
        
        问题: {{start.question}}
      outputs:
        intent: "object"
    
    # 3. 条件分支
    - id: "condition"
      type: "condition"
      conditions:
        - id: "knowledge"
          expression: "{{intent.intent}} == '知识查询'"
        - id: "chat"
          expression: "{{intent.intent}} == '闲聊'"
        - id: "task"
          expression: "default"
    
    # 4a. 知识检索分支
    - id: "knowledge_search"
      type: "knowledge"
      query: "{{start.question}}"
      outputs:
        context: "string"
    
    # 4b. 闲聊分支
    - id: "chat_response"
      type: "llm"
      prompt: "友好地回复用户: {{start.question}}"
    
    # 4c. 任务执行分支
    - id: "task_execute"
      type: "plugin"
      plugin_id: "task_plugin"
    
    # 5. 生成回答
    - id: "generate_answer"
      type: "llm"
      prompt: |
        基于以下信息回答用户问题:
        
        问题: {{start.question}}
        知识: {{knowledge_search.context}}
        
        请给出准确、友好的回答。
    
    # 6. 结束节点
    - id: "end"
      type: "end"
      outputs:
        answer: "{{generate_answer.response}}"
        sources: "{{knowledge_search.result}}"
  
  # 连线
  edges:
    - from: "start"
      to: "intent"
    - from: "intent"
      to: "condition"
    - from: "condition"
      to: "knowledge_search"
      condition: "knowledge"
    - from: "condition"
      to: "chat_response"
      condition: "chat"
    - from: "condition"
      to: "task_execute"
      condition: "task"
    - from: "knowledge_search"
      to: "generate_answer"
    - from: "chat_response"
      to: "end"
    - from: "task_execute"
      to: "end"
    - from: "generate_answer"
      to: "end"
```

### 4.2 数据分析工作流

```yaml
workflow:
  name: "数据分析报告"
  description: "自动分析数据并生成报告"
  
  nodes:
    # 1. 开始
    - id: "start"
      type: "start"
      inputs:
        - name: "data_file"
          type: "file"
        - name: "report_type"
          type: "string"
    
    # 2. 数据读取
    - id: "read_data"
      type: "code"
      language: "python"
      code: |
        import pandas as pd
        df = pd.read_csv("{{start.data_file}}")
        return {
            "shape": df.shape,
            "columns": df.columns.tolist(),
            "head": df.head().to_dict()
        }
    
    # 3. 数据分析
    - id: "analyze"
      type: "code"
      language: "python"
      code: |
        import pandas as pd
        import numpy as np
        
        # 统计分析
        stats = df.describe().to_dict()
        
        # 趋势分析
        # ...
        
        return {"stats": stats, "trends": trends}
    
    # 4. 生成图表
    - id: "charts"
      type: "code"
      language: "python"
      code: |
        import matplotlib.pyplot as plt
        
        # 生成多个图表
        charts = []
        # ...
        
        return {"charts": charts}
    
    # 5. 生成报告
    - id: "generate_report"
      type: "llm"
      prompt: |
        根据以下分析结果生成{{start.report_type}}:
        
        数据概览: {{read_data.result}}
        统计分析: {{analyze.stats}}
        趋势分析: {{analyze.trends}}
        
        请生成专业的分析报告。
    
    # 6. 结束
    - id: "end"
      type: "end"
      outputs:
        report: "{{generate_report.response}}"
        charts: "{{charts.charts}}"
```

---

## 五、高级特性

### 5.1 错误处理

```yaml
error_handling:
  # 节点级错误处理
  node_error:
    strategy: "retry"     # retry/fallback/skip
    retry_count: 3
    retry_delay: 1
    fallback_value: "处理失败"
  
  # 工作流级错误处理
  workflow_error:
    on_error:
      - type: "notification"
        message: "工作流执行失败: {{error.message}}"
      - type: "log"
        level: "error"
```

### 5.2 并行执行

```yaml
parallel_execution:
  # 并行节点
  parallel:
    - id: "parallel_1"
      branches:
        - branch_id: "branch_a"
          nodes: ["node_a1", "node_a2"]
        - branch_id: "branch_b"
          nodes: ["node_b1", "node_b2"]
        - branch_id: "branch_c"
          nodes: ["node_c1", "node_c2"]
      
      # 合并策略
      merge:
        type: "wait_all"   # wait_all/wait_any
```

### 5.3 异步执行

```yaml
async_execution:
  # 异步节点
  async_node:
    type: "http"
    url: "https://api.example.com/long-task"
    async: true
    
    # 回调配置
    callback:
      url: "https://your-server.com/callback"
      method: "POST"
```

---

## 六、调试与测试

### 6.1 调试工具

```yaml
debugging:
  # 断点调试
  breakpoints:
    - node_id: "llm_1"
      pause: true
  
  # 变量查看
  variable_inspector:
    enabled: true
    show_types: true
  
  # 执行日志
  execution_log:
    enabled: true
    level: "debug"
    include_timing: true
```

### 6.2 测试用例

```yaml
test_cases:
  - name: "测试正常流程"
    input:
      question: "什么是扣子平台？"
    expected_output:
      answer: "string"
      sources: "array"
  
  - name: "测试异常输入"
    input:
      question: ""
    expected_error: "INVALID_INPUT"
```

---

## 七、最佳实践

### 7.1 设计原则

```markdown
1. 模块化设计
   - 功能拆分为独立节点
   - 使用子工作流封装复杂逻辑

2. 错误处理
   - 每个关键节点添加错误处理
   - 提供降级方案

3. 性能优化
   - 减少不必要的节点
   - 使用并行执行
   - 缓存中间结果

4. 可维护性
   - 清晰的节点命名
   - 添加注释说明
   - 版本管理
```

### 7.2 性能优化

```yaml
optimization:
  # 减少LLM调用
  llm_optimization:
    - 合并多个LLM节点
    - 使用更短的提示词
    - 缓存常见问题答案
  
  # 并行处理
  parallelization:
    - 识别可并行的节点
    - 使用并行执行节点
  
  # 缓存策略
  caching:
    - 缓存知识库检索结果
    - 缓存API响应
```

---

## 八、总结

工作流是扣子平台的核心编排能力：

- ✅ **可视化设计**: 拖拽式流程编排
- ✅ **节点丰富**: 20+内置节点类型
- ✅ **灵活配置**: 变量、条件、循环
- ✅ **错误处理**: 完善的异常机制
- ✅ **调试工具**: 实时调试与测试

关键成功因素：
1. 清晰的流程设计
2. 合理的节点选择
3. 完善的错误处理
4. 充分的测试验证