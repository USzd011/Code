# Bot创建与配置详解

> 更新时间: 2026-05-09

---

## 一、Bot创建流程

### 1.1 创建入口

```
创建Bot的三种方式:
┌─────────────────────────────────────────┐
│  1. 从零创建 - 空白Bot，完全自定义        │
│  2. 使用模板 - 基于预设模板快速创建       │
│  3. AI生成 - 描述需求，AI自动生成Bot     │
└─────────────────────────────────────────┘
```

### 1.2 创建步骤

```
Step 1: 基本信息
├── Bot名称
├── Bot描述
├── Bot头像（可AI生成）
└── 所属空间

Step 2: 模型配置
├── 选择基础模型
├── 设置模型参数
└── 配置系统提示词

Step 3: 能力配置
├── 添加技能
├── 绑定知识库
├── 配置工作流
└── 安装插件

Step 4: 高级设置
├── 变量管理
├── 记忆配置
├── 开场白设置
└── 快捷指令

Step 5: 测试与发布
├── 预览测试
├── 调试优化
└── 发布上线
```

---

## 二、模型配置

### 2.1 支持的模型

#### 国内模型

| 模型 | 提供商 | 特点 | 适用场景 |
|------|--------|------|----------|
| 豆包大模型 | 字节跳动 | 平台默认 | 通用对话 |
| 云雀大模型 | 字节跳动 | 多模态 | 图文理解 |
| 通义千问 | 阿里巴巴 | 中文优化 | 中文场景 |
| 文心一言 | 百度 | 知识增强 | 知识问答 |
| 讯飞星火 | 科大讯飞 | 教育领域 | 教育场景 |
| 智谱GLM | 智谱AI | 长上下文 | 长文档 |
| Kimi | 月之暗面 | 超长上下文 | 超长文档 |

#### 国际模型

| 模型 | 提供商 | 特点 | 适用场景 |
|------|--------|------|----------|
| GPT-4 | OpenAI | 综合最强 | 复杂任务 |
| GPT-3.5 | OpenAI | 性价比高 | 通用对话 |
| Claude | Anthropic | 安全可靠 | 企业应用 |
| Gemini | Google | 多模态 | 图文理解 |

### 2.2 模型参数配置

```yaml
# 模型参数配置示例
model_config:
  # 基础参数
  model: "doubao-pro-32k"  # 模型选择
  temperature: 0.7         # 创造性 (0-1)
  top_p: 0.9              # 采样范围 (0-1)
  max_tokens: 4096        # 最大输出长度
  
  # 高级参数
  frequency_penalty: 0    # 频率惩罚
  presence_penalty: 0     # 存在惩罚
  stop_sequences: []      # 停止序列
  
  # 响应设置
  stream: true            # 流式输出
  timeout: 60             # 超时时间(秒)
```

### 2.3 系统提示词

#### 提示词结构

```markdown
# 角色定义
你是一个[角色名称]，专门负责[职责描述]。

# 核心能力
- 能力1: [描述]
- 能力2: [描述]
- 能力3: [描述]

# 行为准则
1. [规则1]
2. [规则2]
3. [规则3]

# 输出格式
[输出格式要求]

# 限制条件
- [限制1]
- [限制2]

# 示例对话
用户: [示例问题]
助手: [示例回答]
```

#### 提示词最佳实践

```markdown
✅ 好的提示词特征:
- 角色定位清晰
- 任务边界明确
- 输出格式规范
- 包含示例
- 有约束条件

❌ 避免的问题:
- 指令模糊
- 缺少边界
- 格式混乱
- 无示例参考
```

---

## 三、技能配置

### 3.1 内置技能

#### 联网搜索

```yaml
skill:
  name: "联网搜索"
  type: "search"
  config:
    search_engine: "bing"  # bing/google
    max_results: 5
    include_snippet: true
```

#### AI绘图

```yaml
skill:
  name: "AI绘图"
  type: "image_generation"
  config:
    model: "dall-e-3"
    size: "1024x1024"
    quality: "standard"  # standard/hd
    style: "vivid"       # vivid/natural
```

#### 代码执行

```yaml
skill:
  name: "代码执行"
  type: "code_execution"
  config:
    language: "python"
    timeout: 30
    sandbox: true
```

### 3.2 自定义技能

#### 创建步骤

```
1. 定义技能名称和描述
2. 配置输入参数
   ├── 参数名
   ├── 参数类型
   ├── 是否必填
   └── 默认值
3. 配置输出参数
4. 编写技能逻辑（工作流或代码）
5. 设置触发条件
6. 测试验证
```

#### 技能配置示例

```yaml
custom_skill:
  name: "数据分析"
  description: "分析数据并生成报告"
  
  inputs:
    - name: "data"
      type: "file"
      required: true
      description: "数据文件"
    - name: "analysis_type"
      type: "string"
      required: false
      default: "summary"
      enum: ["summary", "trend", "comparison"]
  
  outputs:
    - name: "report"
      type: "markdown"
    - name: "charts"
      type: "image[]"
  
  trigger:
    type: "keyword"
    keywords: ["分析", "统计", "报告"]
```

---

## 四、知识库绑定

### 4.1 绑定方式

```
知识库绑定:
┌─────────────────────────────────────────┐
│  方式1: 创建新知识库                     │
│  方式2: 选择已有知识库                   │
│  方式3: 导入外部知识库                   │
└─────────────────────────────────────────┘
```

### 4.2 检索配置

```yaml
knowledge_config:
  # 检索方式
  retrieval_mode: "hybrid"  # keyword/semantic/hybrid
  
  # 检索参数
  top_k: 5                  # 返回结果数
  score_threshold: 0.7      # 相似度阈值
  
  # 分段设置
  chunk_size: 500           # 分段大小
  chunk_overlap: 50         # 分段重叠
  
  # 重排序
  rerank: true              # 启用重排序
  rerank_model: "bge-rerank"
```

### 4.3 知识库优先级

```
多个知识库时的优先级:
1. 按绑定顺序检索
2. 可设置权重
3. 可设置互斥关系
```

---

## 五、工作流集成

### 5.1 工作流调用方式

```yaml
# 在Bot中调用工作流
workflow_integration:
  # 方式1: 自动触发
  trigger:
    type: "intent"
    intent_detection: true
  
  # 方式2: 技能调用
  as_skill:
    name: "工作流技能"
    description: "调用工作流处理"
  
  # 方式3: 条件触发
  condition:
    when: "user_input contains '报表'"
    call: "report_workflow"
```

### 5.2 参数传递

```yaml
# Bot变量 -> 工作流
input_mapping:
  workflow_input: "{{bot.user_input}}"
  user_id: "{{bot.user_id}}"
  
# 工作流输出 -> Bot响应
output_mapping:
  bot_response: "{{workflow.result}}"
```

---

## 六、插件配置

### 6.1 插件安装

```
插件安装流程:
1. 进入插件市场
2. 搜索/浏览插件
3. 查看插件详情
4. 点击安装
5. 配置授权
6. 启用插件
```

### 6.2 插件配置

```yaml
plugin_config:
  name: "天气查询"
  enabled: true
  
  # 授权配置
  auth:
    type: "api_key"
    api_key: "${WEATHER_API_KEY}"
  
  # 参数配置
  params:
    default_location: "北京"
    unit: "celsius"
    language: "zh"
  
  # 调用限制
  rate_limit:
    max_calls_per_day: 100
    timeout: 10
```

### 6.3 自定义插件

```yaml
custom_plugin:
  name: "企业内部API"
  description: "调用企业内部系统"
  
  # API配置
  api:
    base_url: "https://api.company.com"
    auth:
      type: "bearer"
      token: "${COMPANY_TOKEN}"
  
  # 接口定义
  endpoints:
    - name: "查询订单"
      method: "GET"
      path: "/orders/{order_id}"
      params:
        - name: "order_id"
          in: "path"
          required: true
```

---

## 七、高级设置

### 7.1 变量管理

```yaml
variables:
  # 系统变量（内置）
  system:
    - "{{user_id}}"        # 用户ID
    - "{{conversation_id}}" # 对话ID
    - "{{current_time}}"   # 当前时间
  
  # 自定义变量
  custom:
    - name: "user_name"
      type: "string"
      default: "用户"
    - name: "user_role"
      type: "string"
      default: "guest"
      enum: ["guest", "member", "admin"]
  
  # 动态变量（从API获取）
  dynamic:
    - name: "user_info"
      source: "api"
      url: "https://api.example.com/user/{{user_id}}"
```

### 7.2 记忆配置

```yaml
memory_config:
  # 短期记忆（对话内）
  short_term:
    enabled: true
    max_turns: 20          # 最大轮次
    summary_threshold: 10  # 摘要触发阈值
  
  # 长期记忆（跨对话）
  long_term:
    enabled: true
    storage: "vector_db"   # 存储方式
    retention_days: 30     # 保留天数
  
  # 记忆检索
  retrieval:
    enabled: true
    top_k: 5
    include_context: true
```

### 7.3 开场白设置

```yaml
greeting:
  # 文本开场白
  text: |
    你好！我是{{bot_name}}，很高兴为你服务。
    我可以帮你：
    - 📝 撰写文档
    - 🔍 搜索信息
    - 📊 分析数据
    
    请问有什么可以帮你的？
  
  # 快捷问题
  quick_questions:
    - "帮我写一份周报"
    - "搜索最新的AI新闻"
    - "分析这份Excel数据"
```

### 7.4 快捷指令

```yaml
shortcuts:
  - name: "日报"
    trigger: "/日报"
    action:
      type: "workflow"
      workflow: "daily_report"
      
  - name: "翻译"
    trigger: "/翻译"
    action:
      type: "skill"
      skill: "translate"
      params:
        target_lang: "en"
```

---

## 八、测试与调试

### 8.1 预览测试

```
测试功能:
┌─────────────────────────────────────────┐
│  ✅ 实时对话测试                         │
│  ✅ 技能调用测试                         │
│  ✅ 工作流调试                           │
│  ✅ 知识库检索测试                       │
│  ✅ 变量查看                             │
│  ✅ 日志追踪                             │
└─────────────────────────────────────────┘
```

### 8.2 调试技巧

```markdown
1. 分模块测试
   - 先测试基础对话
   - 再测试技能调用
   - 最后测试完整流程

2. 日志分析
   - 查看调用链路
   - 检查参数传递
   - 分析错误原因

3. 变量检查
   - 确认变量值
   - 检查变量类型
   - 验证变量传递

4. 性能优化
   - 减少不必要的调用
   - 优化提示词长度
   - 调整检索参数
```

---

## 九、发布配置

### 9.1 发布前检查

```yaml
publish_checklist:
  - [ ] 基础信息完整
  - [ ] 模型配置正确
  - [ ] 技能测试通过
  - [ ] 知识库检索正常
  - [ ] 工作流执行成功
  - [ ] 插件授权完成
  - [ ] 开场白设置
  - [ ] 隐私合规检查
```

### 9.2 版本管理

```yaml
version_config:
  # 版本号
  version: "1.0.0"
  
  # 发布说明
  changelog: |
    - 初始版本
    - 支持基础对话
    - 集成知识库
  
  # 发布渠道
  channels:
    - api
    - wechat
    - feishu
```

### 9.3 灰度发布

```yaml
gray_publish:
  enabled: true
  strategy: "percentage"  # percentage/user_list
  
  # 按比例灰度
  percentage: 10          # 10%用户
  
  # 或按用户列表
  user_list:
    - "user_001"
    - "user_002"
  
  # 监控指标
  metrics:
    - "success_rate"
    - "latency_p99"
    - "user_feedback"
```

---

## 十、最佳实践

### 10.1 Bot设计原则

```markdown
1. 单一职责
   - 一个Bot专注一个领域
   - 避免功能过于复杂

2. 用户体验
   - 开场白友好
   - 响应及时
   - 错误提示清晰

3. 可维护性
   - 提示词结构化
   - 技能模块化
   - 变量命名规范

4. 安全性
   - 敏感信息保护
   - 访问权限控制
   - 输入验证
```

### 10.2 常见问题

```markdown
Q: Bot响应慢怎么办？
A: 
- 减少知识库检索数量
- 优化工作流节点
- 使用更快的模型
- 启用缓存

Q: 如何提高回答质量？
A:
- 优化提示词
- 增强知识库质量
- 调整检索参数
- 添加示例对话

Q: 如何处理错误？
A:
- 设置错误处理节点
- 添加重试机制
- 提供降级方案
- 记录错误日志
```

---

## 十一、总结

Bot创建是扣子平台的核心功能，通过合理配置可以实现：

- ✅ 智能对话
- ✅ 知识问答
- ✅ 技能调用
- ✅ 工作流自动化
- ✅ 多渠道发布

关键成功因素：
1. 清晰的角色定位
2. 完善的知识库
3. 合理的技能配置
4. 优秀的用户体验