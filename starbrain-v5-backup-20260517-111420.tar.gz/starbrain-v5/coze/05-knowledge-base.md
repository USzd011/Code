# 知识库管理机制

> 更新时间: 2026-05-09

---

## 一、知识库概述

### 1.1 什么是知识库

知识库(Knowledge Base)是扣子平台的知识存储与检索系统，用于增强Bot的专业知识能力。

```
知识库 = 数据源 + 向量化 + 检索引擎
```

### 1.2 知识库作用

```yaml
knowledge_base_benefits:
  - 专业领域知识增强    # 注入专业知识
  - 实时信息更新        # 动态更新内容
  - 减少幻觉            # 基于事实回答
  - 可追溯来源          # 引用知识来源
  - 企业知识沉淀        # 积累企业知识
```

### 1.3 知识库类型

```
扣子知识库类型:
┌─────────────────────────────────────────────────────────┐
│  📄 文档知识库                                           │
│     上传PDF/Word/TXT/Markdown等文档                      │
│                                                          │
│  🌐 网页知识库                                           │
│     抓取指定网页内容                                      │
│                                                          │
│  🔗 在线数据知识库                                       │
│     对接API接口获取数据                                   │
│                                                          │
│  🗄️ 数据库知识库                                         │
│     直连MySQL/PostgreSQL等数据库                         │
│                                                          │
│  📊 表格知识库                                           │
│     Excel/CSV结构化数据                                   │
│                                                          │
│  🔄 飞书/Notion知识库                                    │
│     对接飞书/Notion文档                                   │
└─────────────────────────────────────────────────────────┘
```

---

## 二、知识库创建

### 2.1 文档知识库

#### 创建步骤

```yaml
steps:
  1. 创建知识库
     - 名称: "产品手册"
     - 描述: "公司产品使用手册"
     - 类型: "文档"
  
  2. 上传文档
     - 支持格式: PDF/Word/TXT/Markdown
     - 单文件大小: 最大50MB
     - 总容量: 根据套餐限制
  
  3. 文档处理
     - 自动分段
     - 向量化
     - 建立索引
  
  4. 配置检索
     - 检索模式
     - 检索参数
     - 重排序设置
```

#### 文档处理配置

```yaml
document_processing:
  # 分段设置
  chunking:
    strategy: "auto"        # auto/custom
    chunk_size: 500         # 分段大小(字符)
    chunk_overlap: 50       # 分段重叠
    separator: "\n\n"       # 分段分隔符
  
  # 预处理
  preprocessing:
    remove_headers: true    # 移除页眉页脚
    remove_images: false    # 是否移除图片
    ocr_enabled: true       # OCR识别
    table_extraction: true  # 表格提取
  
  # 向量化
  vectorization:
    model: "text-embedding-3"
    dimension: 1536
    batch_size: 100
```

### 2.2 网页知识库

```yaml
web_knowledge_base:
  # 网址配置
  urls:
    - "https://docs.example.com/guide"
    - "https://docs.example.com/api"
  
  # 抓取配置
  crawling:
    depth: 2                # 抓取深度
    max_pages: 100          # 最大页面数
    follow_links: true      # 跟随链接
    respect_robots: true    # 遵守robots.txt
  
  # 更新频率
  update:
    frequency: "daily"      # daily/weekly/manual
    time: "02:00"           # 更新时间
```

### 2.3 数据库知识库

```yaml
database_knowledge_base:
  # 数据库连接
  connection:
    type: "mysql"           # mysql/postgresql/mongodb
    host: "db.example.com"
    port: 3306
    database: "knowledge_db"
    username: "${DB_USER}"
    password: "${DB_PASSWORD}"
  
  # 数据同步
  sync:
    tables:
      - name: "products"
        columns: ["id", "name", "description", "category"]
        where: "status = 'active'"
      
      - name: "faq"
        columns: ["question", "answer", "category"]
    
    schedule: "0 */6 * * *"  # 每6小时同步
```

### 2.4 API知识库

```yaml
api_knowledge_base:
  # API配置
  api:
    method: "GET"
    url: "https://api.example.com/knowledge"
    
    headers:
      Authorization: "Bearer ${API_KEY}"
    
    params:
      category: "all"
      limit: 1000
  
  # 数据映射
  mapping:
    id: "$.data[*].id"
    title: "$.data[*].title"
    content: "$.data[*].content"
  
  # 更新配置
  update:
    frequency: "hourly"
    incremental: true       # 增量更新
```

### 2.5 飞书知识库

```yaml
feishu_knowledge_base:
  # 飞书配置
  app_id: "${FEISHU_APP_ID}"
  app_secret: "${FEISHU_APP_SECRET}"
  
  # 文档选择
  sources:
    - type: "wiki"
      space_id: "wiki_123456"
    
    - type: "doc"
      doc_token: "docx_abcdef"
    
    - type: "sheet"
      sheet_token: "sheet_xyz"
  
  # 同步配置
  sync:
    frequency: "daily"
    include_comments: false
```

---

## 三、知识检索

### 3.1 检索模式

```yaml
retrieval_modes:
  # 关键词检索
  keyword:
    description: "基于关键词匹配"
    pros:
      - 精确匹配
      - 速度快
    cons:
      - 语义理解弱
      - 同义词问题
  
  # 语义检索
  semantic:
    description: "基于向量相似度"
    pros:
      - 语义理解强
      - 同义词支持
    cons:
      - 计算量大
      - 可能偏离关键词
  
  # 混合检索
  hybrid:
    description: "关键词+语义结合"
    pros:
      - 综合优势
      - 效果最佳
    cons:
      - 配置复杂
    recommended: true
```

### 3.2 检索参数

```yaml
retrieval_config:
  # 基础参数
  top_k: 5                  # 返回结果数
  score_threshold: 0.7      # 相似度阈值(0-1)
  
  # 混合检索权重
  hybrid_weights:
    keyword: 0.3            # 关键词权重
    semantic: 0.7           # 语义权重
  
  # 重排序
  rerank:
    enabled: true
    model: "bge-rerank-v2"
    top_n: 3                # 重排序后返回数
  
  # 上下文窗口
  context_window:
    before: 1               # 前文段数
    after: 1                # 后文段数
```

### 3.3 检索优化

```yaml
retrieval_optimization:
  # 查询优化
  query_optimization:
    expand_keywords: true   # 关键词扩展
    remove_stopwords: true  # 移除停用词
    synonym_expansion: true # 同义词扩展
  
  # 结果过滤
  result_filtering:
    by_metadata:
      - field: "category"
        values: ["产品", "服务"]
      - field: "date"
        range: "last_30_days"
  
  # 缓存策略
  caching:
    enabled: true
    ttl: 3600               # 缓存时间(秒)
    max_size: 1000          # 最大缓存数
```

---

## 四、知识库管理

### 4.1 文档管理

```yaml
document_management:
  # 文档操作
  operations:
    - upload                # 上传
    - update                # 更新
    - delete                # 删除
    - reindex               # 重建索引
  
  # 批量操作
  batch:
    max_files: 100          # 单次最大文件数
    supported_formats:
      - ".pdf"
      - ".docx"
      - ".txt"
      - ".md"
      - ".xlsx"
      - ".csv"
  
  # 版本控制
  versioning:
    enabled: true
    max_versions: 10        # 保留版本数
```

### 4.2 知识更新

```yaml
knowledge_update:
  # 自动更新
  auto_update:
    enabled: true
    schedule: "0 2 * * *"   # 每天凌晨2点
    notify_on_change: true
  
  # 增量更新
  incremental:
    enabled: true
    detect_changes: true    # 检测变更
    only_update_changed: true
  
  # 全量重建
  full_rebuild:
    trigger: "manual"       # manual/scheduled
    schedule: "0 3 1 * *"   # 每月1日凌晨3点
```

### 4.3 权限管理

```yaml
permission_management:
  # 访问权限
  access_control:
    public: false           # 是否公开
    allowed_users: []       # 允许的用户
    allowed_teams: []       # 允许的团队
  
  # 操作权限
  operation_permissions:
    view:
      - "owner"
      - "editor"
      - "viewer"
    edit:
      - "owner"
      - "editor"
    delete:
      - "owner"
    manage:
      - "owner"
```

---

## 五、知识库最佳实践

### 5.1 文档准备

```markdown
✅ 好的知识库文档特征:
1. 结构清晰
   - 有明确的标题层级
   - 段落划分合理
   - 使用列表和表格

2. 内容完整
   - 覆盖所有主题
   - 信息准确最新
   - 避免冗余重复

3. 格式规范
   - 统一的文档格式
   - 清晰的命名规范
   - 适当的元数据

❌ 避免的问题:
- 文档过于碎片化
- 内容过时未更新
- 格式混乱难解析
```

### 5.2 分段策略

```yaml
chunking_strategies:
  # 按段落分段
  paragraph:
    chunk_size: 500
    separator: "\n\n"
    best_for: "文章、博客"
  
  # 按章节分段
  section:
    chunk_size: 1000
    separator: "##"
    best_for: "技术文档、手册"
  
  # 按语义分段
  semantic:
    model: "semantic-chunker"
    best_for: "混合内容"
  
  # 按固定长度
  fixed:
    chunk_size: 500
    overlap: 50
    best_for: "无结构文本"
```

### 5.3 检索优化

```yaml
retrieval_best_practices:
  # 提高召回率
  improve_recall:
    - 增加top_k值
    - 降低score_threshold
    - 使用同义词扩展
    - 启用混合检索
  
  # 提高精确率
  improve_precision:
    - 提高score_threshold
    - 启用重排序
    - 添加元数据过滤
    - 优化查询表达
  
  # 提高响应速度
  improve_speed:
    - 减少top_k值
    - 启用缓存
    - 使用更快的向量模型
    - 优化索引
```

### 5.4 知识库维护

```yaml
maintenance_tasks:
  # 定期检查
  regular_checks:
    - frequency: "weekly"
      tasks:
        - 检查文档有效性
        - 清理过期内容
        - 更新统计数据
  
  # 质量监控
  quality_monitoring:
    metrics:
      - "检索命中率"
      - "用户满意度"
      - "知识覆盖率"
    
    alerts:
      - condition: "hit_rate < 70%"
        action: "发送告警"
  
  # 持续优化
  continuous_improvement:
    - 分析用户查询日志
    - 补充缺失知识
    - 优化检索参数
    - 更新过时内容
```

---

## 六、高级功能

### 6.1 多知识库协同

```yaml
multi_knowledge_base:
  # 知识库组
  group:
    name: "企业知识库"
    members:
      - id: "kb_product"
        name: "产品知识库"
        weight: 0.5
      
      - id: "kb_faq"
        name: "FAQ知识库"
        weight: 0.3
      
      - id: "kb_policy"
        name: "政策知识库"
        weight: 0.2
  
  # 检索策略
  strategy: "weighted"      # weighted/sequential/parallel
  
  # 结果合并
  merge:
    deduplicate: true
    sort_by: "score"
    max_results: 10
```

### 6.2 知识图谱

```yaml
knowledge_graph:
  # 实体抽取
  entity_extraction:
    enabled: true
    types: ["产品", "功能", "问题", "解决方案"]
  
  # 关系抽取
  relation_extraction:
    enabled: true
    types: ["属于", "相关", "解决", "依赖"]
  
  # 图谱应用
  applications:
    - 关联推荐
    - 知识导航
    - 智能问答
```

### 6.3 知识库API

```yaml
knowledge_base_api:
  # 搜索接口
  search:
    method: "POST"
    url: "/v1/knowledge/{kb_id}/search"
    body:
      query: "用户问题"
      top_k: 5
      filters: {}
  
  # 添加文档
  add_document:
    method: "POST"
    url: "/v1/knowledge/{kb_id}/documents"
    body:
      content: "文档内容"
      metadata: {}
  
  # 删除文档
  delete_document:
    method: "DELETE"
    url: "/v1/knowledge/{kb_id}/documents/{doc_id}"
```

---

## 七、常见问题

### 7.1 检索效果不佳

```markdown
问题: 知识库检索效果不好

诊断步骤:
1. 检查文档质量
   - 内容是否清晰
   - 格式是否规范

2. 检查分段设置
   - 分段大小是否合适
   - 是否有重要信息被截断

3. 检查检索参数
   - top_k是否足够
   - score_threshold是否过高

4. 检查查询表达
   - 用户查询是否准确
   - 是否需要查询改写

解决方案:
- 优化文档质量
- 调整分段参数
- 使用混合检索
- 启用重排序
```

### 7.2 知识库更新不及时

```markdown
问题: 知识库内容更新后，Bot回答仍是旧内容

原因:
- 索引未更新
- 缓存未清除
- 同步延迟

解决方案:
1. 手动触发重建索引
2. 清除检索缓存
3. 检查同步任务状态
4. 设置自动更新频率
```

### 7.3 知识库容量不足

```markdown
问题: 知识库达到容量上限

解决方案:
1. 清理无用文档
2. 压缩文档内容
3. 升级套餐
4. 拆分知识库
```

---

## 八、总结

知识库是扣子平台的核心能力之一：

- ✅ **多数据源支持**: 文档、网页、数据库、API
- ✅ **灵活检索**: 关键词、语义、混合检索
- ✅ **智能处理**: 自动分段、向量化、重排序
- ✅ **便捷管理**: 版本控制、权限管理、自动更新

关键成功因素：
1. 高质量的文档内容
2. 合理的分段策略
3. 优化的检索参数
4. 持续的知识维护