# 扣子平台最佳实践

> 更新时间: 2026-05-09

---

## 一、Bot设计最佳实践

### 1.1 角色定位清晰

```markdown
✅ 好的角色定义:
- 明确Bot的职责范围
- 清晰的能力边界
- 一致的人设风格

示例:
"你是一个专业的产品客服助手，专门负责解答产品使用问题。
你的职责是：
1. 解答产品功能问题
2. 处理使用故障
3. 收集用户反馈

你不能：
1. 处理退款事宜（转人工）
2. 承诺产品功能更新
3. 泄露用户隐私"

❌ 避免的问题:
- 角色定位模糊
- 职责范围过宽
- 人设不一致
```

### 1.2 提示词优化

```markdown
# 提示词结构模板

## 角色定义
你是一个[角色名称]，专门负责[职责]。

## 核心能力
- 能力1: [描述]
- 能力2: [描述]

## 行为准则
1. [规则1]
2. [规则2]

## 输出格式
[格式要求]

## 示例对话
用户: [示例问题]
助手: [示例回答]

## 限制条件
- [限制1]
- [限制2]
```

### 1.3 技能配置原则

```yaml
skill_best_practices:
  # 按需配置
  on_demand:
    - 只添加必要的技能
    - 避免技能冗余
    - 定期清理无用技能
  
  # 优先级管理
  priority:
    - 设置技能优先级
    - 避免技能冲突
    - 明确触发条件
  
  # 性能考虑
  performance:
    - 减少同步技能调用
    - 使用异步处理
    - 缓存技能结果
```

---

## 二、知识库最佳实践

### 2.1 文档准备

```markdown
✅ 高质量知识库文档:
1. 结构清晰
   - 明确的标题层级
   - 合理的段落划分
   - 使用列表和表格

2. 内容完整
   - 覆盖所有主题
   - 信息准确最新
   - 避免冗余重复

3. 格式规范
   - 统一的文档格式
   - 清晰的命名规范
   - 适当的元数据

示例文档结构:
# 产品使用手册

## 第一章 产品概述
### 1.1 产品简介
### 1.2 核心功能

## 第二章 快速开始
### 2.1 安装配置
### 2.2 基本操作

## 第三章 常见问题
### 3.1 功能问题
### 3.2 故障排除
```

### 2.2 分段策略

```yaml
chunking_best_practices:
  # 按内容类型选择
  by_content_type:
    article:
      strategy: "paragraph"
      chunk_size: 500
    
    technical_doc:
      strategy: "section"
      chunk_size: 1000
    
    faq:
      strategy: "qa_pair"
      chunk_size: 200
  
  # 重叠设置
  overlap:
    recommendation: "10-20% of chunk_size"
    purpose: "保持上下文连贯"
```

### 2.3 检索优化

```yaml
retrieval_optimization:
  # 混合检索
  hybrid_search:
    enabled: true
    keyword_weight: 0.3
    semantic_weight: 0.7
  
  # 重排序
  rerank:
    enabled: true
    model: "bge-rerank"
  
  # 结果过滤
  filtering:
    by_score: true
    threshold: 0.7
    by_metadata: true
```

---

## 三、工作流最佳实践

### 3.1 模块化设计

```yaml
modular_design:
  # 功能拆分
  decomposition:
    - 识别独立功能模块
    - 创建子工作流
    - 主工作流调用子工作流
  
  # 复用性
  reusability:
    - 设计通用工作流
    - 参数化配置
    - 避免硬编码
  
  # 示例
  example:
    main_workflow:
      name: "客户服务"
      nodes:
        - type: "subworkflow"
          name: "意图识别"
          workflow_id: "wf_intent"
        
        - type: "subworkflow"
          name: "知识检索"
          workflow_id: "wf_knowledge"
        
        - type: "subworkflow"
          name: "答案生成"
          workflow_id: "wf_answer"
```

### 3.2 错误处理

```yaml
error_handling:
  # 节点级错误处理
  node_level:
    - 设置超时时间
    - 配置重试策略
    - 提供降级方案
  
  # 工作流级错误处理
  workflow_level:
    - 全局异常捕获
    - 错误日志记录
    - 用户友好提示
  
  # 示例
  example:
    node:
      type: "http"
      timeout: 30
      retry:
        max_attempts: 3
        backoff: "exponential"
      fallback:
        action: "return_cached"
        value: "{{cache.result}}"
```

### 3.3 性能优化

```yaml
performance_optimization:
  # 减少节点
  reduce_nodes:
    - 合并相似节点
    - 使用代码节点替代多节点
    - 删除冗余节点
  
  # 并行执行
  parallel:
    - 识别可并行节点
    - 使用并行节点
    - 异步处理
  
  # 缓存策略
  caching:
    - 缓存LLM响应
    - 缓存知识库检索
    - 缓存API结果
```

---

## 四、API集成最佳实践

### 4.1 错误处理

```python
import time
from functools import wraps

def handle_api_error(max_retries=3, initial_delay=1, backoff=2):
    """API错误处理装饰器"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            delay = initial_delay
            
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except RateLimitError as e:
                    retries += 1
                    if retries >= max_retries:
                        raise
                    time.sleep(e.retry_after or delay)
                    delay *= backoff
                except APIError as e:
                    if e.code in [400, 401, 403]:
                        raise  # 客户端错误，不重试
                    retries += 1
                    if retries >= max_retries:
                        raise
                    time.sleep(delay)
                    delay *= backoff
            
        return wrapper
    return decorator

@handle_api_error(max_retries=3)
def call_api():
    # API调用
    pass
```

### 4.2 并发控制

```python
import asyncio
from asyncio import Semaphore

class ConcurrentAPI:
    """并发API调用"""
    
    def __init__(self, max_concurrent=10):
        self.semaphore = Semaphore(max_concurrent)
    
    async def call(self, request):
        async with self.semaphore:
            return await self._execute(request)
    
    async def batch_call(self, requests):
        tasks = [self.call(req) for req in requests]
        return await asyncio.gather(*tasks, return_exceptions=True)
```

### 4.3 缓存策略

```python
import hashlib
from functools import lru_cache
from datetime import datetime, timedelta

class APICache:
    """API响应缓存"""
    
    def __init__(self, ttl=3600):
        self.cache = {}
        self.ttl = ttl
    
    def get(self, key):
        """获取缓存"""
        if key in self.cache:
            value, timestamp = self.cache[key]
            if datetime.now() - timestamp < timedelta(seconds=self.ttl):
                return value
            else:
                del self.cache[key]
        return None
    
    def set(self, key, value):
        """设置缓存"""
        self.cache[key] = (value, datetime.now())
    
    def generate_key(self, *args, **kwargs):
        """生成缓存键"""
        content = str(args) + str(kwargs)
        return hashlib.md5(content.encode()).hexdigest()
```

---

## 五、安全最佳实践

### 5.1 API密钥管理

```yaml
api_key_management:
  # 不要硬编码
  no_hardcode:
    - 使用环境变量
    - 使用密钥管理服务
    - 定期轮换密钥
  
  # 权限最小化
  least_privilege:
    - 只授予必要权限
    - 使用只读密钥（如适用）
    - 定期审计权限
  
  # 示例
  example:
    # ❌ 错误
    api_key = "pat_xxxxxxxxxxxxxxxx"
    
    # ✅ 正确
    import os
    api_key = os.environ.get("COZE_API_KEY")
```

### 5.2 数据安全

```yaml
data_security:
  # 敏感数据处理
  sensitive_data:
    - 脱敏后上传
    - 加密传输
    - 本地处理敏感信息
  
  # 用户隐私
  privacy:
    - 最小化数据收集
    - 明确告知用户
    - 提供数据删除选项
  
  # 访问控制
  access_control:
    - 身份认证
    - 权限验证
    - 操作审计
```

### 5.3 输入验证

```python
def validate_input(user_input):
    """输入验证"""
    
    # 长度检查
    if len(user_input) > 10000:
        raise ValueError("输入过长")
    
    # 内容检查
    forbidden_patterns = ["<script>", "javascript:", "data:"]
    for pattern in forbidden_patterns:
        if pattern in user_input.lower():
            raise ValueError("包含禁止内容")
    
    # 格式检查
    if not isinstance(user_input, str):
        raise ValueError("输入格式错误")
    
    return user_input.strip()
```

---

## 六、运维最佳实践

### 6.1 监控告警

```yaml
monitoring:
  # 性能监控
  performance:
    metrics:
      - "响应时间"
      - "成功率"
      - "并发数"
    thresholds:
      response_time: "3s"
      success_rate: "95%"
  
  # 使用量监控
  usage:
    metrics:
      - "对话次数"
      - "API调用次数"
      - "Token使用量"
    thresholds:
      daily_limit: "80%"
  
  # 告警配置
  alerts:
    channels:
      - "邮件"
      - "短信"
      - "Webhook"
    rules:
      - condition: "success_rate < 90%"
        severity: "critical"
      - condition: "usage > 80%"
        severity: "warning"
```

### 6.2 日志管理

```python
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('coze_api.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('coze_api')

def log_api_call(bot_id, user_id, message, response, duration):
    """记录API调用"""
    logger.info({
        "timestamp": datetime.now().isoformat(),
        "bot_id": bot_id,
        "user_id": user_id,
        "message_length": len(message),
        "response_length": len(response),
        "duration_ms": duration,
        "success": True
    })
```

### 6.3 备份恢复

```yaml
backup:
  # 配置备份
  config_backup:
    frequency: "daily"
    retention: "30 days"
    items:
      - "Bot配置"
      - "工作流定义"
      - "技能配置"
  
  # 知识库备份
  knowledge_backup:
    frequency: "weekly"
    retention: "90 days"
    items:
      - "文档文件"
      - "索引数据"
  
  # 恢复测试
  recovery_test:
    frequency: "monthly"
    items:
      - "配置恢复测试"
      - "知识库恢复测试"
```

---

## 七、成本优化

### 7.1 Token优化

```yaml
token_optimization:
  # 提示词优化
  prompt:
    - 精简提示词
    - 使用更短的示例
    - 移除冗余内容
  
  # 对话优化
  conversation:
    - 控制历史记录长度
    - 使用摘要替代完整历史
    - 按需加载知识
  
  # 模型选择
  model:
    - 简单任务用小模型
    - 复杂任务用大模型
    - 批量任务用批量API
```

### 7.2 资源优化

```yaml
resource_optimization:
  # Bot数量
  bot_count:
    - 合并功能相似的Bot
    - 删除不用的Bot
    - 按需创建
  
  # 知识库容量
  knowledge_size:
    - 清理无用文档
    - 压缩文档内容
    - 归档历史数据
  
  # 工作流执行
  workflow:
    - 优化节点数量
    - 减少不必要的执行
    - 使用缓存结果
```

---

## 八、常见问题解决

### 8.1 响应慢

```yaml
problem:
  symptom: "Bot响应慢"
  
  diagnosis:
    - 检查模型选择
    - 检查知识库大小
    - 检查工作流复杂度
    - 检查网络延迟
  
  solutions:
    - 使用更快的模型
    - 减少知识库检索数量
    - 简化工作流
    - 启用缓存
    - 使用CDN加速
```

### 8.2 回答不准确

```yaml
problem:
  symptom: "Bot回答不准确"
  
  diagnosis:
    - 检查提示词是否清晰
    - 检查知识库内容质量
    - 检查检索参数设置
    - 检查是否有技能冲突
  
  solutions:
    - 优化提示词
    - 完善知识库内容
    - 调整检索参数
    - 添加示例对话
    - 使用重排序
```

### 8.3 频繁超限

```yaml
problem:
  symptom: "频繁达到使用限制"
  
  diagnosis:
    - 分析使用模式
    - 识别高消耗操作
    - 检查是否有异常调用
  
  solutions:
    - 优化使用策略
    - 启用缓存
    - 使用降级方案
    - 升级套餐
    - 多账号分流
```

---

## 九、总结

扣子平台最佳实践核心要点：

### 9.1 设计原则

- ✅ 角色定位清晰
- ✅ 提示词结构化
- ✅ 技能按需配置
- ✅ 知识库高质量

### 9.2 技术实践

- ✅ 模块化工作流设计
- ✅ 完善的错误处理
- ✅ 合理的缓存策略
- ✅ 有效的并发控制

### 9.3 运维保障

- ✅ 实时监控告警
- ✅ 完善的日志记录
- ✅ 定期备份恢复
- ✅ 成本持续优化

### 9.4 安全合规

- ✅ 密钥安全管理
- ✅ 数据隐私保护
- ✅ 输入严格验证
- ✅ 访问权限控制

关键成功因素：
1. 清晰的需求定义
2. 合理的架构设计
3. 持续的优化迭代
4. 完善的运维保障