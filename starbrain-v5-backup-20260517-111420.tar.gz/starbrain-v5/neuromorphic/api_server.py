"""
星辰大脑类脑网络API服务
StarBrain Neuromorphic API Service

为10号扣子等外部智能体提供API接口
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import json
import time
import threading

sys.path.append('/root/.openclaw/workspace/starbrain-v5/neuromorphic')
from snn_core import neuromorphic_module

app = Flask(__name__)
CORS(app)

# ==================== 健康检查 ====================

@app.route('/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({
        "status": "healthy",
        "service": "starbrain-neuromorphic-api",
        "version": "1.0.0",
        "timestamp": time.time()
    })

# ==================== 感知接口 ====================

@app.route('/api/v1/perception', methods=['POST'])
def perception():
    """
    感知处理接口

    请求体:
    {
        "data": {
            "key1": value1,
            "key2": value2,
            ...
        },
        "learn": false
    }

    返回:
    {
        "status": "success",
        "result": {
            "spike_rate": 0.4,
            "is_anomaly": false,
            "pattern": "low_activity",
            "active_neurons": 100,
            "elapsed_ms": 150.5
        }
    }
    """
    try:
        req = request.get_json()
        data = req.get('data', {})
        learn = req.get('learn', False)

        result = neuromorphic_module.process_perception(data)

        return jsonify({
            "status": "success",
            "result": result['result']
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 执行接口 ====================

@app.route('/api/v1/execute', methods=['POST'])
def execute():
    """
    执行反射接口

    请求体:
    {
        "stimulus": "high_priority_order"
    }

    返回:
    {
        "status": "success",
        "stimulus": "high_priority_order",
        "action": "analyze"
    }
    """
    try:
        req = request.get_json()
        stimulus = req.get('stimulus', '')

        result = neuromorphic_module.execute_reflex(stimulus)

        return jsonify(result)

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 学习接口 ====================

@app.route('/api/v1/learn', methods=['POST'])
def learn():
    """
    习惯学习接口

    请求体:
    {
        "stimulus": "爆款商品检测",
        "action": "立即推荐"
    }

    返回:
    {
        "status": "learned",
        "stimulus": "爆款商品检测",
        "action": "立即推荐"
    }
    """
    try:
        req = request.get_json()
        stimulus = req.get('stimulus', '')
        action = req.get('action', '')

        result = neuromorphic_module.learn_habit(stimulus, action)

        return jsonify(result)

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 状态接口 ====================

@app.route('/api/v1/status', methods=['GET'])
def status():
    """
    获取状态

    返回:
    {
        "enabled": true,
        "perception": {...},
        "execution": {...}
    }
    """
    try:
        result = neuromorphic_module.get_status()
        return jsonify(result)

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 控制接口 ====================

@app.route('/api/v1/enable', methods=['POST'])
def enable():
    """启用类脑网络"""
    neuromorphic_module.enable()
    return jsonify({"status": "enabled"})

@app.route('/api/v1/disable', methods=['POST'])
def disable():
    """禁用类脑网络"""
    neuromorphic_module.disable()
    return jsonify({"status": "disabled"})

@app.route('/api/v1/reset', methods=['POST'])
def reset():
    """重置类脑网络"""
    neuromorphic_module.reset()
    return jsonify({"status": "reset"})

# ==================== 批量接口 ====================

@app.route('/api/v1/batch/perception', methods=['POST'])
def batch_perception():
    """
    批量感知处理

    请求体:
    {
        "items": [
            {"data": {...}, "learn": false},
            {"data": {...}, "learn": true}
        ]
    }

    返回:
    {
        "status": "success",
        "results": [...]
    }
    """
    try:
        req = request.get_json()
        items = req.get('items', [])

        results = []
        for item in items:
            data = item.get('data', {})
            learn = item.get('learn', False)
            result = neuromorphic_module.process_perception(data)
            results.append(result['result'])

        return jsonify({
            "status": "success",
            "count": len(results),
            "results": results
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 扣子专用接口 ====================

@app.route('/coze/webhook', methods=['POST'])
def coze_webhook():
    """
    扣子Webhook接口

    扣子平台专用，支持多种操作类型

    请求体:
    {
        "type": "perception|execute|learn|status",
        "data": {...}
    }
    """
    try:
        req = request.get_json()
        msg_type = req.get('type', '')
        data = req.get('data', {})

        if msg_type == 'perception':
            result = neuromorphic_module.process_perception(data)

        elif msg_type == 'execute':
            stimulus = data.get('stimulus', '')
            result = neuromorphic_module.execute_reflex(stimulus)

        elif msg_type == 'learn':
            stimulus = data.get('stimulus', '')
            action = data.get('action', '')
            result = neuromorphic_module.learn_habit(stimulus, action)

        elif msg_type == 'status':
            result = neuromorphic_module.get_status()

        else:
            return jsonify({
                "status": "error",
                "error": f"Unknown type: {msg_type}"
            }), 400

        return jsonify({
            "status": "success",
            "type": msg_type,
            "result": result
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# ==================== 启动服务 ====================

if __name__ == '__main__':
    print("=" * 60)
    print("🧠 星辰大脑类脑网络API服务")
    print("=" * 60)
    print()
    print("📡 API端点:")
    print("  GET  /health              - 健康检查")
    print("  POST /api/v1/perception   - 感知处理")
    print("  POST /api/v1/execute      - 执行反射")
    print("  POST /api/v1/learn        - 习惯学习")
    print("  GET  /api/v1/status       - 获取状态")
    print("  POST /api/v1/enable       - 启用")
    print("  POST /api/v1/disable      - 禁用")
    print("  POST /api/v1/reset        - 重置")
    print("  POST /api/v1/batch/perception - 批量感知")
    print("  POST /coze/webhook        - 扣子专用")
    print()
    print("🌐 服务地址: http://0.0.0.0:8001")
    print()
    print("✅ 服务启动中...")
    print()

    app.run(host='0.0.0.0', port=8001, debug=False, threaded=True)
