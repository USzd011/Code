"""
星辰大脑类脑网络模块
StarBrain Neuromorphic Module

基于脉冲神经网络(SNN)的类脑计算模块
集成到星辰大脑L3感知层和L6执行层
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import time
import json

# ==================== 配置 ====================

class NeuronType(Enum):
    """神经元类型"""
    LIF = "leaky_integrate_and_fire"
    IZHIKEVICH = "izhikevich"

@dataclass
class SNNConfig:
    """SNN配置"""
    num_neurons: int = 1000
    neuron_type: NeuronType = NeuronType.LIF
    threshold: float = 1.0
    decay: float = 0.9
    refractory: int = 2
    learning_rate: float = 0.01
    max_weight: float = 1.0
    min_weight: float = 0.0

# ==================== 神经元 ====================

class LIFNeuron:
    """Leaky Integrate-and-Fire神经元"""

    def __init__(self, config: SNNConfig):
        self.config = config
        self.membrane_potential = 0.0
        self.refractory_counter = 0
        self.spike_history: List[bool] = []
        self.last_spike_time = 0

    def update(self, input_current: float, time_step: int) -> bool:
        """更新神经元状态

        Args:
            input_current: 输入电流
            time_step: 当前时间步

        Returns:
            是否发放脉冲
        """
        # 不应期检查
        if self.refractory_counter > 0:
            self.refractory_counter -= 1
            self.spike_history.append(False)
            return False

        # 膜电位更新（泄露积分）
        self.membrane_potential = (
            self.config.decay * self.membrane_potential + input_current
        )

        # 发放判定
        if self.membrane_potential >= self.config.threshold:
            self.membrane_potential = 0.0
            self.refractory_counter = self.config.refractory
            self.last_spike_time = time_step
            self.spike_history.append(True)
            return True

        self.spike_history.append(False)
        return False

    def reset(self):
        """重置神经元状态"""
        self.membrane_potential = 0.0
        self.refractory_counter = 0
        self.spike_history.clear()

# ==================== 突触 ====================

class Synapse:
    """突触（支持STDP学习）"""

    def __init__(self, weight: float = 0.5, delay: int = 1):
        self.weight = weight
        self.delay = delay
        self.pre_spike_time = 0
        self.post_spike_time = 0
        self.eligibility_trace = 0.0

    def stdp_update(self, dt: int, learning_rate: float,
                    a_plus: float = 1.0, a_minus: float = 0.5,
                    tau_plus: float = 20.0, tau_minus: float = 20.0):
        """STDP权重更新

        Args:
            dt: pre和post发放时间差（pre - post）
            learning_rate: 学习率
            a_plus: LTP幅度
            a_minus: LTD幅度
            tau_plus: LTP时间常数
            tau_minus: LTD时间常数
        """
        if dt > 0:  # pre先于post → LTP
            delta_w = a_plus * np.exp(-dt / tau_plus)
            self.weight += learning_rate * delta_w
        else:  # post先于pre → LTD
            delta_w = a_minus * np.exp(dt / tau_minus)
            self.weight -= learning_rate * delta_w

        # 权重限制
        self.weight = np.clip(self.weight, 0.0, 1.0)

# ==================== SNN层 ====================

class SNNLayer:
    """SNN层"""

    def __init__(self, num_neurons: int, config: SNNConfig, name: str = ""):
        self.num_neurons = num_neurons
        self.config = config
        self.name = name
        self.neurons = [LIFNeuron(config) for _ in range(num_neurons)]
        self.output_spikes = np.zeros(num_neurons)

    def forward(self, input_currents: np.ndarray, time_step: int) -> np.ndarray:
        """前向传播

        Args:
            input_currents: 输入电流（每个神经元一个）
            time_step: 当前时间步

        Returns:
            输出脉冲
        """
        self.output_spikes = np.zeros(self.num_neurons)

        for i, neuron in enumerate(self.neurons):
            if i < len(input_currents):
                self.output_spikes[i] = neuron.update(input_currents[i], time_step)

        return self.output_spikes

    def get_spike_rate(self, window: int = 100) -> np.ndarray:
        """获取发放率

        Args:
            window: 时间窗口

        Returns:
            每个神经元的发放率
        """
        rates = np.zeros(self.num_neurons)
        for i, neuron in enumerate(self.neurons):
            recent = neuron.spike_history[-window:] if neuron.spike_history else []
            rates[i] = sum(recent) / len(recent) if recent else 0.0
        return rates

    def reset(self):
        """重置层状态"""
        for neuron in self.neurons:
            neuron.reset()
        self.output_spikes = np.zeros(self.num_neurons)

# ==================== SNN网络 ====================

class SNNNetwork:
    """SNN网络"""

    def __init__(self, config: SNNConfig):
        self.config = config
        self.layers: List[SNNLayer] = []
        self.synapses: Dict[Tuple[int, int, int], Synapse] = {}
        self.time_step = 0

    def add_layer(self, num_neurons: int, name: str = ""):
        """添加层

        Args:
            num_neurons: 神经元数量
            name: 层名称
        """
        layer = SNNLayer(num_neurons, self.config, name)
        self.layers.append(layer)

        # 连接突触
        if len(self.layers) > 1:
            prev_layer_idx = len(self.layers) - 2
            prev_layer = self.layers[prev_layer_idx]

            # 全连接
            for i in range(prev_layer.num_neurons):
                for j in range(num_neurons):
                    self.synapses[(prev_layer_idx, i, j)] = Synapse(
                        weight=np.random.random() * 0.5 + 0.25
                    )

    def forward(self, input_spikes: np.ndarray) -> np.ndarray:
        """前向传播

        Args:
            input_spikes: 输入脉冲

        Returns:
            输出脉冲
        """
        self.time_step += 1
        current_spikes = input_spikes

        for layer_idx, layer in enumerate(self.layers):
            if layer_idx == 0:
                # 输入层：直接使用输入脉冲作为电流
                input_currents = current_spikes * self.config.threshold
                current_spikes = layer.forward(input_currents, self.time_step)
            else:
                # 隐藏层/输出层：通过突触传递
                prev_layer = self.layers[layer_idx - 1]
                input_currents = np.zeros(layer.num_neurons)

                for (l, i, j), synapse in self.synapses.items():
                    if l == layer_idx - 1:
                        input_currents[j] += current_spikes[i] * synapse.weight

                current_spikes = layer.forward(input_currents, self.time_step)

        return current_spikes

    def stdp_learning(self, learning_rate: Optional[float] = None):
        """STDP学习

        Args:
            learning_rate: 学习率（可选，默认使用配置）
        """
        if learning_rate is None:
            learning_rate = self.config.learning_rate

        for (layer_idx, i, j), synapse in self.synapses.items():
            pre_neuron = self.layers[layer_idx].neurons[i]
            post_neuron = self.layers[layer_idx + 1].neurons[j]

            dt = pre_neuron.last_spike_time - post_neuron.last_spike_time

            if dt != 0:
                synapse.stdp_update(dt, learning_rate)

    def reset(self):
        """重置网络状态"""
        self.time_step = 0
        for layer in self.layers:
            layer.reset()

    def get_stats(self) -> Dict:
        """获取网络统计信息"""
        stats = {
            "time_step": self.time_step,
            "num_layers": len(self.layers),
            "num_neurons": sum(layer.num_neurons for layer in self.layers),
            "num_synapses": len(self.synapses),
            "layers": []
        }

        for i, layer in enumerate(self.layers):
            layer_stats = {
                "name": layer.name or f"Layer {i}",
                "num_neurons": layer.num_neurons,
                "spike_rate": float(np.mean(layer.get_spike_rate()))
            }
            stats["layers"].append(layer_stats)

        return stats

# ==================== 编码器/解码器 ====================

class RateEncoder:
    """频率编码器"""

    def __init__(self, num_neurons: int = 100, max_rate: float = 100.0):
        self.num_neurons = num_neurons
        self.max_rate = max_rate

    def encode(self, data: np.ndarray, duration: int = 10) -> np.ndarray:
        """编码数据为脉冲序列

        Args:
            data: 输入数据（归一化到[0, 1]）
            duration: 编码时长（时间步）

        Returns:
            脉冲序列（duration × num_neurons）
        """
        # 确保数据在[0, 1]范围
        data = np.clip(data, 0.0, 1.0)

        # 生成脉冲序列
        spike_trains = np.zeros((duration, self.num_neurons))

        for t in range(duration):
            for i in range(min(len(data), self.num_neurons)):
                # 泊松脉冲生成
                rate = data[i] * self.max_rate
                prob = rate / self.max_rate
                spike_trains[t, i] = 1.0 if np.random.random() < prob else 0.0

        return spike_trains

class RateDecoder:
    """频率解码器"""

    def __init__(self, window: int = 10):
        self.window = window

    def decode(self, spike_trains: np.ndarray) -> np.ndarray:
        """解码脉冲序列为数据

        Args:
            spike_trains: 脉冲序列

        Returns:
            解码后的数据
        """
        # 计算发放率
        rates = np.mean(spike_trains[-self.window:], axis=0)
        return rates

# ==================== 应用模块 ====================

class SNNPerceptionModule:
    """SNN感知模块（L3感知层）"""

    def __init__(self):
        self.config = SNNConfig(num_neurons=500)
        self.network = SNNNetwork(self.config)
        self.network.add_layer(100, "input")
        self.network.add_layer(200, "hidden")
        self.network.add_layer(100, "output")

        self.encoder = RateEncoder(num_neurons=100)
        self.decoder = RateDecoder(window=10)

        self.anomaly_threshold = 0.8
        self.pattern_memory: Dict[str, np.ndarray] = {}

    def process(self, input_data: np.ndarray, learn: bool = False) -> Dict:
        """处理感知数据

        Args:
            input_data: 输入数据
            learn: 是否学习

        Returns:
            处理结果
        """
        start_time = time.time()

        # 编码
        spike_trains = self.encoder.encode(input_data, duration=10)

        # SNN处理
        output_spikes = []
        for t in range(spike_trains.shape[0]):
            output = self.network.forward(spike_trains[t])
            output_spikes.append(output)

        output_spikes = np.array(output_spikes)

        # STDP学习
        if learn:
            self.network.stdp_learning()

        # 解码
        decoded = self.decoder.decode(output_spikes)

        # 异常检测
        spike_rate = np.mean(decoded)
        is_anomaly = spike_rate > self.anomaly_threshold

        # 模式识别
        pattern = self._recognize_pattern(decoded)

        elapsed = (time.time() - start_time) * 1000

        return {
            "spike_rate": float(spike_rate),
            "is_anomaly": bool(is_anomaly),
            "pattern": pattern,
            "active_neurons": int(np.sum(decoded > 0.1)),
            "elapsed_ms": elapsed,
            "stats": self.network.get_stats()
        }

    def _recognize_pattern(self, decoded: np.ndarray) -> str:
        """识别模式

        Args:
            decoded: 解码后的数据

        Returns:
            模式名称
        """
        # 简化：基于发放率判断
        avg_rate = np.mean(decoded)

        if avg_rate > 0.7:
            return "high_activity"
        elif avg_rate > 0.4:
            return "medium_activity"
        elif avg_rate > 0.1:
            return "low_activity"
        else:
            return "idle"

    def learn_pattern(self, pattern_name: str, data: np.ndarray):
        """学习模式

        Args:
            pattern_name: 模式名称
            data: 模式数据
        """
        spike_trains = self.encoder.encode(data, duration=10)
        avg_pattern = np.mean(spike_trains, axis=0)
        self.pattern_memory[pattern_name] = avg_pattern

    def reset(self):
        """重置模块"""
        self.network.reset()

class SNNExecutionModule:
    """SNN执行模块（L6执行层）"""

    def __init__(self):
        self.config = SNNConfig(num_neurons=300)
        self.network = SNNNetwork(self.config)
        self.network.add_layer(50, "input")
        self.network.add_layer(150, "hidden")
        self.network.add_layer(100, "output")

        self.habit_memory: Dict[str, str] = {}
        self.action_mapping = {
            0: "analyze",
            1: "respond",
            2: "wait",
            3: "escalate",
            4: "ignore"
        }

    def execute(self, stimulus: str) -> Optional[str]:
        """执行反射动作

        Args:
            stimulus: 刺激

        Returns:
            动作
        """
        # 检查习惯记忆
        if stimulus in self.habit_memory:
            return self.habit_memory[stimulus]

        # SNN处理
        input_spikes = self._stimulus_to_spikes(stimulus)
        output_spikes = self.network.forward(input_spikes)

        # 选择动作
        action = self._spikes_to_action(output_spikes)

        return action

    def learn_habit(self, stimulus: str, action: str):
        """学习习惯

        Args:
            stimulus: 刺激
            action: 动作
        """
        self.habit_memory[stimulus] = action

        # STDP强化
        input_spikes = self._stimulus_to_spikes(stimulus)
        self.network.forward(input_spikes)
        self.network.stdp_learning(learning_rate=0.05)

    def _stimulus_to_spikes(self, stimulus: str) -> np.ndarray:
        """刺激转脉冲

        Args:
            stimulus: 刺激字符串

        Returns:
            脉冲数组
        """
        # 简化：使用哈希映射
        hash_val = hash(stimulus) % 50
        spikes = np.zeros(50)
        spikes[hash_val] = 1.0
        return spikes

    def _spikes_to_action(self, spikes: np.ndarray) -> str:
        """脉冲转动作

        Args:
            spikes: 脉冲数组

        Returns:
            动作名称
        """
        # 选择最活跃的神经元对应动作
        active_idx = int(np.argmax(spikes[:50]))  # 只看前50个
        return self.action_mapping.get(active_idx % 5, "wait")

    def get_habit_stats(self) -> Dict:
        """获取习惯统计"""
        return {
            "num_habits": len(self.habit_memory),
            "habits": list(self.habit_memory.keys())[:10],  # 前10个
            "stats": self.network.get_stats()
        }

    def reset(self):
        """重置模块"""
        self.network.reset()

# ==================== 集成接口 ====================

class NeuromorphicIntegration:
    """类脑模块集成接口"""

    def __init__(self):
        self.perception = SNNPerceptionModule()
        self.execution = SNNExecutionModule()
        self.enabled = True

    def process_perception(self, data: Dict) -> Dict:
        """处理感知数据

        Args:
            data: 感知数据

        Returns:
            处理结果
        """
        if not self.enabled:
            return {"status": "disabled"}

        try:
            # 转换为numpy数组
            input_array = np.array(list(data.values()))

            # SNN处理
            result = self.perception.process(input_array)

            return {
                "status": "success",
                "layer": "L3",
                "result": result
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }

    def execute_reflex(self, stimulus: str) -> Dict:
        """执行反射动作

        Args:
            stimulus: 刺激

        Returns:
            执行结果
        """
        if not self.enabled:
            return {"status": "disabled", "action": None}

        try:
            action = self.execution.execute(stimulus)

            return {
                "status": "success",
                "layer": "L6",
                "stimulus": stimulus,
                "action": action
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }

    def learn_habit(self, stimulus: str, action: str) -> Dict:
        """学习习惯

        Args:
            stimulus: 刺激
            action: 动作

        Returns:
            学习结果
        """
        self.execution.learn_habit(stimulus, action)

        return {
            "status": "learned",
            "stimulus": stimulus,
            "action": action
        }

    def get_status(self) -> Dict:
        """获取状态"""
        return {
            "enabled": self.enabled,
            "perception": {
                "num_neurons": 500,
                "stats": self.perception.network.get_stats()
            },
            "execution": {
                "num_neurons": 300,
                "habits": self.execution.get_habit_stats()
            }
        }

    def enable(self):
        """启用"""
        self.enabled = True

    def disable(self):
        """禁用"""
        self.enabled = False

    def reset(self):
        """重置"""
        self.perception.reset()
        self.execution.reset()

# ==================== 全局实例 ====================

neuromorphic_module = NeuromorphicIntegration()

# ==================== 测试 ====================

def test_snn():
    """测试SNN"""
    print("🧠 测试SNN模块...")

    # 测试感知模块
    print("\n📊 测试感知模块...")
    perception = SNNPerceptionModule()

    # 模拟输入数据
    test_data = np.random.random(100)
    result = perception.process(test_data, learn=True)

    print(f"发放率: {result['spike_rate']:.3f}")
    print(f"异常检测: {result['is_anomaly']}")
    print(f"模式识别: {result['pattern']}")
    print(f"活跃神经元: {result['active_neurons']}")
    print(f"耗时: {result['elapsed_ms']:.2f}ms")

    # 测试执行模块
    print("\n⚡ 测试执行模块...")
    execution = SNNExecutionModule()

    # 测试反射
    stimulus = "test_stimulus_001"
    action = execution.execute(stimulus)
    print(f"刺激: {stimulus}")
    print(f"动作: {action}")

    # 学习习惯
    execution.learn_habit(stimulus, "custom_action")
    action_after = execution.execute(stimulus)
    print(f"学习后动作: {action_after}")

    # 测试集成
    print("\n🔗 测试集成...")
    integration = NeuromorphicIntegration()

    # 感知测试
    data = {"sensor1": 0.8, "sensor2": 0.3, "sensor3": 0.6}
    result = integration.process_perception(data)
    print(f"感知结果: {result}")

    # 执行测试
    result = integration.execute_reflex("emergency_alert")
    print(f"执行结果: {result}")

    # 状态
    status = integration.get_status()
    print(f"\n状态: {json.dumps(status, indent=2)}")

    print("\n✅ 测试完成！")

if __name__ == "__main__":
    test_snn()
