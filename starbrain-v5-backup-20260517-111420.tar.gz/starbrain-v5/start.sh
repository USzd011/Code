#!/bin/bash
# ============================================================
# 🔱 星辰大脑 v5.0 — 一键启动脚本
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "======================================"
echo "🔱 星辰大脑 v5.0 启动中..."
echo "======================================"

# 1. 先kill旧的
echo -n "[1/4] 清理旧进程... "
pkill -f "star_brain.py\|api_server.py\|compute_node.py" 2>/dev/null || true
sleep 1
echo "✅"

# 2. 启动API服务
echo -n "[2/4] 启动内核 (轻量 threading)... "
LOG_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOG_DIR"
python3 api_v2.py > "$LOG_DIR/star_brain.log" 2>&1 &
BRAIN_PID=$!
sleep 2
echo "✅ (PID: $BRAIN_PID)"

# 3. 验证
echo -n "[3/4] 验证... "
if curl -s http://localhost:8899/status > /dev/null 2>&1; then
    echo "✅ 服务正常!"
else
    echo "⚠️ 状态检查失败，查看日志中..."
    tail -5 "$LOG_DIR/star_brain.log"
fi

# 4. 注册自愈
echo -n "[4/4] 注册系统监控... "
echo $BRAIN_PID > "$LOG_DIR/star_brain.pid"
echo "✅"

echo ""
echo "🔱 星辰大脑 v5.0 — 已上线"
echo "   API: http://localhost:8899"
echo "   日志: $LOG_DIR/star_brain.log"
echo "   管理: python3 star_network.py (L8网络层)"
echo ""
echo "   curl http://localhost:8899/status"
echo ""

# ============================================================
# API 速查卡
# ============================================================
# GET  /status      系统状态
# GET  /skills      处理器列表
# GET  /domains     八宿域信息
# GET  /memory?q=   记忆搜索
# GET  /route?task= 域路由
# POST /task        提交任务
# POST /memory      存储记忆
# POST /collect     收完成结果
# ============================================================
