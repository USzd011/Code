"""
团队Agent API - 给3号QClaw和其他成员用的接口
"""
import os, sys, json, time, uuid

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "prototypes"))


class AgentAPI:
    """Agent间通信API - 供3号QClaw等成员调用"""

    @staticmethod
    def think(query: str, context: str = "") -> dict:
        """🧠 思考：检索记忆+推理"""
        from brain_cortex import get_cortex_engine
        engine = get_cortex_engine()
        return engine.think(query, context)

    @staticmethod
    def learn(topic: str) -> dict:
        """📖 学习：主动学一个主题"""
        from brain_cortex import get_cortex_engine
        engine = get_cortex_engine()
        return engine.learn(topic)

    @staticmethod
    def mcts(revenue: float, conversion: float, cost: float, risk: float) -> dict:
        """🎯 MCTS决策推演"""
        from mcts_prototype import MCTSEngine, GameState
        engine = MCTSEngine(max_iterations=1000)
        state = GameState(revenue=float(revenue), conversion=float(conversion),
                          cost=float(cost), risk=float(risk))
        result = engine.search(state)
        return {
            "action": result["best_action"],
            "top3": [f"#{p['rank']} {p['action']} ({p['confidence']}%)" for p in result.get("top3_plans", [])],
            "time_s": round(result.get("time", 0), 3),
        }

    @staticmethod
    def store(content: str, domain: str = "通用", source: str = "agent") -> dict:
        """💾 存储记忆"""
        from light_cortex import LightVectorStore
        v = LightVectorStore()
        v.store(content, domain=domain)
        return {"stored": True, "total": v.stats()["total"]}

    @staticmethod
    def search(query: str, limit: int = 5) -> dict:
        """🔍 搜索知识库"""
        from light_cortex import LightVectorStore
        v = LightVectorStore()
        results = v.search(query, limit=limit)
        return {"count": len(results), "results": results}

    @staticmethod
    def route(task: str) -> dict:
        """🔗 二十八宿路由"""
        DOMAINS = {
            "宿1-抖音": ["抖音", "选品", "爆款", "带货"],
            "宿2-快手": ["快手", "小店"],
            "宿3-头条": ["头条", "文章", "写作"],
            "宿4-达人": ["达人", "匹配", "合作"],
            "宿5-用户": ["用户", "画像", "粉丝"],
            "宿6-竞品": ["竞品", "竞争", "市场"],
            "宿7-趋势": ["趋势", "预测", "热点"],
            "宿8-风控": ["风险", "合规", "安全"],
        }
        for domain, keywords in DOMAINS.items():
            for kw in keywords:
                if kw in task:
                    return {"domain": domain}
        return {"domain": "通用"}

    @staticmethod
    def enrich(task_type: str, payload: dict) -> dict:
        """🚀 任务增强：自动注入经验"""
        from brain_cortex import get_cortex_engine
        engine = get_cortex_engine()
        return engine.enrich_task(task_type, payload)

API_MAP = AgentAPI().__class__.__dict__

print("AgentAPI 已就绪，可用方法:")
for name, func in AgentAPI.__dict__.items():
    if not name.startswith('_'):
        print(f"  - {name}")
