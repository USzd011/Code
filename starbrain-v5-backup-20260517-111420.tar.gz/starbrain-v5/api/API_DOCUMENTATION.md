# 星辰大脑 API 对接文档

> **版本：** v1.0
> **基础URL：** `http://your-server:8000`

---

## 一、接口概览

| 接口 | 方法 | 说明 |
|------|------|------|
| `/health` | GET | 健康检查 |
| `/coze/intents` | GET | 获取支持的意图列表 |
| `/coze/trigger` | POST | 触发任务 |
| `/coze/task/{task_id}` | GET | 查询任务状态 |
| `/webhook/starbrain` | POST | Webhook回调 |

---

## 二、接口详情

### 2.1 健康检查

**GET /health**

**响应：**
```json
{
  "status": "healthy",
  "version": "v1.0",
  "timestamp": 1778292526
}
```

---

### 2.2 获取意图列表

**GET /coze/intents**

**响应：**
```json
{
  "intents": [
    {
      "intent": "douyin_select_product",
      "name": "抖音选品",
      "estimated_time": 120,
      "handler": "宿1-抖音商品"
    },
    {
      "intent": "toutiao_write",
      "name": "头条写作",
      "estimated_time": 300,
      "handler": "宿3-头条内容"
    },
    {
      "intent": "data_analysis",
      "name": "数据分析",
      "estimated_time": 180,
      "handler": "宿5-用户画像"
    },
    {
      "intent": "talent_match",
      "name": "达人匹配",
      "estimated_time": 60,
      "handler": "宿4-达人资源"
    },
    {
      "intent": "novel_create",
      "name": "小说创作",
      "estimated_time": 600,
      "handler": "通用技能"
    }
  ]
}
```

---

### 2.3 触发任务

**POST /coze/trigger**

**请求体：**
```json
{
  "intent": "douyin_select_product",
  "params": {
    "category": "生鲜",
    "target_count": 10
  },
  "priority": 2,
  "session_id": "coze_session_xxx",
  "callback_url": "https://your-coze-bot.com/webhook"
}
```

**参数说明：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| intent | string | 是 | 意图类型 |
| params | object | 否 | 业务参数 |
| priority | int | 否 | 优先级 1-3，默认2 |
| session_id | string | 否 | 扣子会话ID |
| callback_url | string | 否 | 回调URL |

**响应：**
```json
{
  "success": true,
  "task_id": "task_b0c9927aebaa4b95",
  "status": "queued",
  "estimated_time": 120,
  "message": "任务已接收，将由宿1-抖音商品处理"
}
```

---

### 2.4 查询任务状态

**GET /coze/task/{task_id}**

**响应：**
```json
{
  "task_id": "task_b0c9927aebaa4b95",
  "status": "completed",
  "progress": 1.0,
  "result": {
    "message": "任务完成",
    "data": {
      "products": [
        {"name": "商品1", "score": 0.92},
        {"name": "商品2", "score": 0.88}
      ]
    }
  },
  "error": null,
  "updated_at": 1778292526
}
```

**状态说明：**

| 状态 | 说明 |
|------|------|
| queued | 排队中 |
| running | 执行中 |
| completed | 已完成 |
| failed | 失败 |

---

### 2.5 Webhook回调

**POST /webhook/starbrain**

**请求头：**
```
X-StarBrain-Signature: sha256=xxx
X-StarBrain-Timestamp: 1778292526
```

**请求体：**
```json
{
  "event_type": "task_complete",
  "task_id": "task_b0c9927aebaa4b95",
  "timestamp": 1778292526,
  "data": {
    "success": true,
    "result": {...}
  }
}
```

**事件类型：**

| 事件 | 说明 |
|------|------|
| task_complete | 任务完成 |
| alert | 告警通知 |
| schedule | 定时任务 |

---

## 三、扣子配置示例

### 3.1 意图识别配置

```yaml
意图映射:
  "找爆款":
    intent: douyin_select_product
    params:
      platform: douyin
  
  "写文章":
    intent: toutiao_write
    params:
      platform: toutiao
  
  "分析数据":
    intent: data_analysis
    params: {}
  
  "匹配达人":
    intent: talent_match
    params: {}
```

### 3.2 工作流配置

```yaml
工作流: 星辰大脑任务分发

节点1: 意图识别
  输入: 用户消息
  输出: intent, params

节点2: API调用
  URL: http://your-server:8000/coze/trigger
  方法: POST
  Body:
    intent: ${intent}
    params: ${params}
    session_id: ${session_id}

节点3: 等待回调
  超时: 300秒

节点4: 返回结果
  输出: 任务结果
```

---

## 四、测试用例

### 4.1 测试触发任务

```bash
curl -X POST http://localhost:8000/coze/trigger \
  -H "Content-Type: application/json" \
  -d '{
    "intent": "douyin_select_product",
    "params": {"category": "生鲜"},
    "priority": 2
  }'
```

### 4.2 测试查询状态

```bash
curl http://localhost:8000/coze/task/task_b0c9927aebaa4b95
```

### 4.3 测试健康检查

```bash
curl http://localhost:8000/health
```

---

## 五、错误处理

### 5.1 错误码

| 状态码 | 说明 |
|--------|------|
| 400 | 请求参数错误 |
| 404 | 任务不存在 |
| 401 | 签名验证失败 |
| 500 | 服务器内部错误 |

### 5.2 错误响应

```json
{
  "detail": "未知意图: unknown_intent"
}
```

---

## 六、下一步

1. 杨欢配置扣子API调用
2. 测试触发接口
3. 测试回调接收
4. 完整流程测试

---

_创建时间: 2026-05-09_
