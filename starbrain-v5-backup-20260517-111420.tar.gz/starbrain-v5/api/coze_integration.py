"""
星辰大脑 API - 扣子对接接口
"""

from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, Dict, Any
import uuid
import time
import hmac
import hashlib

app = FastAPI(title="星辰大脑 API", version="v1.0")

# ========== 数据模型 ==========

class TriggerRequest(BaseModel):
    """触发请求"""
    intent: str
    params: Dict[str, Any] = {}
    priority: int = 2
    session_id: Optional[str] = None
    callback_url: Optional[str] = None

class TriggerResponse(BaseModel):
    """触发响应"""
    success: bool
    task_id: str
    status: str
    estimated_time: int
    message: str

class TaskStatus(BaseModel):
    """任务状态"""
    task_id: str
    status: str
    progress: float
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    updated_at: int

class WebhookPayload(BaseModel):
    """Webhook载荷"""
    event_type: str
    task_id: str
    timestamp: int
    data: Dict[str, Any]

# ========== 模拟存储 ==========

tasks_db: Dict[str, Dict] = {}

# ========== 意图处理 ==========

INTENT_HANDLERS = {
    "douyin_select_product": {
        "name": "抖音选品",
        "estimated_time": 120,
        "handler": "宿1-抖音商品"
    },
    "toutiao_write": {
        "name": "头条写作",
        "estimated_time": 300,
        "handler": "宿3-头条内容"
    },
    "data_analysis": {
        "name": "数据分析",
        "estimated_time": 180,
        "handler": "宿5-用户画像"
    },
    "talent_match": {
        "name": "达人匹配",
        "estimated_time": 60,
        "handler": "宿4-达人资源"
    },
    "novel_create": {
        "name": "小说创作",
        "estimated_time": 600,
        "handler": "通用技能"
    },
}

# ========== API接口 ==========

@app.post("/coze/trigger", response_model=TriggerResponse)
async def trigger_task(request: TriggerRequest):
    """触发星辰大脑任务"""
    
    # 验证意图
    if request.intent not in INTENT_HANDLERS:
        raise HTTPException(status_code=400, detail=f"未知意图: {request.intent}")
    
    # 生成任务ID
    task_id = f"task_{uuid.uuid4().hex[:16]}"
    
    # 获取处理器信息
    handler_info = INTENT_HANDLERS[request.intent]
    
    # 存储任务
    tasks_db[task_id] = {
        "task_id": task_id,
        "intent": request.intent,
        "params": request.params,
        "priority": request.priority,
        "session_id": request.session_id,
        "callback_url": request.callback_url,
        "status": "queued",
        "progress": 0.0,
        "created_at": int(time.time()),
        "handler": handler_info["handler"],
    }
    
    return TriggerResponse(
        success=True,
        task_id=task_id,
        status="queued",
        estimated_time=handler_info["estimated_time"],
        message=f"任务已接收，将由{handler_info['handler']}处理"
    )

@app.get("/coze/task/{task_id}", response_model=TaskStatus)
async def get_task_status(task_id: str):
    """查询任务状态"""
    
    if task_id not in tasks_db:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    task = tasks_db[task_id]
    
    # 模拟任务进度
    elapsed = time.time() - task["created_at"]
    if elapsed > 5:
        task["status"] = "completed"
        task["progress"] = 1.0
        task["result"] = {
            "message": "任务完成",
            "data": {"example": "result"}
        }
    elif elapsed > 1:
        task["status"] = "running"
        task["progress"] = min(0.9, elapsed / 5)
    
    return TaskStatus(
        task_id=task["task_id"],
        status=task["status"],
        progress=task["progress"],
        result=task.get("result"),
        error=task.get("error"),
        updated_at=int(time.time())
    )

@app.post("/webhook/starbrain")
async def receive_webhook(
    payload: WebhookPayload,
    x_starbrain_signature: Optional[str] = Header(None),
    x_starbrain_timestamp: Optional[int] = Header(None)
):
    """接收Webhook回调"""
    
    # 验证签名（实际部署时启用）
    # if not verify_signature(x_starbrain_signature, payload.json(), x_starbrain_timestamp):
    #     raise HTTPException(status_code=401, detail="签名验证失败")
    
    # 处理不同事件类型
    if payload.event_type == "task_complete":
        # 任务完成处理
        print(f"任务完成: {payload.task_id}")
        return {"status": "acknowledged"}
    
    elif payload.event_type == "alert":
        # 告警处理
        print(f"告警: {payload.data}")
        return {"status": "acknowledged"}
    
    else:
        return {"status": "unknown_event"}

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "version": "v1.0",
        "timestamp": int(time.time())
    }

@app.get("/coze/intents")
async def list_intents():
    """列出所有支持的意图"""
    return {
        "intents": [
            {
                "intent": intent,
                "name": info["name"],
                "estimated_time": info["estimated_time"],
                "handler": info["handler"]
            }
            for intent, info in INTENT_HANDLERS.items()
        ]
    }

# ========== 辅助函数 ==========

def verify_signature(signature: str, payload: str, timestamp: int) -> bool:
    """验证签名"""
    # 防止重放攻击
    current_time = int(time.time())
    if abs(current_time - timestamp) > 300:  # 5分钟窗口
        return False
    
    # 验证签名（实际部署时使用真实密钥）
    # expected = generate_signature(payload, timestamp)
    # return hmac.compare_digest(signature, expected)
    return True

def generate_signature(payload: str, timestamp: int, secret: str = "your-secret") -> str:
    """生成签名"""
    message = f"{timestamp}.{payload}"
    signature = hmac.new(
        secret.encode(),
        message.encode(),
        hashlib.sha256
    ).hexdigest()
    return f"sha256={signature}"

# ========== 启动 ==========

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
