"""
语义检索服务
基于Milvus向量数据库实现记忆的语义检索
"""

import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import json

# 模拟实现（实际部署时使用真实SDK）

@dataclass
class SearchResult:
    """搜索结果"""
    memory_id: str
    content: str
    source: str
    score: float


class MockVectorDB:
    """模拟向量数据库（用于测试）"""
    
    def __init__(self):
        self.data: List[Dict] = []
        self._load_mock_data()
    
    def _load_mock_data(self):
        """加载模拟数据"""
        mock_memories = [
            {"id": "mem_001", "content": "抖音选品分析技能，用于分析商品潜力", "source": "MEMORY.md"},
            {"id": "mem_002", "content": "快手达人匹配，匹配商品与达人", "source": "MEMORY.md"},
            {"id": "mem_003", "content": "头条内容生成，每日8篇文章", "source": "MEMORY.md"},
            {"id": "mem_004", "content": "MCTS决策引擎，多方案推演", "source": "CORE_DIRECTIVES.md"},
            {"id": "mem_005", "content": "二十八宿大阵，技能分类系统", "source": "CORE_DIRECTIVES.md"},
            {"id": "mem_006", "content": "九曜星君阵，多线程执行", "source": "CORE_DIRECTIVES.md"},
            {"id": "mem_007", "content": "南斗六星阵，技能培育机制", "source": "CORE_DIRECTIVES.md"},
            {"id": "mem_008", "content": "北斗七星阵，技能淘汰机制", "source": "CORE_DIRECTIVES.md"},
        ]
        
        for mem in mock_memories:
            self.data.append({
                "memory_id": mem["id"],
                "content": mem["content"],
                "source": mem["source"],
                "embedding": self._mock_embedding(mem["content"]),
            })
    
    def _mock_embedding(self, text: str) -> List[float]:
        """模拟向量（实际使用OpenAI API）"""
        # 简单的词频向量模拟
        import hashlib
        hash_obj = hashlib.md5(text.encode())
        hash_bytes = hash_obj.digest()
        
        # 生成128维向量（模拟）
        embedding = []
        for i in range(128):
            embedding.append((hash_bytes[i % 16] / 255.0) * 2 - 1)
        
        return embedding
    
    def search(self, query_embedding: List[float], top_k: int = 10) -> List[Dict]:
        """搜索"""
        # 计算相似度
        results = []
        for item in self.data:
            score = self._cosine_similarity(query_embedding, item["embedding"])
            results.append({
                "memory_id": item["memory_id"],
                "content": item["content"],
                "source": item["source"],
                "score": score,
            })
        
        # 排序
        results.sort(key=lambda x: x["score"], reverse=True)
        
        return results[:top_k]
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """计算余弦相似度"""
        import math
        
        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot_product / (norm_a * norm_b)


class SemanticSearchService:
    """语义检索服务"""
    
    def __init__(self, use_mock: bool = True):
        if use_mock:
            self.db = MockVectorDB()
        else:
            # 实际部署时使用Milvus
            from pymilvus import Collection
            self.db = Collection(name="starbrain_memories")
            self.db.load()
    
    def search(self, query: str, top_k: int = 10) -> List[SearchResult]:
        """语义检索"""
        start_time = time.time()
        
        # 获取查询向量
        query_embedding = self._get_embedding(query)
        
        # 搜索
        results = self.db.search(query_embedding, top_k)
        
        # 转换结果
        search_results = []
        for item in results:
            search_results.append(SearchResult(
                memory_id=item["memory_id"],
                content=item["content"],
                source=item["source"],
                score=item["score"],
            ))
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return search_results, elapsed_ms
    
    def _get_embedding(self, text: str) -> List[float]:
        """获取文本向量"""
        # 模拟实现
        import hashlib
        hash_obj = hashlib.md5(text.encode())
        hash_bytes = hash_obj.digest()
        
        embedding = []
        for i in range(128):
            embedding.append((hash_bytes[i % 16] / 255.0) * 2 - 1)
        
        return embedding
    
    def insert(self, memory_id: str, content: str, source: str):
        """插入记忆"""
        # 实际部署时实现
        pass


def main():
    """测试语义检索"""
    print("=== 语义检索服务测试 ===\n")
    
    service = SemanticSearchService(use_mock=True)
    
    # 测试查询
    queries = [
        "抖音选品",
        "技能评估",
        "决策推演",
        "内容生成",
    ]
    
    for query in queries:
        print(f"\n查询: {query}")
        results, elapsed_ms = service.search(query, top_k=3)
        
        print(f"耗时: {elapsed_ms:.2f}ms")
        print(f"结果数: {len(results)}")
        
        for i, result in enumerate(results):
            print(f"  {i+1}. [{result.score:.3f}] {result.content[:50]}...")


if __name__ == "__main__":
    main()
