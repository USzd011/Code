#!/bin/bash
# 星辰大脑 v5.0 一键部署脚本
# 适用于：2核4G内存，40G存储的服务器

set -e

echo "========================================="
echo "星辰大脑 v5.0 一键部署脚本"
echo "========================================="

# ========== 环境检查 ==========

echo "[1/8] 检查环境..."

# 检查系统
if [ ! -f /etc/os-release ]; then
    echo "错误：无法识别操作系统"
    exit 1
fi

# 检查资源
CPU_CORES=$(nproc)
MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
DISK_TOTAL=$(df -m / | awk 'NR==2 {print $2}')

echo "CPU: ${CPU_CORES}核"
echo "内存: ${MEM_TOTAL}MB"
echo "磁盘: ${DISK_TOTAL}MB"

if [ $CPU_CORES -lt 2 ] || [ $MEM_TOTAL -lt 3500 ] || [ $DISK_TOTAL -lt 35000 ]; then
    echo "警告：资源可能不足，建议至少2核4G内存40G存储"
fi

# ========== 安装依赖 ==========

echo "[2/8] 安装依赖..."

# 更新系统
apt update -qq

# 安装Docker
if ! command -v docker &> /dev/null; then
    echo "安装Docker..."
    curl -fsSL https://get.docker.com | bash
fi

# 安装Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "安装Docker Compose..."
    pip install docker-compose -q
fi

# 安装Python依赖
pip install fastapi uvicorn pymilvus redis psycopg2-binary -q

# ========== 创建目录 ==========

echo "[3/8] 创建目录..."

mkdir -p /root/starbrain/{data,logs,config,api}
mkdir -p /root/starbrain/data/{pg,redis}

# ========== 部署PostgreSQL ==========

echo "[4/8] 部署PostgreSQL..."

docker run -d --name starbrain-postgres \
    --restart unless-stopped \
    -p 5432:5432 \
    -e POSTGRES_USER=starbrain \
    -e POSTGRES_PASSWORD=starbrain123 \
    -e POSTGRES_DB=starbrain \
    -v /root/starbrain/data/pg:/var/lib/postgresql/data \
    postgres:15-alpine

# 等待启动
sleep 5

# 安装pgvector扩展
docker exec starbrain-postgres psql -U starbrain -d starbrain -c "CREATE EXTENSION IF NOT EXISTS vector;" || true

echo "PostgreSQL部署完成"

# ========== 部署Redis ==========

echo "[5/8] 部署Redis..."

docker run -d --name starbrain-redis \
    --restart unless-stopped \
    -p 6379:6379 \
    -v /root/starbrain/data/redis:/data \
    redis:7-alpine \
    redis-server --maxmemory 200mb --save 60 1000

echo "Redis部署完成"

# ========== 复制API代码 ==========

echo "[6/8] 复制API代码..."

# 从workspace复制
if [ -d /root/.openclaw/workspace/starbrain-v5/api ]; then
    cp -r /root/.openclaw/workspace/starbrain-v5/api/* /root/starbrain/api/
else
    echo "创建API代码..."
    cat > /root/starbrain/api/app.py << 'APICODE'
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, Any, Optional
import uuid
import time

app = FastAPI(title="星辰大脑 API")

tasks_db = {}

class TriggerRequest(BaseModel):
    intent: str
    params: Dict[str, Any] = {}
    priority: int = 2

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": int(time.time())}

@app.post("/coze/trigger")
async def trigger(request: TriggerRequest):
    task_id = f"task_{uuid.uuid4().hex[:16]}"
    tasks_db[task_id] = {"status": "queued", "created": time.time()}
    return {"success": True, "task_id": task_id, "status": "queued"}

@app.get("/coze/task/{task_id}")
async def status(task_id: str):
    task = tasks_db.get(task_id, {"status": "unknown"})
    return task

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
APICODE
fi

echo "API代码复制完成"

# ========== 启动API服务 ==========

echo "[7/8] 启动API服务..."

cd /root/starbrain/api

# 停止旧进程
pkill -f "python.*app.py" || true
pkill -f "uvicorn.*:8000" || true

# 启动新进程
nohup python3 app.py > /root/starbrain/logs/api.log 2>&1 &

sleep 2

# 检查是否启动
if curl -s http://localhost:8000/health > /dev/null; then
    echo "API服务启动成功"
else
    echo "警告：API服务可能未正常启动，请检查日志"
fi

# ========== 配置Nginx ==========

echo "[8/8] 配置Nginx..."

# 安装Nginx
apt install nginx -y -qq

# 配置反向代理
cat > /etc/nginx/sites-available/starbrain << 'NGINXCONF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /health {
        proxy_pass http://127.0.0.1:8000/health;
    }
}
NGINXCONF

# 启用配置
ln -sf /etc/nginx/sites-available/starbrain /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# 测试并重启
nginx -t && systemctl restart nginx

echo "Nginx配置完成"

# ========== 完成 ==========

echo ""
echo "========================================="
echo "部署完成！"
echo "========================================="
echo ""
echo "服务状态："
echo "  PostgreSQL: localhost:5432"
echo "  Redis:      localhost:6379"
echo "  API:        localhost:8000"
echo "  Nginx:      localhost:80"
echo ""
echo "测试命令："
echo "  curl http://localhost/health"
echo "  curl -X POST http://localhost/coze/trigger -H 'Content-Type: application/json' -d '{\"intent\":\"test\"}'"
echo ""
echo "日志位置："
echo "  /root/starbrain/logs/api.log"
echo ""
echo "下一步："
echo "  1. 配置扣子对接"
echo "  2. 测试API接口"
echo "  3. 部署业务逻辑"
echo ""