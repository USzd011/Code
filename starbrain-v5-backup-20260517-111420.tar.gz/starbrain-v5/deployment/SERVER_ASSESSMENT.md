# 4号服务器资源评估

> **服务器配置：** 2核4G内存，40G存储

---

## 一、资源需求分析

### 各服务资源需求

| 服务 | CPU | 内存 | 存储 | 必需 |
|------|-----|------|------|------|
| PostgreSQL | 0.5核 | 512MB | 5GB | ✅ |
| Redis | 0.2核 | 256MB | 1GB | ✅ |
| Milvus | 1核 | 1GB | 10GB | ✅ |
| MCTS API | 0.3核 | 256MB | 1GB | ✅ |
| 技能评估API | 0.2核 | 128MB | 1GB | ✅ |
| Kong网关 | 0.2核 | 128MB | 1GB | ⚠️ 可选 |
| Prometheus | 0.2核 | 256MB | 2GB | ⚠️ 可选 |
| Grafana | 0.1核 | 128MB | 1GB | ⚠️ 可选 |

### 总需求

| 类型 | 需求 | 可用 | 状态 |
|------|------|------|------|
| CPU | 2.7核 | 2核 | ⚠️ 略紧 |
| 内存 | 2.6GB | 4GB | ✅ 足够 |
| 存储 | 22GB | 40GB | ✅ 足够 |

---

## 二、部署方案

### 方案A：精简部署（推荐）

**只部署核心服务，不部署监控**

```
✅ PostgreSQL     - 数据存储
✅ Redis          - 缓存
✅ Milvus         - 向量检索
✅ MCTS API       - 决策引擎
✅ 技能评估API    - 进化系统
```

**资源占用：**
- CPU: 2.2核（110%利用率，可接受）
- 内存: 2.1GB（52%利用率）
- 存储: 19GB（47%利用率）

**优点：** 核心功能完整，资源刚好够用
**缺点：** 无监控，需手动排查问题

---

### 方案B：完整部署

**包含所有服务和监控**

**资源占用：**
- CPU: 2.7核（135%利用率，会卡顿）
- 内存: 2.6GB（65%利用率）
- 存储: 22GB（55%利用率）

**风险：** CPU超载，服务可能卡顿

---

## 三、优化建议

### 1. 使用轻量级替代

| 原服务 | 替代方案 | 节省资源 |
|--------|----------|----------|
| Milvus | pgvector | 0.5核+512MB |
| Kong | Nginx | 0.1核+64MB |
| Prometheus | 日志文件 | 0.2核+256MB |

### 2. 配置优化

```yaml
PostgreSQL:
  shared_buffers: 128MB  # 默认128MB，够用
  max_connections: 50     # 限制连接数

Redis:
  maxmemory: 200MB        # 限制内存使用

Milvus:
  # 使用单机模式，不部署集群
```

### 3. 服务合并

```yaml
合并方案:
  - MCTS API + 技能评估API → 合并为一个服务
  - 使用SQLite替代PostgreSQL（如果数据量小）
```

---

## 四、推荐部署方案

### 最终方案：精简 + 优化

| 服务 | 配置 | 状态 |
|------|------|------|
| PostgreSQL | 0.5核/512MB/5GB | ✅ 必需 |
| Redis | 0.2核/200MB/1GB | ✅ 必需 |
| pgvector | 0.3核/512MB/5GB | ✅ 替代Milvus |
| API服务 | 0.5核/512MB/2GB | ✅ 合并部署 |
| Nginx | 0.1核/64MB/1GB | ✅ 替代Kong |

**总占用：**
- CPU: 1.6核（80%利用率）✅
- 内存: 1.8GB（45%利用率）✅
- 存储: 14GB（35%利用率）✅

**预留：**
- CPU: 0.4核（20%预留）
- 内存: 2.2GB（55%预留）
- 存储: 26GB（65%预留）

---

## 五、部署步骤

### Step 1: 环境准备

```bash
# 安装Docker
curl -fsSL https://get.docker.com | bash

# 安装Docker Compose
pip install docker-compose

# 创建目录
mkdir -p /root/starbrain/{data,logs,config}
```

### Step 2: 部署数据库

```bash
# PostgreSQL + pgvector
docker run -d --name postgres \
  -p 5432:5432 \
  -e POSTGRES_PASSWORD=starbrain123 \
  -v /root/starbrain/data/pg:/var/lib/postgresql/data \
  postgres:15

# 安装pgvector扩展
docker exec -it postgres psql -U postgres -c "CREATE EXTENSION vector;"
```

### Step 3: 部署Redis

```bash
docker run -d --name redis \
  -p 6379:6379 \
  -v /root/starbrain/data/redis:/data \
  redis:7-alpine \
  redis-server --maxmemory 200mb
```

### Step 4: 部署API服务

```bash
# 复制代码
cp -r /root/.openclaw/workspace/starbrain-v5/api /root/starbrain/

# 启动服务
cd /root/starbrain/api
nohup python3 coze_integration.py > /root/starbrain/logs/api.log 2>&1 &
```

### Step 5: 配置Nginx

```bash
# 安装Nginx
apt install nginx -y

# 配置反向代理
cat > /etc/nginx/sites-available/starbrain << 'EOF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF

ln -s /etc/nginx/sites-available/starbrain /etc/nginx/sites-enabled/
nginx -t && systemctl restart nginx
```

---

## 六、验收标准

### 资源使用

- [ ] CPU使用率 < 80%
- [ ] 内存使用率 < 60%
- [ ] 磁盘使用率 < 50%

### 服务状态

- [ ] PostgreSQL运行正常
- [ ] Redis运行正常
- [ ] API服务运行正常
- [ ] Nginx代理正常

---

## 七、下一步

1. 杨欢提供4号服务器访问权限
2. 执行部署脚本
3. 验证服务状态
4. 配置扣子对接

---

_创建时间: 2026-05-09_
