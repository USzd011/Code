# Milvus 向量数据库部署指南

> **目标：** 部署Milvus实现语义检索能力

---

## 一、部署方案

### 方案选择

| 方案 | 优点 | 缺点 | 推荐 |
|------|------|------|------|
| Docker Compose | 简单快速 | 单机 | ✅ 开发测试 |
| Kubernetes | 高可用 | 复杂 | 生产环境 |
| Milvus Lite | 最简单 | 功能有限 | 快速验证 |

**决策：** Docker Compose（开发测试）

---

## 二、Docker Compose 部署

### 1. 创建配置文件

```yaml
# docker-compose.yml
version: '3.5'

services:
  etcd:
    container_name: milvus-etcd
    image: quay.io/coreos/etcd:v3.5.5
    environment:
      - ETCD_AUTO_COMPACTION_MODE=revision
      - ETCD_AUTO_COMPACTION_RETENTION=1000
      - ETCD_QUOTA_BACKEND_BYTES=4294967296
    volumes:
      - ${DOCKER_VOLUME_DIRECTORY:-.}/volumes/etcd:/etcd
    command: etcd -advertise-client-urls=http://127.0.0.1:2379 -listen-client-urls http://0.0.0.0:2379 --data-dir /etcd

  minio:
    container_name: milvus-minio
    image: minio/minio:RELEASE.2023-03-20T20-16-18Z
    environment:
      MINIO_ACCESS_KEY: minioadmin
      MINIO_SECRET_KEY: minioadmin
    volumes:
      - ${DOCKER_VOLUME_DIRECTORY:-.}/volumes/minio:/minio_data
    command: minio server /minio_data
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 20s
      retries: 3

  standalone:
    container_name: milvus-standalone
    image: milvusdb/milvus:v2.3.3
    command: ["milvus", "run", "standalone"]
    environment:
      ETCD_ENDPOINTS: etcd:2379
      MINIO_ADDRESS: minio:9000
    volumes:
      - ${DOCKER_VOLUME_DIRECTORY:-.}/volumes/milvus:/var/lib/milvus
    ports:
      - "19530:19530"
      - "9091:9091"
    depends_on:
      - "etcd"
      - "minio"

networks:
  default:
    name: milvus
```

### 2. 启动命令

```bash
# 创建目录
mkdir -p /root/milvus/volumes/{etcd,minio,milvus}

# 启动服务
cd /root/milvus
docker-compose up -d

# 检查状态
docker-compose ps

# 查看日志
docker-compose logs -f standalone
```

---

## 三、Python SDK 集成

### 1. 安装依赖

```bash
pip install pymilvus openai
```

### 2. 连接测试

```python
from pymilvus import connections, utility

# 连接
connections.connect(
    alias="default",
    host='localhost',
    port='19530'
)

# 检查连接
print("Milvus版本:", utility.get_server_version())

# 断开连接
connections.disconnect("default")
```

---

## 四、Collection 设计

### 记忆向量 Collection

```python
from pymilvus import Collection, FieldSchema, CollectionSchema, DataType

# 定义字段
fields = [
    FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
    FieldSchema(name="memory_id", dtype=DataType.VARCHAR, max_length=64),
    FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=2000),
    FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=1536),
    FieldSchema(name="source", dtype=DataType.VARCHAR, max_length=64),
    FieldSchema(name="created_at", dtype=DataType.INT64),
]

# 创建schema
schema = CollectionSchema(
    fields=fields,
    description="星辰大脑记忆向量库"
)

# 创建collection
collection = Collection(
    name="starbrain_memories",
    schema=schema
)

# 创建索引
index_params = {
    "metric_type": "COSINE",
    "index_type": "IVF_FLAT",
    "params": {"nlist": 1024}
}

collection.create_index(
    field_name="embedding",
    index_params=index_params
)
```

---

## 五、语义检索实现

```python
from openai import OpenAI
from pymilvus import Collection

class SemanticSearch:
    def __init__(self, collection_name="starbrain_memories"):
        self.collection = Collection(name=collection_name)
        self.collection.load()
        self.openai_client = OpenAI()
    
    def get_embedding(self, text: str) -> list:
        """获取文本向量"""
        response = self.openai_client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    
    def search(self, query: str, top_k: int = 10) -> list:
        """语义检索"""
        # 获取查询向量
        query_embedding = self.get_embedding(query)
        
        # 搜索
        results = self.collection.search(
            data=[query_embedding],
            anns_field="embedding",
            param={"metric_type": "COSINE", "params": {"nprobe": 10}},
            limit=top_k,
            output_fields=["memory_id", "content", "source"]
        )
        
        return results[0]
    
    def insert(self, memory_id: str, content: str, source: str):
        """插入记忆"""
        embedding = self.get_embedding(content)
        
        self.collection.insert([
            [memory_id],
            [content],
            [embedding],
            [source],
            [int(time.time())]
        ])
```

---

## 六、验收标准

| 指标 | 目标值 |
|------|--------|
| 部署时间 | < 10分钟 |
| 连接延迟 | < 10ms |
| 插入延迟 | < 100ms |
| 检索延迟 | < 50ms |
| 检索准确率 | > 85% |

---

## 七、下一步

1. 执行部署脚本
2. 测试连接
3. 创建Collection
4. 迁移历史记忆
5. 集成到记忆系统

---

_创建时间: 2026-05-09_
