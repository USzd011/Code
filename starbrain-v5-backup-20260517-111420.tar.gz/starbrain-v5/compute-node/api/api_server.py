"""
星辰大脑 v5.0 - 算力节点 API 服务
"""
import json, time, threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Optional


class ComputeAPIHandler(BaseHTTPRequestHandler):
    """算力节点 REST API"""

    node = None  # 由外部注入

    def do_GET(self):
        if self.path == "/status":
            self._json_response(self.node.status())
        elif self.path == "/health":
            snap = self.node.resource_monitor.health()
            snap["workers"] = self.node.worker_pool.status()
            self._json_response(snap)
        elif self.path == "/resources":
            self._json_response(self.node.resource_monitor.snapshot())
        elif self.path == "/tasks":
            self._json_response(self.node.node_manager.status_report())
        elif self.path == "/handlers":
            from workers.worker_pool import TASK_HANDLERS
            self._json_response({"handlers": list(TASK_HANDLERS.keys())})
        else:
            self._json_response({"error": "not found"}, 404)

    def do_POST(self):
        if self.path == "/task":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length) if length else b"{}"
            data = json.loads(body)
            task = self.node.submit(
                task_type=data.get("type", "ping"),
                payload=data.get("payload", {}),
                priority=data.get("priority", 2),
            )
            self._json_response(task)
        elif self.path == "/start":
            self._json_response({"status": "already_running"})
        elif self.path == "/stop":
            threading.Thread(target=self.node.stop, daemon=True).start()
            self._json_response({"status": "stopping"})
        else:
            self._json_response({"error": "not found"}, 404)

    def _json_response(self, data: dict, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, indent=2,
                                    default=str).encode())

    def log_message(self, format, *args):
        pass  # 减少日志噪音


class APIServer:
    """API 服务"""

    def __init__(self, compute_node, host: str = "0.0.0.0", port: int = 8899):
        ComputeAPIHandler.node = compute_node
        self.host = host
        self.port = port
        self.server = HTTPServer((host, port), ComputeAPIHandler)
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self.server.serve_forever,
                                        daemon=True)
        self._thread.start()
        print(f"🌐 API服务: http://{self.host}:{self.port}")
        print(f"   ├ GET  /status   - 完整状态")
        print(f"   ├ GET  /health   - 健康检查")
        print(f"   ├ GET  /resources - 资源监控")
        print(f"   ├ GET  /tasks    - 任务状态")
        print(f"   ├ GET  /handlers - 处理器列表")
        print(f"   ├ POST /task     - 提交任务")
        print(f"   └ POST /stop     - 停止节点")

    def stop(self):
        self.server.shutdown()
