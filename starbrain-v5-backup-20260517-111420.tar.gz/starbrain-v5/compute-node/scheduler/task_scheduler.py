"""
星辰大脑 v5.0 - 任务调度器
混元河洛大阵 · 决策层 (L5)
"""
import json, time, heapq, uuid
from datetime import datetime
from typing import Optional, Callable
from dataclasses import dataclass, field


@dataclass(order=True)
class ScheduledTask:
    priority: int
    scheduled_at: float
    task_id: str = field(compare=False)
    task_type: str = field(compare=False)
    payload: dict = field(compare=False)
    max_retries: int = field(default=3, compare=False)
    retry_count: int = field(default=0, compare=False)
    timeout: int = field(default=300, compare=False)
    status: str = field(default="pending", compare=False)


class TaskScheduler:
    """混元河洛调度引擎"""

    def __init__(self):
        self.queue = []          # 优先级队列（堆）
        self.pending = {}        # task_id -> task
        self.history = []        # 已完成历史
        self.callbacks = {}      # event -> handler

    def schedule(self, task_type: str, payload: dict,
                 priority: int = 2, delay: float = 0,
                 task_id: str = None, timeout: int = 300) -> str:
        """调度一个任务"""
        tid = task_id or f"star-{uuid.uuid4().hex[:12]}"
        task = ScheduledTask(
            priority=priority,
            scheduled_at=time.time() + delay,
            task_id=tid,
            task_type=task_type,
            payload=payload,
            timeout=timeout,
            status="pending",
        )
        heapq.heappush(self.queue, task)
        self.pending[tid] = task
        return tid

    def schedule_cron(self, task_type: str, payload: dict,
                      interval: int, priority: int = 2,
                      task_id: str = None) -> str:
        """调度周期性任务"""
        tid = self.schedule(task_type, payload, priority, task_id=task_id)
        # 注册周期标记
        if not hasattr(self, '_cron_tasks'):
            self._cron_tasks = {}
        self._cron_tasks[tid] = interval
        return tid

    def _on_event(self, event: str, callback: Callable):
        """注册事件回调"""
        if event not in self.callbacks:
            self.callbacks[event] = []
        self.callbacks[event].append(callback)

    def _emit(self, event: str, data: dict):
        """触发事件"""
        for cb in self.callbacks.get(event, []):
            try:
                cb(data)
            except Exception as e:
                pass

    def poll(self) -> list:
        """获取到期任务"""
        now = time.time()
        ready = []
        while self.queue and self.queue[0].scheduled_at <= now:
            task = heapq.heappop(self.queue)
            if task.task_id in self.pending:
                task.status = "dispatching"
                ready.append(task)
        return ready

    def complete(self, task_id: str, result: dict):
        """完成任务"""
        if task_id in self.pending:
            task = self.pending.pop(task_id)
            task.status = "completed"
            self.history.append({
                "task_id": task_id,
                "type": task.task_type,
                "status": "completed",
                "result": result,
                "completed_at": time.time(),
            })
            self._emit("task.completed", {"task_id": task_id, "result": result})

            # 周期性任务重新调度
            if hasattr(self, '_cron_tasks') and task_id in self._cron_tasks:
                interval = self._cron_tasks[task_id]
                new_id = self.schedule(task.task_type, task.payload,
                                       task.priority, delay=interval,
                                       task_id=task_id)
                self._cron_tasks[new_id] = interval

            if len(self.history) > 200:
                self.history = self.history[-200:]

    def fail(self, task_id: str, error: str):
        """任务失败（可重试）"""
        if task_id in self.pending:
            task = self.pending[task_id]
            task.retry_count += 1
            if task.retry_count < task.max_retries:
                task.status = "retrying"
                task.scheduled_at = time.time() + 5 * task.retry_count
                heapq.heappush(self.queue, task)
            else:
                task.status = "failed"
                self.pending.pop(task_id)
                self.history.append({
                    "task_id": task_id,
                    "type": task.task_type,
                    "status": "failed",
                    "error": error,
                    "failed_at": time.time(),
                })
                self._emit("task.failed", {"task_id": task_id, "error": error})

    def status(self) -> dict:
        return {
            "queued": len(self.queue),
            "pending": len(self.pending),
            "history": len(self.history),
            "cron_tasks": len(getattr(self, '_cron_tasks', {})),
        }
