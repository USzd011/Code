"""
星辰大脑 v5.0 - 算力节点管理器
九曜星君阵 · 多线程执行层 (L6)

管理 worker 池、任务调度、资源监控
"""
import os, json, time, logging, signal, sys
from datetime import datetime
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('NodeManager')

CONFIG = {
    "max_workers": 4,           # 最大并行worker数 (当前4核)
    "task_queue_max": 100,      # 任务队列容量
    "heartbeat_interval": 10,   # 心跳间隔(秒)
    "task_timeout": 300,        # 任务超时(秒)
    "retry_max": 3,             # 最大重试次数
    "data_dir": os.path.join(os.path.dirname(__file__), "data")
}


class NodeManager:
    """算力节点管理器 - 九曜星君阵核心"""

    def __init__(self, config: Optional[dict] = None):
        self.config = {**CONFIG, **(config or {})}
        self.workers = {}          # worker_id -> WorkerInfo
        self.task_queue = []       # 待执行任务
        self.running_tasks = {}    # 执行中的任务
        self.completed_tasks = []  # 已完成任务(保留最近100条)
        self.status = "idle"
        self.start_time = time.time()

        # 创建数据目录
        os.makedirs(self.config["data_dir"], exist_ok=True)

        log.info(f"🔱 九曜星君阵 · 节点管理器初始化")
        log.info(f"   ├ Workers: {self.config['max_workers']}")
        log.info(f"   ├ 超时: {self.config['task_timeout']}s")
        log.info(f"   └ 重试: {self.config['retry_max']}次")

    def submit_task(self, task_type: str, payload: dict,
                    priority: int = 2, task_id: str = None) -> dict:
        """提交任务到队列"""
        import uuid
        task = {
            "id": task_id or f"task-{uuid.uuid4().hex[:12]}",
            "type": task_type,
            "payload": payload,
            "priority": priority,       # 1=紧急 2=重要 3=一般
            "status": "queued",
            "created_at": time.time(),
            "retry_count": 0,
            "max_retries": self.config["retry_max"],
        }

        # 按优先级插入
        inserted = False
        for i, t in enumerate(self.task_queue):
            if t["priority"] > task["priority"]:
                self.task_queue.insert(i, task)
                inserted = True
                break
        if not inserted:
            self.task_queue.append(task)

        log.info(f"📥 任务入队 [{task['id']}] {task_type} (P{priority})")
        self._persist_state()
        return task

    def get_worker(self) -> Optional[dict]:
        """获取可用worker"""
        for wid, w in self.workers.items():
            if w["status"] == "idle":
                return w
        return None

    def dispatch(self) -> int:
        """调度: 将队列任务分配给空闲worker"""
        dispatched = 0
        while self.task_queue:
            w = self.get_worker()
            if not w:
                break

            task = self.task_queue.pop(0)
            # 启动worker执行
            w["status"] = "busy"
            w["current_task"] = task["id"]
            w["task_start"] = time.time()
            self.running_tasks[task["id"]] = {
                **task,
                "status": "running",
                "started_at": time.time(),
                "worker_id": w["id"],
            }
            dispatched += 1
            log.info(f"▶️ 调度 [{task['id']}] → Worker [{w['id']}] (优先级P{task['priority']})")

        return dispatched

    def complete_task(self, task_id: str, result: dict, success: bool = True):
        """完成任务"""
        if task_id in self.running_tasks:
            task = self.running_tasks.pop(task_id)
            task["status"] = "completed" if success else "failed"
            task["result"] = result
            task["completed_at"] = time.time()
            task["duration"] = task["completed_at"] - task.get("started_at", task["completed_at"])
            self.completed_tasks.append(task)

            # 释放worker
            wid = task.get("worker_id")
            if wid and wid in self.workers:
                self.workers[wid]["status"] = "idle"
                self.workers[wid]["current_task"] = None
                self.workers[wid]["task_count"] = self.workers[wid].get("task_count", 0) + 1

            # 保持最近100条
            if len(self.completed_tasks) > 100:
                self.completed_tasks = self.completed_tasks[-100:]

            status_icon = "✅" if success else "❌"
            log.info(f"{status_icon} [{task_id}] 完成 ({task.get('duration', 0):.1f}s)")
            self._persist_state()

    def fail_task(self, task_id: str, error: str):
        """任务失败处理 (可重试)"""
        if task_id in self.running_tasks:
            task = self.running_tasks.pop(task_id)
            task["retry_count"] += 1

            if task["retry_count"] < task["max_retries"]:
                # 重新入队
                log.warning(f"🔄 [{task_id}] 重试 ({task['retry_count']}/{task['max_retries']})")
                self.task_queue.insert(0, task)
            else:
                self.complete_task(task_id, {"error": error}, success=False)

    def status_report(self) -> dict:
        """生成状态报告"""
        return {
            "status": self.status,
            "uptime": int(time.time() - self.start_time),
            "workers": {
                "total": len(self.workers),
                "idle": sum(1 for w in self.workers.values() if w["status"] == "idle"),
                "busy": sum(1 for w in self.workers.values() if w["status"] == "busy"),
            },
            "tasks": {
                "queued": len(self.task_queue),
                "running": len(self.running_tasks),
                "completed": len(self.completed_tasks),
                "completed_last_hour": sum(
                    1 for t in self.completed_tasks
                    if t.get("completed_at", 0) > time.time() - 3600
                ),
            },
            "timestamp": datetime.now().isoformat(),
        }

    def _persist_state(self):
        """持久化状态到磁盘"""
        state = {
            "workers": self.workers,
            "task_queue": self.task_queue,
            "running_tasks": self.running_tasks,
            "completed_tasks": self.completed_tasks[-20:],  # 只保留最近20条
            "status": self.status,
        }
        path = os.path.join(self.config["data_dir"], "node_state.json")
        with open(path, "w") as f:
            json.dump(state, f, indent=2, default=str)

    def shutdown(self):
        """优雅关闭"""
        log.info("🛑 节点管理器关闭中...")
        self.status = "shutting_down"
        self._persist_state()
        log.info("✅ 节点管理器已关闭")


if __name__ == "__main__":
    mgr = NodeManager()
    print(json.dumps(mgr.status_report(), indent=2, ensure_ascii=False))
