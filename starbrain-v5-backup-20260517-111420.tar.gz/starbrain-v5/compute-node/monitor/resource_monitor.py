"""
星辰大脑 v5.0 - 算力资源监控
周天星斗大阵 · 感知层 (L3)
"""
import os, json, time, logging, threading
from datetime import datetime
from typing import Optional

log = logging.getLogger('ResourceMonitor')


class ResourceMonitor:
    """资源监控器"""

    def __init__(self, history_size: int = 360):
        self.history_size = history_size
        self.history = []
        self._running = False
        self._thread = None

    def _get_cpu_percent(self) -> float:
        """获取CPU使用率"""
        try:
            with open('/proc/stat', 'r') as f:
                first = [float(x) for x in f.readline().split()[1:]]
            import time
            time.sleep(0.1)
            with open('/proc/stat', 'r') as f:
                second = [float(x) for x in f.readline().split()[1:]]

            if len(first) >= 4 and len(second) >= 4:
                total = sum(second) - sum(first)
                idle = second[3] - first[3]
                if total > 0:
                    return 100.0 * (1 - idle / total)
        except Exception:
            pass
        return 0.0

    def _get_memory_info(self) -> dict:
        """获取内存信息"""
        try:
            with open('/proc/meminfo', 'r') as f:
                lines = f.readlines()
            mem_total = int([l for l in lines if 'MemTotal' in l][0].split()[1]) / 1024
            mem_avail = int([l for l in lines if 'MemAvailable' in l][0].split()[1]) / 1024
            mem_used = mem_total - mem_avail
            swap_total = int([l for l in lines if 'SwapTotal' in l][0].split()[1]) / 1024
            swap_free = int([l for l in lines if 'SwapFree' in l][0].split()[1]) / 1024
            return {
                "total_mb": round(mem_total, 1),
                "used_mb": round(mem_used, 1),
                "available_mb": round(mem_avail, 1),
                "percent": round(mem_used / mem_total * 100, 1),
                "swap_total_mb": round(swap_total, 1),
                "swap_free_mb": round(swap_free, 1),
            }
        except Exception:
            return {"error": "无法读取内存信息"}

    def _get_disk_info(self) -> dict:
        """获取磁盘信息"""
        try:
            stat = os.statvfs('/')
            total = stat.f_frsize * stat.f_blocks / (1024**3)
            free = stat.f_frsize * stat.f_bfree / (1024**3)
            used = total - free
            return {
                "total_gb": round(total, 1),
                "used_gb": round(used, 1),
                "free_gb": round(free, 1),
                "percent": round(used / total * 100, 1),
            }
        except Exception:
            return {"error": "无法读取磁盘信息"}

    def _get_load_avg(self) -> list:
        """获取系统负载"""
        try:
            with open('/proc/loadavg', 'r') as f:
                parts = f.read().strip().split()
                return [float(parts[0]), float(parts[1]), float(parts[2])]
        except Exception:
            return [0, 0, 0]

    def snapshot(self) -> dict:
        """采集一次资源快照"""
        return {
            "timestamp": datetime.now().isoformat(),
            "cpu": {
                "percent": self._get_cpu_percent(),
                "load_avg": self._get_load_avg(),
                "cores": os.cpu_count() or 1,
            },
            "memory": self._get_memory_info(),
            "disk": self._get_disk_info(),
        }

    def record(self):
        """记录一次快照到历史"""
        snap = self.snapshot()
        self.history.append(snap)
        if len(self.history) > self.history_size:
            self.history = self.history[-self.history_size:]
        return snap

    def _loop(self):
        """后台采集循环"""
        while self._running:
            try:
                self.record()
            except Exception as e:
                log.error(f"资源监控异常: {e}")
            time.sleep(5)  # 每5秒采集一次

    def start(self):
        """启动后台监控"""
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        log.info("📊 资源监控已启动 (5s间隔)")

    def stop(self):
        """停止监控"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        log.info("📊 资源监控已停止")

    def summary(self) -> dict:
        """生成资源摘要"""
        if not self.history:
            return self.snapshot()
        latest = self.history[-1]
        recent = [h for h in self.history[-12:]]  # 最近1分钟
        avg_cpu = sum(h["cpu"]["percent"] for h in recent) / len(recent) if recent else 0
        return {
            "current": latest,
            "avg_cpu_1m": round(avg_cpu, 1),
            "samples": len(self.history),
        }

    def health(self) -> dict:
        """健康检查"""
        snap = self.snapshot()
        issues = []
        if snap["memory"]["percent"] > 90:
            issues.append("内存使用率>90%")
        if snap["disk"]["percent"] > 90:
            issues.append("磁盘使用率>90%")
        if snap["cpu"]["load_avg"][0] > os.cpu_count() * 2:
            issues.append("CPU负载过高")
        return {
            "healthy": len(issues) == 0,
            "issues": issues,
            "snapshot_id": datetime.now().isoformat(),
        }


if __name__ == "__main__":
    mon = ResourceMonitor()
    print(json.dumps(mon.snapshot(), indent=2, ensure_ascii=False))
    print(json.dumps(mon.health(), indent=2, ensure_ascii=False))
