"""
星辰大脑 v5.0 - 算力节点控制台
九曜星君阵 · 主入口
"""
import os, sys, json, time, logging, threading, signal
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('ComputeNode')

# 添加模块路径
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

from node_manager import NodeManager
from workers.worker_pool import WorkerPool, TASK_HANDLERS
from monitor.resource_monitor import ResourceMonitor


class ComputeNode:
    """算力节点 - 九曜星君阵完整实现"""

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.running = False
        self._main_thread = None
        self._api_thread = None

        # 初始化组件
        log.info("=" * 50)
        log.info("🔱 星辰大脑 · 算力节点 初始化")
        log.info("=" * 50)

        self.resource_monitor = ResourceMonitor()
        self.node_manager = NodeManager(self.config)
        self.worker_pool = WorkerPool(count=self.config.get("max_workers", 4))

        # 注册任务处理器
        self._register_builtin_handlers()

        log.info(f"📋 已注册处理器: {list(TASK_HANDLERS.keys())}")

    def _register_builtin_handlers(self):
        """注册内置任务处理器"""
        from workers.worker_pool import register_handler

        @register_handler("compute")
        def handle_compute(payload):
            """通用计算任务"""
            operation = payload.get("operation", "identity")
            data = payload.get("data", {})
            log.info(f"  🔢 计算: {operation}")
            return {"operation": operation, "result": data, "status": "ok"}

        @register_handler("resource_query")
        def handle_resource_query(payload):
            """查询当前资源状态"""
            return self.resource_monitor.summary()

        @register_handler("status_query")
        def handle_status_query(payload):
            """查询节点状态"""
            return self.node_manager.status_report()

        @register_handler("dispatch")
        def handle_dispatch(payload):
            """调度任务"""
            task_type = payload.get("type", "ping")
            task_payload = payload.get("payload", {})
            priority = payload.get("priority", 2)
            task = self.node_manager.submit_task(task_type, task_payload, priority)
            return {"task_id": task["id"], "status": "queued"}

    def start(self):
        """启动算力节点"""
        log.info("🚀 启动算力节点...")

        # 启动资源监控
        self.resource_monitor.start()

        # 启动Worker池
        self.worker_pool.start()

        # 初始化NodeManager中的Worker信息
        for w in self.worker_pool.workers:
            self.node_manager.workers[w.worker_id] = {
                "id": w.worker_id,
                "name": w.name,
                "pid": w.pid,
                "status": "idle",
                "current_task": None,
                "task_count": 0,
                "alive": w.is_alive(),
            }

        self.node_manager.status = "running"
        self.running = True

        # 启动调度循环
        self._main_thread = threading.Thread(target=self._main_loop, daemon=True)
        self._main_thread.start()

        log.info("✅ 算力节点已启动")
        self._print_banner()
        return self

    def _main_loop(self):
        """主调度循环"""
        while self.running:
            try:
                # 1. 收集worker结果
                results = self.worker_pool.get_results(timeout=0.1)
                for r in results:
                    tid = r.get("task_id")
                    result = r.get("result", {})
                    success = result.get("success", False)
                    if success:
                        self.node_manager.complete_task(tid, result.get("output", {}))
                    else:
                        self.node_manager.fail_task(tid, result.get("error", "未知错误"))

                # 2. 调度新任务
                while self.node_manager.task_queue:
                    task = self.node_manager.task_queue[0]
                    # 如果有空闲worker，提交给worker池
                    if self._has_idle_worker():
                        task = self.node_manager.task_queue.pop(0)
                        self.worker_pool.submit(task)
                        # 更新node_manager状态
                        wid = self._get_idle_worker_id()
                        if wid:
                            self.node_manager.workers[wid]["status"] = "busy"
                            self.node_manager.workers[wid]["current_task"] = task["id"]
                            self.node_manager.running_tasks[task["id"]] = {
                                **task, "status": "running", "started_at": time.time(),
                                "worker_id": wid,
                            }
                    else:
                        break

                # 3. 每分钟报告一次状态
                if int(time.time()) % 60 == 0:
                    report = self.node_manager.status_report()
                    log.info(f"📊 {report['tasks']['completed']}完成 | "
                             f"{report['tasks']['queued']}排队 | "
                             f"{report['tasks']['running']}运行中")

            except Exception as e:
                log.error(f"主循环异常: {e}")
            time.sleep(0.5)

    def _has_idle_worker(self) -> bool:
        return self._get_idle_worker_id() is not None

    def _get_idle_worker_id(self) -> Optional[str]:
        for wid, w in self.node_manager.workers.items():
            if w["status"] == "idle":
                return wid
        return None

    def submit(self, task_type: str, payload: dict, priority: int = 2) -> dict:
        """提交任务"""
        return self.node_manager.submit_task(task_type, payload, priority)

    def status(self) -> dict:
        """完整状态报告"""
        return {
            "node": self.node_manager.status_report(),
            "workers": self.worker_pool.status(),
            "resources": self.resource_monitor.summary(),
            "handlers": list(TASK_HANDLERS.keys()),
        }

    def _print_banner(self):
        """打印启动横幅"""
        snap = self.resource_monitor.snapshot()
        log.info("")
        log.info("🔱 星辰大脑 · 算力节点运行中")
        log.info(f"  Worker池: {self.worker_pool.count}/9曜")
        log.info(f"  CPU: {snap['cpu']['cores']}核 | 内存: {snap['memory']['total_mb']}MB")
        log.info(f"  任务队列: 0排队 | 已集成 {len(TASK_HANDLERS)}个处理器")
        log.info("")

    def stop(self):
        """停止节点"""
        log.info("🛑 停止算力节点...")
        self.running = False
        self.node_manager.shutdown()
        self.worker_pool.stop()
        self.resource_monitor.stop()
        log.info("✅ 算力节点已停止")


def main():
    """主入口"""
    import argparse
    parser = argparse.ArgumentParser(description="星辰大脑 v5.0 - 算力节点")
    parser.add_argument("--workers", type=int, default=4, help="Worker数量")
    parser.add_argument("--daemon", action="store_true", help="后台运行")
    args = parser.parse_args()

    config = {"max_workers": min(args.workers, 9)}

    node = ComputeNode(config)
    node.start()

    def handle_signal(sig, frame):
        log.info(f"收到信号 {sig}")
        node.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    if not args.daemon:
        # 交互式保持运行
        try:
            while node.running:
                time.sleep(1)
        except KeyboardInterrupt:
            node.stop()

    return node


if __name__ == "__main__":
    main()
