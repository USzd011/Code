"""
星辰大脑 v5.0 - 算力节点配置
"""
NODE_CONFIG = {
    "name": "4号腾云·九曜星君阵",
    "version": "v5.0",

    # Worker配置
    "max_workers": 4,
    "task_queue_max": 100,
    "task_timeout": 300,      # 任务超时(秒)
    "retry_max": 3,           # 最大重试次数

    # 资源阈值
    "resource_limits": {
        "max_cpu_percent": 85,
        "max_memory_percent": 85,
        "max_disk_percent": 90,
    },

    # 服务端口
    "api_port": 8899,
    "heartbeat_interval": 10,

    # 数据目录
    "data_dir": "./data",
}
