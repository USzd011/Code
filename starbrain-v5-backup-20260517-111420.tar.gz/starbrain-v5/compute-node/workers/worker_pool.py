"""
星辰大脑 v5.0 - Worker 执行器
九曜星君 · 多线程工兵
"""
import os, sys, json, time, logging, signal
from multiprocessing import Process, Queue, Event
from typing import Optional, Callable

log = logging.getLogger('Worker')

# 九曜星君命名
WORKER_NAMES = [
    ("日耀", "Sun"), ("月华", "Moon"), ("金耀", "Venus"), ("木灵", "Jupiter"),
    ("水柔", "Mercury"), ("火烈", "Mars"), ("土坤", "Saturn"),
    ("罗睺", "Rahu"), ("计都", "Ketu"),
]


class WorkerProcess(Process):
    """单个worker进程"""

    def __init__(self, worker_id: str, task_queue: Queue,
                 result_queue: Queue, stop_event: Event):
        super().__init__(name=f"Worker-{worker_id}")
        self.worker_id = worker_id
        self.task_queue = task_queue
        self.result_queue = result_queue
        self.stop_event = stop_event
        self.tasks_done = 0

    def run(self):
        """worker主循环"""
        log.info(f"🐉 [{self.worker_id}] Worker 启动")
        while not self.stop_event.is_set():
            try:
                task = self.task_queue.get(timeout=2)
                if task is None:
                    break
                self._execute_task(task)
            except Exception:
                # 超时或队列空，继续循环
                pass
        log.info(f"🛑 [{self.worker_id}] Worker 停止 (完成{self.tasks_done}个任务)")

    def _execute_task(self, task: dict):
        """执行单个任务"""
        task_id = task.get("id", "unknown")
        task_type = task.get("type", "unknown")
        log.info(f"  ⚡ [{self.worker_id}] 执行 [{task_id}] {task_type}")

        start = time.time()
        result = {"success": False, "output": "", "error": ""}

        try:
            handler = TASK_HANDLERS.get(task_type)
            if handler:
                output = handler(task.get("payload", {}))
                result = {"success": True, "output": output}
            else:
                result = {"success": False, "error": f"未知任务类型: {task_type}"}

            elapsed = time.time() - start
            result["duration"] = elapsed
            self.tasks_done += 1

        except Exception as e:
            elapsed = time.time() - start
            result = {"success": False, "error": str(e), "duration": elapsed}
            log.error(f"  ❌ [{self.worker_id}] [{task_id}] 失败: {e}")

        # 发送结果
        self.result_queue.put({
            "task_id": task_id,
            "worker_id": self.worker_id,
            "result": result,
            "completed_at": time.time(),
        })


class WorkerPool:
    """Worker池管理器"""

    def __init__(self, count: int = 4):
        self.count = min(count, 9)  # 最多9曜
        self.task_queue = Queue(maxsize=100)
        self.result_queue = Queue()
        self.stop_event = Event()
        self.workers = []
        self.handlers = {}

        # 创建workers
        for i in range(self.count):
            cn_name, en_name = WORKER_NAMES[i] if i < len(WORKER_NAMES) else ("无名", "Unknown")
            wid = f"{en_name}-{i+1:02d}"
            w = WorkerProcess(wid, self.task_queue, self.result_queue, self.stop_event)
            self.workers.append(w)

        log.info(f"⚡ Worker池: {self.count}个 ({', '.join(w.name for w in self.workers)})")

    def start(self):
        """启动所有worker"""
        for w in self.workers:
            w.start()
        log.info(f"✅ 全部Worker已启动")

    def submit(self, task: dict):
        """提交任务"""
        self.task_queue.put(task)

    def get_results(self, timeout: float = 0.1) -> list:
        """获取完成的result"""
        results = []
        while not self.result_queue.empty():
            try:
                results.append(self.result_queue.get(timeout=timeout))
            except Exception:
                break
        return results

    def stop(self):
        """停止所有worker"""
        log.info("🛑 停止Worker池...")
        self.stop_event.set()
        for _ in self.workers:
            self.task_queue.put(None)  # 发送停止信号
        for w in self.workers:
            w.join(timeout=10)
        log.info("✅ Worker池已停止")

    def status(self) -> dict:
        """获取状态"""
        return {
            "total": self.count,
            "alive": sum(1 for w in self.workers if w.is_alive()),
            "queue_size": self.task_queue.qsize(),
        }


# ===== 任务处理器注册 =====
TASK_HANDLERS = {}


def register_handler(task_type: str):
    """装饰器: 注册任务处理器"""
    def decorator(func):
        TASK_HANDLERS[task_type] = func
        return func
    return decorator


def get_handlers() -> dict:
    """获取所有已注册处理器"""
    return dict(TASK_HANDLERS)


# ===== 内置任务处理器 =====

@register_handler("ping")
def handle_ping(payload: dict) -> dict:
    return {"pong": True, "time": time.time()}


@register_handler("echo")
def handle_echo(payload: dict) -> dict:
    return payload


@register_handler("sleep")
def handle_sleep(payload: dict) -> dict:
    duration = payload.get("duration", 1)
    time.sleep(duration)
    return {"slept": duration}


if __name__ == "__main__":
    pool = WorkerPool(count=2)
    pool.start()

    pool.submit({"id": "test-1", "type": "ping", "payload": {}})
    pool.submit({"id": "test-2", "type": "sleep", "payload": {"duration": 2}})

    time.sleep(3)
    results = pool.get_results()
    for r in results:
        print(f"Result: {r}")

    pool.stop()
