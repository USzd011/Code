# 4号无服务器升级方案

> **约束：** 需要手动改服务器，杨欢无法操作
> **方案：** 纯配置升级，通过API和配置文件实现

---

## 一、升级策略

### 可行方式

| 方式 | 可行性 | 说明 |
|------|--------|------|
| API调用 | ✅ 可行 | 通过API接口操作 |
| 配置文件 | ✅ 可行 | 上传配置文件 |
| Webhook配置 | ✅ 可行 | 配置回调地址 |
| 服务器部署 | ❌ 不可行 | 无法操作 |

### 核心思路

**通过API和配置文件实现升级，不依赖服务器操作**

---

## 二、具体升级内容

### 1. API配置升级

**目标：** 配置星辰大脑API对接

**配置内容：**

```yaml
api_config:
  starbrain:
    base_url: "https://api.starbrain.example.com"
    endpoints:
      trigger: "/coze/trigger"
      status: "/coze/task/{id}"
      webhook: "/coze/webhook"
    
    auth:
      type: "bearer"
      token: "${STAR_BRAIN_TOKEN}"
    
    retry:
      max_retries: 3
      backoff: "exponential"
      initial_delay: 1000
```

---

### 2. Webhook配置

**目标：** 配置回调接收

**配置内容：**

```yaml
webhook_config:
  endpoint: "/webhook/starbrain"
  events:
    - task_complete
    - alert
    - schedule
  
  verification:
    type: "hmac"
    secret: "${WEBHOOK_SECRET}"
  
  response:
    success_code: 200
    retry_on_failure: true
```

---

### 3. 意图映射配置

**目标：** 配置意图到任务的映射

**配置内容：**

```yaml
intent_mapping:
  douyin_select_product:
    keywords:
      - "找爆款"
      - "选品"
      - "推荐商品"
    params:
      platform: "douyin"
      action: "select"
    priority: 2
  
  toutiao_write:
    keywords:
      - "写文章"
      - "生成内容"
      - "创作"
    params:
      platform: "toutiao"
      action: "create"
    priority: 2
  
  data_analysis:
    keywords:
      - "分析数据"
      - "数据报告"
      - "统计"
    params:
      action: "analyze"
    priority: 3
```

---

### 4. 业务配置

**目标：** 配置业务参数

**配置内容：**

```yaml
business_config:
  douyin:
    product_analysis:
      batch_size: 50
      timeout: 120
      cache_ttl: 3600
  
  kuaishou:
    talent_match:
      max_results: 20
      min_match_score: 0.7
  
  toutiao:
    content_generation:
      daily_target: 8
      time_window: "6:00-22:00"
      avg_length: 1200
```

---

## 三、操作步骤

### Step 1: 下载配置模板（5分钟）

```bash
# 配置文件模板
wget https://example.com/starbrain-config.tar.gz
tar -xzf starbrain-config.tar.gz
```

### Step 2: 填写配置（10分钟）

```bash
# 编辑配置文件
vim config/api_config.yaml
vim config/webhook_config.yaml
vim config/intent_mapping.yaml
vim config/business_config.yaml
```

### Step 3: 上传配置（5分钟）

```bash
# 通过API上传配置
curl -X POST https://api.example.com/config/upload \
  -H "Authorization: Bearer ${TOKEN}" \
  -F "config=@config.tar.gz"
```

### Step 4: 验证配置（5分钟）

```bash
# 测试API连接
curl -X GET https://api.example.com/health \
  -H "Authorization: Bearer ${TOKEN}"

# 测试Webhook
curl -X POST https://api.example.com/webhook/test \
  -H "Authorization: Bearer ${TOKEN}" \
  -d '{"event": "test"}'
```

---

## 四、配置文件模板

### 完整配置包

```
starbrain-config/
├── config.yaml              # 主配置
├── api_config.yaml          # API配置
├── webhook_config.yaml      # Webhook配置
├── intent_mapping.yaml      # 意图映射
├── business_config.yaml     # 业务配置
└── README.md                # 配置说明
```

---

## 五、预期效果

### 升级后能力

| 能力 | 升级前 | 升级后 |
|------|--------|--------|
| API对接 | 无 | ✅ 配置完成 |
| Webhook接收 | 无 | ✅ 配置完成 |
| 意图识别 | 简单 | ✅ 多意图支持 |
| 业务参数 | 无 | ✅ 完整配置 |

---

## 六、注意事项

### 约束条件

- ❌ 无法部署服务
- ❌ 无法修改服务器代码
- ✅ 可以配置API
- ✅ 可以上传配置文件
- ✅ 可以配置Webhook

### 替代方案

| 原方案 | 替代方案 |
|--------|----------|
| 服务部署 | API配置 |
| 代码修改 | 配置文件 |
| 数据库部署 | 使用现有数据库 |

---

## 七、验收标准

- [ ] 配置文件填写完成
- [ ] API配置上传成功
- [ ] Webhook配置成功
- [ ] 测试API连接正常
- [ ] 测试Webhook接收正常

---

_创建时间: 2026-05-09_
