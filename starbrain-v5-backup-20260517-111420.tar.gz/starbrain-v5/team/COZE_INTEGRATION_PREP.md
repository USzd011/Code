# 星辰大脑 v5.0 - 扣子对接准备

> **目标：** 完成升级后，与杨欢对接扣子Agent

---

## 一、对接准备

### 我需要完成的工作

| 任务 | 状态 | 说明 |
|------|------|------|
| 方案理解 | ✅ 完成 | 9份文档理解 |
| 技能分类 | ✅ 完成 | 431个技能分类 |
| MCTS原型 | ✅ 完成 | 决策引擎 |
| 技能评估原型 | ✅ 完成 | 进化系统 |
| 语义检索原型 | ✅ 完成 | 向量检索 |
| API接口设计 | ⏳ 待完成 | 对接扣子需要 |
| Webhook配置 | ⏳ 待完成 | 双向通信需要 |

---

## 二、扣子对接接口设计

### 2.1 触发接口

**POST /coze/trigger**

```yaml
请求:
  intent: string         # 意图类型
  params: object         # 业务参数
  priority: int          # 优先级 1-3
  session_id: string     # 扣子会话ID
  callback_url: string   # 回调URL（可选）

响应:
  success: boolean
  task_id: string        # 任务ID
  status: string         # queued/processing
  estimated_time: int    # 预估耗时（秒）
```

### 2.2 状态查询接口

**GET /coze/task/{task_id}**

```yaml
响应:
  task_id: string
  status: string         # queued/running/completed/failed
  progress: float        # 进度 0-1
  result: object         # 任务结果
  error: string          # 错误信息
```

### 2.3 Webhook回调接口

**POST /webhook/starbrain**

```yaml
请求头:
  X-StarBrain-Signature: string  # 签名验证
  X-StarBrain-Timestamp: int     # 时间戳

请求体:
  event_type: string     # task_complete/alert/schedule
  task_id: string
  timestamp: int
  data: object           # 结果数据
```

---

## 三、意图映射表

| 用户说 | 星辰大脑意图 | 处理流程 |
|--------|--------------|----------|
| "找爆款" | douyin_select_product | L3宿1感知→L4推理→L5推演→TOP10 |
| "写文章" | toutiao_write | L3宿3感知→L4推理→L5生成→文章 |
| "分析数据" | data_analysis | L3数据采集→L4分析→报告 |
| "匹配达人" | talent_match | L3宿4感知→L4匹配→达人列表 |
| "写小说" | novel_create | L4创意→L5规划→章节生成 |

---

## 四、对接流程

### 4.1 杨欢操作扣子

```
1. 在扣子平台配置API调用
2. 配置Webhook接收地址
3. 配置意图识别规则
4. 测试触发接口
5. 测试回调接收
```

### 4.2 我提供的内容

```
1. API接口文档
2. 意图映射表
3. 测试用例
4. 错误处理指南
```

---

## 五、下一步

1. **我继续完成API接口设计**
2. **完成后杨欢来对接扣子**
3. **测试完整流程**
4. **优化迭代**

---

_创建时间: 2026-05-09_