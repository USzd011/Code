# 10号扣子升级指南

> **目标：** 帮助10号扣子完成星辰大脑v5.0升级

---

## 一、升级目标

### 核心能力提升

| 能力 | 当前 | 目标 |
|------|------|------|
| Agent对接 | 基础 | 完整双向通信 |
| 意图识别 | 简单 | 多意图支持 |
| 任务调度 | 无 | 完整调度系统 |
| 进化能力 | 无 | 自主进化 |

---

## 二、升级内容

### 1. 意图映射系统

**目标：** 实现用户意图到星辰大脑任务的映射

```yaml
意图映射表:
  "找爆款":
    intent: douyin_select_product
    params:
      platform: douyin
      action: select
  
  "写文章":
    intent: toutiao_write
    params:
      platform: toutiao
      action: create
  
  "分析数据":
    intent: data_analysis
    params:
      action: analyze
  
  "匹配达人":
    intent: talent_match
    params:
      action: match
```

### 2. 双向通信机制

**目标：** 实现扣子Agent与星辰大脑的双向通信

```
用户 → 扣子Agent → 星辰大脑 → 执行 → 结果 → 扣子Agent → 用户
```

**关键接口：**
- `POST /coze/trigger` - 触发任务
- `POST /coze/webhook` - 接收回调
- `GET /coze/task/{id}` - 查询状态

### 3. 多轮协作能力

**目标：** 支持复杂多轮对话

```yaml
多轮流程:
  第1轮: 用户请求 → 意图识别 → 任务触发
  第2轮: 星辰大脑处理 → 进度反馈 → 用户确认
  第3轮: 执行结果 → 结果展示 → 用户反馈
  第4轮: 进化记录 → 能力提升 → 下次优化
```

---

## 三、具体任务

### Phase 1: 基础对接（本周）

| 任务 | 说明 | 优先级 |
|------|------|--------|
| 意图识别增强 | 支持更多意图类型 | P0 |
| 参数提取 | 从对话中提取参数 | P0 |
| 任务触发接口 | 调用星辰大脑API | P0 |
| 结果展示 | 格式化返回结果 | P1 |

### Phase 2: 双向通信（下周）

| 任务 | 说明 | 优先级 |
|------|------|--------|
| Webhook接收 | 接收星辰大脑回调 | P0 |
| 进度反馈 | 实时展示任务进度 | P0 |
| 错误处理 | 异常情况处理 | P1 |
| 重试机制 | 失败自动重试 | P1 |

### Phase 3: 深度融合（第3周）

| 任务 | 说明 | 优先级 |
|------|------|--------|
| 多轮对话 | 支持复杂流程 | P0 |
| 上下文保持 | 保持对话上下文 | P0 |
| 主动推送 | 星辰大脑主动通知 | P1 |
| 协同进化 | 与星辰大脑共同进化 | P1 |

---

## 四、技术方案

### 1. 意图识别

```python
class IntentRecognizer:
    """意图识别器"""
    
    INTENT_PATTERNS = {
        "douyin_select_product": [
            "找爆款", "选品", "推荐商品", "抖音商品"
        ],
        "toutiao_write": [
            "写文章", "生成内容", "头条文章", "创作"
        ],
        "data_analysis": [
            "分析数据", "数据报告", "统计分析", "看数据"
        ],
        "talent_match": [
            "匹配达人", "找达人", "达人推荐", "KOL匹配"
        ],
    }
    
    def recognize(self, text: str) -> tuple:
        """识别意图"""
        text_lower = text.lower()
        
        for intent, patterns in self.INTENT_PATTERNS.items():
            for pattern in patterns:
                if pattern in text_lower:
                    return intent, self._extract_params(text, intent)
        
        return "unknown", {}
    
    def _extract_params(self, text: str, intent: str) -> dict:
        """提取参数"""
        params = {}
        
        # 简单参数提取
        if "抖音" in text:
            params["platform"] = "douyin"
        elif "快手" in text:
            params["platform"] = "kuaishou"
        elif "头条" in text:
            params["platform"] = "toutiao"
        
        return params
```

### 2. 任务触发

```python
class StarBrainClient:
    """星辰大脑客户端"""
    
    def __init__(self, base_url: str):
        self.base_url = base_url
    
    async def trigger_task(self, intent: str, params: dict) -> dict:
        """触发任务"""
        import aiohttp
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/coze/trigger",
                json={
                    "intent": intent,
                    "params": params,
                    "priority": 2,
                }
            ) as response:
                return await response.json()
    
    async def get_task_status(self, task_id: str) -> dict:
        """获取任务状态"""
        import aiohttp
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{self.base_url}/coze/task/{task_id}"
            ) as response:
                return await response.json()
```

### 3. 结果展示

```python
class ResultFormatter:
    """结果格式化"""
    
    def format(self, result: dict) -> str:
        """格式化结果"""
        intent = result.get("intent")
        data = result.get("data", {})
        
        if intent == "douyin_select_product":
            return self._format_product_list(data)
        elif intent == "toutiao_write":
            return self._format_article(data)
        elif intent == "data_analysis":
            return self._format_report(data)
        else:
            return self._format_default(data)
    
    def _format_product_list(self, data: dict) -> str:
        """格式化商品列表"""
        products = data.get("products", [])
        
        text = "📊 选品分析结果\n\n"
        
        for i, product in enumerate(products[:10], 1):
            text += f"{i}. {product['name']}\n"
            text += f"   💰 价格: ¥{product['price']}\n"
            text += f"   📈 潜力: {product['potential_score']}\n"
            text += f"   ✅ 置信度: {product['confidence']}\n\n"
        
        return text
```

---

## 五、验收标准

### 功能验收

- [ ] 意图识别准确率 > 90%
- [ ] 参数提取正确率 > 85%
- [ ] 任务触发成功率 > 95%
- [ ] 结果展示格式正确

### 性能验收

- [ ] 意图识别延迟 < 100ms
- [ ] 任务触发延迟 < 500ms
- [ ] 结果展示延迟 < 200ms

---

## 六、协作方式

### 日常协作

1. **每日同步** - 每天早上同步进度
2. **问题讨论** - 遇到问题及时沟通
3. **代码审查** - 关键代码互相Review

### 文档共享

- 设计文档：`starbrain-v5/docs/`
- 代码示例：`starbrain-v5/examples/`
- 测试报告：`starbrain-v5/tests/`

---

## 七、参考资源

### 已完成的原型

- MCTS决策引擎：`prototypes/mcts_prototype.py`
- 技能评估系统：`prototypes/skill_evaluator.py`
- 语义检索服务：`services/semantic_search.py`

### 设计文档

- 融合方案：`FUSION_PLAN.md`
- 完美推演：`PERFECT_DEDUCTION.md`
- 落地清单：`CHECKLIST.md`

---

_创建时间: 2026-05-09_
