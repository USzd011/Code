# 4号完整升级方案

> **状态：** 杨欢可操作，支持完整部署

---

## 一、升级目标

### 核心能力

| 能力 | 目标 |
|------|------|
| 向量检索 | Milvus部署 + 语义检索 |
| 决策引擎 | MCTS集成 |
| 技能评估 | 进化系统部署 |
| API服务 | 完整API接口 |

---

## 二、部署步骤

### Phase 1: 环境准备（Day 1）

#### 1.1 Docker环境

```bash
# 检查Docker
docker --version
docker-compose --version

# 如未安装，安装Docker
curl -fsSL https://get.docker.com | bash
pip install docker-compose
```

#### 1.2 Python环境

```bash
# 检查Python
python3 --version  # 需要 3.11+

# 安装依赖
pip install pymilvus openai fastapi uvicorn celery redis
```

---

### Phase 2: Milvus部署（Day 1-2）

#### 2.1 部署Milvus

```bash
# 创建目录
mkdir -p /root/milvus/volumes/{etcd,minio,milvus}
cd /root/milvus

# 下载docker-compose配置
wget https://github.com/milvus-io/milvus/releases/download/v2.3.3/milvus-standalone-docker-compose.yml -O docker-compose.yml

# 启动服务
docker-compose up -d

# 检查状态
docker-compose ps
```

#### 2.2 验证部署

```bash
# 测试连接
python3 -c "
from pymilvus import connections
connections.connect(host='localhost', port='19530')
print('Milvus连接成功')
connections.disconnect('default')
"
```

---

### Phase 3: 服务部署（Day 2-3）

#### 3.1 部署MCTS服务

```bash
# 创建服务目录
mkdir -p /root/starbrain/services

# 复制原型代码
cp /root/.openclaw/workspace/starbrain-v5/prototypes/mcts_prototype.py /root/starbrain/services/

# 创建API服务
cat > /root/starbrain/services/mcts_api.py << 'EOF'
from fastapi import FastAPI
from pydantic import BaseModel
from mcts_prototype import MCTSEngine, GameState, ActionType

app = FastAPI()

class DecisionRequest(BaseModel):
    scenario: str
    context: dict
    iterations: int = 3000

@app.post("/decide")
async def decide(request: DecisionRequest):
    engine = MCTSEngine(max_iterations=request.iterations)
    initial_state = GameState()
    result = engine.search(initial_state)
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
EOF

# 启动服务
cd /root/starbrain/services
nohup python3 mcts_api.py > mcts.log 2>&1 &
```

#### 3.2 部署技能评估服务

```bash
# 复制原型代码
cp /root/.openclaw/workspace/starbrain-v5/prototypes/skill_evaluator.py /root/starbrain/services/

# 创建API服务
cat > /root/starbrain/services/evaluator_api.py << 'EOF'
from fastapi import FastAPI
from skill_evaluator import SkillEvaluator, SkillMetrics, SkillLevel, SkillStatus
from pydantic import BaseModel

app = FastAPI()
evaluator = SkillEvaluator()

class EvaluateRequest(BaseModel):
    skill_id: str
    name: str
    level: int
    use_count: int
    success_count: int
    fail_count: int
    p99_latency_ms: float

@app.post("/evaluate")
async def evaluate(request: EvaluateRequest):
    metrics = SkillMetrics(
        skill_id=request.skill_id,
        name=request.name,
        level=SkillLevel(request.level),
        status=SkillStatus.ACTIVE,
        use_count=request.use_count,
        success_count=request.success_count,
        fail_count=request.fail_count,
        p99_latency_ms=request.p99_latency_ms,
    )
    result = evaluator.evaluate(metrics)
    return {
        "skill_id": result.skill_id,
        "can_upgrade": result.can_upgrade,
        "can_downgrade": result.can_downgrade,
        "should_retire": result.should_retire,
        "total_score": result.total_score,
        "recommendations": result.recommendations,
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
EOF

# 启动服务
nohup python3 evaluator_api.py > evaluator.log 2>&1 &
```

---

### Phase 4: API网关（Day 3）

#### 4.1 部署Kong

```bash
# 创建Kong网络
docker network create kong-net

# 启动Kong数据库
docker run -d --name kong-database \
  --network=kong-net \
  -p 5432:5432 \
  -e "POSTGRES_USER=kong" \
  -e "POSTGRES_DB=kong" \
  postgres:9.6

# 启动Kong
docker run -d --name kong \
  --network=kong-net \
  -p 8000:8000 \
  -p 8443:8443 \
  -e "KONG_DATABASE=postgres" \
  -e "KONG_PG_HOST=kong-database" \
  -e "KONG_PROXY_listen=0.0.0.0:8000" \
  kong:latest

# 配置路由
curl -X POST http://localhost:8001/services \
  --data "name=mcts-service" \
  --data "url=http://host.docker.internal:8001"

curl -X POST http://localhost:8001/services/mcts-service/routes \
  --data "paths[]=/api/mcts"
```

---

## 三、验收测试

### 3.1 Milvus测试

```bash
curl -X POST http://localhost:8001/api/milvus/test
```

### 3.2 MCTS测试

```bash
curl -X POST http://localhost:8000/api/mcts/decide \
  -H "Content-Type: application/json" \
  -d '{"scenario": "test", "context": {}, "iterations": 1000}'
```

### 3.3 技能评估测试

```bash
curl -X POST http://localhost:8000/api/evaluator/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "skill_id": "test_001",
    "name": "测试技能",
    "level": 2,
    "use_count": 100,
    "success_count": 80,
    "fail_count": 20,
    "p99_latency_ms": 500
  }'
```

---

## 四、监控配置

### 4.1 Prometheus

```bash
# 启动Prometheus
docker run -d --name prometheus \
  -p 9090:9090 \
  prom/prometheus

# 配置监控目标
cat > /root/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'starbrain'
    static_configs:
      - targets: ['localhost:8001', 'localhost:8002']
EOF
```

### 4.2 Grafana

```bash
# 启动Grafana
docker run -d --name grafana \
  -p 3000:3000 \
  grafana/grafana

# 访问 http://localhost:3000
# 默认账号: admin/admin
```

---

## 五、预期效果

### 部署后能力

| 服务 | 端口 | 状态 |
|------|------|------|
| Milvus | 19530 | ✅ 运行中 |
| MCTS API | 8001 | ✅ 运行中 |
| Evaluator API | 8002 | ✅ 运行中 |
| Kong Gateway | 8000 | ✅ 运行中 |
| Prometheus | 9090 | ✅ 运行中 |
| Grafana | 3000 | ✅ 运行中 |

---

## 六、下一步

1. 杨欢登录4号服务器
2. 执行部署脚本
3. 验证服务状态
4. 配置API路由
5. 测试完整流程

---

_创建时间: 2026-05-09_
