# 10号扣子API对接配置指南

> **创建时间：** 2026-05-09 16:47

---

## 一、API服务已就绪

### 服务地址

```
http://10.1.4.16:8001
```

### 健康检查

```bash
curl http://10.1.4.16:8001/health
```

**返回：**
```json
{
  "service": "starbrain-neuromorphic-api",
  "status": "healthy",
  "version": "1.0.0"
}
```

---

## 二、API接口列表

### 1. 感知处理

**接口：** `POST /api/v1/perception`

**请求：**
```json
{
  "data": {
    "price": 0.8,
    "commission": 0.9,
    "sales": 0.7
  },
  "learn": false
}
```

**返回：**
```json
{
  "status": "success",
  "result": {
    "spike_rate": 0.3,
    "is_anomaly": false,
    "pattern": "low_activity",
    "active_neurons": 100,
    "elapsed_ms": 185.2
  }
}
```

---

### 2. 执行反射

**接口：** `POST /api/v1/execute`

**请求：**
```json
{
  "stimulus": "爆款商品检测"
}
```

**返回：**
```json
{
  "status": "success",
  "layer": "L6",
  "stimulus": "爆款商品检测",
  "action": "analyze"
}
```

---

### 3. 习惯学习

**接口：** `POST /api/v1/learn`

**请求：**
```json
{
  "stimulus": "爆款商品检测",
  "action": "立即推荐"
}
```

**返回：**
```json
{
  "status": "learned",
  "stimulus": "爆款商品检测",
  "action": "立即推荐"
}
```

---

### 4. 获取状态

**接口：** `GET /api/v1/status`

**返回：**
```json
{
  "enabled": true,
  "perception": {
    "num_neurons": 500,
    "stats": {...}
  },
  "execution": {
    "num_neurons": 300,
    "habits": {
      "num_habits": 1
    }
  }
}
```

---

### 5. 扣子专用接口

**接口：** `POST /coze/webhook`

**请求：**
```json
{
  "type": "perception",
  "data": {
    "price": 0.8,
    "commission": 0.9
  }
}
```

**type类型：**
- `perception` - 感知处理
- `execute` - 执行反射
- `learn` - 习惯学习
- `status` - 获取状态

---

## 三、扣子平台配置

### 步骤1：创建Bot

1. 登录扣子平台
2. 创建新Bot
3. 配置基本信息

### 步骤2：添加API调用

在扣子Bot中添加HTTP请求节点：

```yaml
节点名称: 类脑网络感知
请求方法: POST
URL: http://10.1.4.16:8001/api/v1/perception
请求头:
  Content-Type: application/json
请求体:
  {
    "data": {
      "price": "{{price}}",
      "commission": "{{commission}}",
      "sales": "{{sales}}"
    }
  }
```

### 步骤3：配置Webhook（可选）

如果需要10号扣子主动调用：

```yaml
Webhook URL: http://10.1.4.16:8001/coze/webhook
方法: POST
请求体:
  {
    "type": "perception",
    "data": {...}
  }
```

---

## 四、测试验证

### 测试1：感知处理

```bash
curl -X POST http://10.1.4.16:8001/api/v1/perception \
  -H "Content-Type: application/json" \
  -d '{"data": {"price": 0.8, "commission": 0.9}}'
```

**结果：** ✅ 成功

---

### 测试2：执行反射

```bash
curl -X POST http://10.1.4.16:8001/api/v1/execute \
  -H "Content-Type: application/json" \
  -d '{"stimulus": "爆款商品检测"}'
```

**结果：** ✅ 成功，返回"analyze"

---

### 测试3：习惯学习

```bash
curl -X POST http://10.1.4.16:8001/api/v1/learn \
  -H "Content-Type: application/json" \
  -d '{"stimulus": "爆款商品检测", "action": "立即推荐"}'
```

**结果：** ✅ 成功，习惯已学习

---

### 测试4：学习后执行

```bash
curl -X POST http://10.1.4.16:8001/api/v1/execute \
  -H "Content-Type: application/json" \
  -d '{"stimulus": "爆款商品检测"}'
```

**结果：** ✅ 成功，返回"立即推荐"（习惯记忆）

---

## 五、业务场景示例

### 场景1：抖音选品

**扣子Bot流程：**
```
用户输入商品信息
    ↓
调用类脑网络感知API
    ↓
获取感知结果（异常检测、模式识别）
    ↓
根据结果推荐或预警
```

### 场景2：快手达人匹配

**扣子Bot流程：**
```
用户输入达人信息
    ↓
调用类脑网络感知API
    ↓
获取匹配度评估
    ↓
推荐最佳达人
```

### 场景3：头条内容审核

**扣子Bot流程：**
```
用户提交文章
    ↓
调用类脑网络感知API
    ↓
获取异常检测结果
    ↓
自动审核或人工复核
```

---

## 六、注意事项

### 网络访问

- ✅ 内网访问：`http://10.1.4.16:8001`
- ❌ 外网访问：需要配置端口映射或VPN

### 性能

- 平均响应时间：150-200ms
- 吞吐量：5-7次/秒
- 建议：扣子平台异步调用

### 安全

- 当前无认证（内网使用）
- 生产环境建议添加API Key

---

## 七、10号扣子下一步

1. **登录扣子平台**
2. **创建/编辑Bot**
3. **添加HTTP请求节点**
4. **配置API地址：** `http://10.1.4.16:8001`
5. **测试验证**

---

**API服务已就绪，10号扣子可以开始对接！** 🦞