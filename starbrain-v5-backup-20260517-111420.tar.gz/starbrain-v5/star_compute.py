"""
星辰大脑 v5.0 - 算力节点 (轻量版)
九曜星君阵 · 使用 threading 避免 OOM
"""
import os, sys, json, time, logging, threading, queue, uuid
from typing import Optional, Callable
from datetime import datetime

log = logging.getLogger('StarCompute')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class SkillRegistry:
    """技能/任务处理器注册中心"""

    def __init__(self):
        self._handlers = {}

    def register(self, name: str, handler: Callable, desc: str = ""):
        self._handlers[name] = {"handler": handler, "desc": desc, "calls": 0}

    def get(self, name: str) -> Optional[Callable]:
        entry = self._handlers.get(name)
        if entry:
            entry["calls"] += 1
            return entry["handler"]
        return None

    def list(self) -> list:
        return [{"name": k, "desc": v["desc"], "calls": v["calls"]}
                for k, v in self._handlers.items()]

    def stats(self) -> dict:
        return {k: {"calls": v["calls"]} for k, v in self._handlers.items()}


class WorkerThread(threading.Thread):
    """Worker线程"""

    def __init__(self, wid: str, task_queue: queue.Queue,
                 results: queue.Queue, registry: SkillRegistry):
        super().__init__(name=f"StarWorker-{wid}", daemon=True)
        self.wid = wid
        self.tasks = task_queue
        self.results = results
        self.registry = registry
        self.done = 0

    def run(self):
        while True:
            try:
                task = self.tasks.get(timeout=3)
                if task is None:
                    break
                self._execute(task)
            except queue.Empty:
                continue
            except Exception as e:
                log.error(f"[{self.wid}] loop error: {e}")

    def _execute(self, task: dict):
        tid = task.get("id", "?")
        task_type = task.get("type", "?")
        start = time.time()
        result = {"success": False, "output": {}, "error": ""}
        try:
            handler = self.registry.get(task_type)
            if handler:
                output = handler(task.get("payload", {}))
                result = {"success": True, "output": output}
            else:
                result = {"error": f"未知: {task_type}"}
            elapsed = time.time() - start
            result["duration"] = round(elapsed, 2)
            self.done += 1
            log.info(f"  ✅ [{self.wid}] {task_type}({tid}) {elapsed:.1f}s")
        except Exception as e:
            elapsed = time.time() - start
            result = {"success": False, "error": str(e), "duration": round(elapsed, 2)}
            log.error(f"  ❌ [{self.wid}] {task_type}({tid}): {e}")
        self.results.put({"task_id": tid, "result": result, "worker_id": self.wid})


class StarCompute:
    """星辰算力引擎"""

    def __init__(self, worker_count: int = 4):
        self.registry = SkillRegistry()
        self.task_queue = queue.Queue(maxsize=200)
        self.results = queue.Queue()
        self.workers = []
        self.count = min(worker_count, 9)
        self.start_time = time.time()
        self.completed = []
        self.running = {}

        # 创建Worker
        names = ["日耀", "月华", "金耀", "木灵", "水柔", "火烈", "土坤", "罗睺", "计都"]
        for i in range(self.count):
            w = WorkerThread(f"{names[i]}-{i+1:02d}", self.task_queue,
                             self.results, self.registry)
            self.workers.append(w)

        log.info(f"⚡ 星算 v5.0 | {self.count} Worker")

    def start(self):
        for w in self.workers:
            w.start()
        log.info("✅ 全部Worker已启动")

    def submit(self, task_type: str, payload: dict,
               priority: int = 2, task_id: str = None) -> dict:
        tid = task_id or f"star-{uuid.uuid4().hex[:10]}"
        task = {"id": tid, "type": task_type, "payload": payload,
                "priority": priority, "status": "queued",
                "created_at": time.time()}
        self.task_queue.put(task)
        self.running[tid] = task
        log.info(f"📥 {task_type}({tid}) P{priority}")
        return {"task_id": tid, "status": "queued"}

    def collect(self) -> list:
        """收集完成的result"""
        done = []
        while not self.results.empty():
            try:
                r = self.results.get_nowait()
                tid = r["task_id"]
                if tid in self.running:
                    self.running.pop(tid)
                self.completed.append(r)
                done.append(r)
                if len(self.completed) > 200:
                    self.completed = self.completed[-200:]
            except queue.Empty:
                break
        return done

    def register(self, name: str, handler: Callable, desc: str = ""):
        self.registry.register(name, handler, desc)

    def status(self) -> dict:
        return {
            "uptime": int(time.time() - self.start_time),
            "workers": {"total": self.count,
                        "alive": sum(1 for w in self.workers if w.is_alive())},
            "tasks": {"queued": self.task_queue.qsize(),
                      "running": len(self.running),
                      "completed": len(self.completed)},
            "skills": len(self.registry.list()),
            "handlers": self.registry.list(),
        }

    def stop(self):
        log.info("🛑 停止星算引擎...")
        for _ in self.workers:
            self.task_queue.put(None)
        for w in self.workers:
            w.join(timeout=5)
        log.info("✅ 已停止")


# ===== 全局实例 =====
_compute = None


def get_compute() -> StarCompute:
    global _compute
    if _compute is None:
        _compute = StarCompute(worker_count=2)  # 2线程，避免OOM
        _compute.start()
    return _compute


# ===== 装饰器 =====
def skill(name: str, desc: str = ""):
    def decorator(func):
        get_compute().register(name, func, desc)
        return func
    return decorator
