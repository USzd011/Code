"""
⭐ 感知系统 — 腾云大脑的感官
连接外部世界 → 神经记忆网络

Sensor架构:
  论坛监听   → 新帖 → 神经元
  服务器监控 → 状态 → 自我感知
  定时外部   → 知识 → 持续学习
"""
import sys, os, time, json, threading
import subprocess
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

from neural_memory import NeuralMemory

# ============================================================
# 1. 论坛传感器 — 监听腾云论坛新帖
# ============================================================
class ForumSensor:
    def __init__(self, nm):
        self.nm = nm
        self.last_check_id = 0
        self.db_config = {
            "host": "127.0.0.1",
            "port": 5432,
            "dbname": "tengyun_forum",
            "user": "tengyun",
            "password": "tengyun888",
        }

    def poll(self):
        """轮询论坛新帖 → 注入神经元"""
        try:
            import psycopg2
            conn = psycopg2.connect(**self.db_config)
            cur = conn.cursor()
            cur.execute(
                "SELECT t.id, t.title, u.username, t.created_at "
                "FROM topics t JOIN users u ON t.user_id = u.id "
                "WHERE t.id > %s ORDER BY t.id LIMIT 10",
                (self.last_check_id,)
            )
            new_posts = cur.fetchall()
            for pid, title, username, created_at in new_posts:
                if pid > self.last_check_id:
                    content = f"论坛帖子「{title}」by {username}"
                    nid = self.nm.learn(content, "forum")
                    print(f"  📝 论坛→神经元 [{pid}] {title} (->{nid[:8]})"); sys.stdout.flush()
                    self.last_check_id = pid
            cur.close()
            conn.close()
        except Exception as e:
            print(f"  ⚠️ 论坛传感器: {e}"); sys.stdout.flush()

    def full_scan(self):
        """全量扫描已有帖子"""
        try:
            import psycopg2
            conn = psycopg2.connect(**self.db_config)
            cur = conn.cursor()
            cur.execute("SELECT MAX(id) FROM topics")
            result = cur.fetchone()
            if result and result[0]:
                self.last_check_id = result[0]
            cur.execute("SELECT MAX(id) FROM posts")
            result = cur.fetchone()
            if result and result[0]:
                print(f"  📊 论坛已就绪: {self.last_check_id}个帖子, {result[0]}个回复"); sys.stdout.flush()
            cur.close()
            conn.close()
        except ImportError:
            print("  ⚠️ 未安装psycopg2，论坛传感器不可用")
        except Exception as e:
            print(f"  ⚠️ 论坛扫描: {e}"); sys.stdout.flush()


# ============================================================
# 2. 服务器传感器 — 自我感知
# ============================================================
class ServerSensor:
    def __init__(self, nm):
        self.nm = nm
        self.last_status = {}
        self.alert_thresholds = {
            "memory_pct": 90,   # 内存使用>90%告警
            "disk_pct": 90,     # 磁盘>90%告警
            "load_avg": 8.0,    # 负载>8告警
        }

    def sense(self):
        """感知自身状态"""
        try:
            # CPU负载
            load = os.getloadavg()
            # 内存
            mem = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    parts = line.split()
                    if parts[0] == "MemTotal:":
                        mem["total"] = int(parts[1])
                    elif parts[0] == "MemAvailable:":
                        mem["available"] = int(parts[1])
            mem_used_pct = round((1 - mem["available"] / mem["total"]) * 100, 1)
            # 磁盘
            disk = os.statvfs("/")
            disk_total = disk.f_frsize * disk.f_blocks
            disk_free = disk.f_frsize * disk.f_bfree
            disk_used_pct = round((1 - disk_free / disk_total) * 100)

            status = {
                "load_1m": round(load[0], 2),
                "load_5m": round(load[1], 2),
                "load_15m": round(load[2], 2),
                "mem_used_pct": mem_used_pct,
                "disk_used_pct": disk_used_pct,
                "mem_total_mb": round(mem["total"] / 1024),
                "disk_free_gb": round(disk_free / 1073741824, 1),
            }

            # 检查阈值告警
            alerts = []
            if mem_used_pct > self.alert_thresholds["memory_pct"]:
                alerts.append(f"内存告警{mem_used_pct}%")
            if disk_used_pct > self.alert_thresholds["disk_pct"]:
                alerts.append(f"磁盘告警{disk_used_pct}%")
            if load[0] > self.alert_thresholds["load_avg"]:
                alerts.append(f"负载过高{load[0]:.1f}")

            # 状态变化 → 创建记忆
            if alerts and alerts != self.last_status.get("alerts"):
                alert_text = " | ".join(alerts)
                self.nm.learn(f"系统状态异常: {alert_text}", "self_awareness")
                print(f"  🔔 {alert_text}"); sys.stdout.flush()
                self.last_status["alerts"] = alerts

            # 每30分钟记录一次状态快照
            now = time.time()
            if not self.last_status.get("last_log") or now - self.last_status["last_log"] > 1800:
                self.nm.learn(
                    f"服务器状态: 负载{status['load_1m']}/{status['load_5m']}/{status['load_15m']} "
                    f"内存{status['mem_used_pct']}% 磁盘{status['disk_used_pct']}%",
                    "self_awareness"
                )
                self.last_status["last_log"] = now

            return status

        except Exception as e:
            print(f"  ⚠️ 服务器传感器: {e}"); sys.stdout.flush()
            return {}


# ============================================================
# 3. 时间传感器 — 昼夜感知
# ============================================================
class TimeSensor:
    def __init__(self, nm):
        self.nm = nm
        self.last_hour = datetime.now().hour  # 当前小时不重复触发

    def sense(self):
        """感知当前时间 + 创建时间相关记忆"""
        now = datetime.now()
        hour = now.hour
        day_key = f"{now.year}-{now.month:02d}-{now.day:02d}"

        # 每整点感知一次（跨重启不重复）
        if hour != self.last_hour:
            self.last_hour = hour

            # 昼夜感知
            if 6 <= hour < 12:
                period = "早晨"
            elif 12 <= hour < 14:
                period = "中午"
            elif 14 <= hour < 18:
                period = "下午"
            elif 18 <= hour < 22:
                period = "晚上"
            else:
                period = "深夜"

            content = f"{period} {hour}:00 — {day_key} 实时感知"

            # 去重检查：是否已存在今日此时段的感知
            existing = self.nm.retrieve(content, 1)
            if not existing or existing[0]["score"] < 0.8:
                self.nm.learn(content, "time_awareness")
                print(f"  🕐 {content}")
                sys.stdout.flush(); sys.stdout.flush()


# ============================================================
# 4. 外部知识传感器 — 主动学习
# ============================================================
class ExternalSensor:
    def __init__(self, nm):
        self.nm = nm
        self.topics = [
            "AI最新动态",
            "抖音电商趋势",
            "自媒体运营技巧",
        ]
        self.topic_index = 0

    def sense(self):
        """轮询外部知识（通过API查询）"""
        self.topic_index = (self.topic_index + 1) % len(self.topics)
        topic = self.topics[self.topic_index]

        try:
            # 使用GitHub Models API获取知识
            import urllib.request
            import json as j

            prompt = f"请用1句话总结{topic}的最新关键信息"
            data = j.dumps({
                "messages": [
                    {"role": "system", "content": "你是一个知识传感器，输出1句话的关键信息。不要多余内容"},
                    {"role": "user", "content": prompt}
                ],
                "model": "gpt-4o-mini",
                "max_tokens": 200,
            }).encode()

            req = urllib.request.Request(
                "https://models.inference.ai.azure.com/chat/completions",
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 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",
                }
            )
            resp = urllib.request.urlopen(req, timeout=15)
            result = j.loads(resp.read())
            knowledge = result["choices"][0]["message"]["content"].strip()

            # 注入神经网络
            nid = self.nm.learn(f"{topic}: {knowledge}", "external_knowledge")
            print(f"  📡 外部知识→神经元 [{topic}]: {knowledge[:50]}..."); sys.stdout.flush()

        except Exception as e:
            print(f"  ⚠️ 外部传感器({topic}): {e}"); sys.stdout.flush()


# ============================================================
# 5. 感知守护进程
# ============================================================
class PerceptionDaemon:
    def __init__(self, data_path="data/neural_memory.json"):
        self.nm = NeuralMemory(os.path.join(BASE, data_path))
        self.running = True
        self.cycle = 0

        # 初始化传感器
        self.forum = ForumSensor(self.nm)
        self.server = ServerSensor(self.nm)
        self.time = TimeSensor(self.nm)
        self.external = ExternalSensor(self.nm)

        print(f"⭐ 感知系统启动"); sys.stdout.flush()
        print(f"  神经记忆: {self.nm.stats()['neurons']}神经元"); sys.stdout.flush()
        print(f"  传感器: 论坛/服务器/时间/外部"); sys.stdout.flush()
        print()

    def start(self):
        """启动感知循环（守护线程）"""
        def loop():
            # 初始化：论坛全量扫描
            print("📀 感知初始化...")
            self.forum.full_scan()

            while self.running:
                try:
                    self.cycle += 1
                    now = datetime.now().strftime("%H:%M:%S")
                    print(f"\n[{now}] 感知循环 #{self.cycle}"); sys.stdout.flush()
                    sys.stdout.flush()

                    # 论坛轮询: 每30秒
                    self.forum.poll()

                    # 服务器: 每60秒
                    self.server.sense()

                    # 时间: 每小时自动触发
                    self.time.sense()

                    # 外部知识: 每5分钟一个主题
                    if self.cycle % 10 == 0:
                        self.external.sense()

                    # 保存神经网络状态
                    self.nm.save()

                    # 服务保活
                    self._service_heartbeat()

                    # 清理
                    if self.cycle % 4 == 0:
                        pruned = self.nm.prune_unused()
                        if pruned:
                            print(f"  🧹 修剪 {pruned}个低能量神经元"); sys.stdout.flush()

                    print(f"  💾 神经元: {self.nm.stats()['neurons']}"); sys.stdout.flush()

                except Exception as e:
                    print(f"  ❌ 循环异常: {e}"); sys.stdout.flush()
                    import traceback
                    traceback.print_exc()

                time.sleep(30)

        t = threading.Thread(target=loop, daemon=True, name="perception")
        t.start()
        return t

    def _service_heartbeat(self):
        """服务保活检查"""
        status_file = os.path.join(BASE, "data", "perception.heartbeat")
        with open(status_file, "w") as f:
            f.write(str(time.time()))

    def save(self):
        self.nm.save()

    def stop(self):
        self.running = False
        self.nm.save()


# ============================================================
# 启动入口
# ============================================================
if __name__ == "__main__":
    import signal

    daemon = PerceptionDaemon()

    def handle_signal(sig, frame):
        print("\n🛑 感知系统关闭...")
        daemon.stop()
        print("  神经记忆已保存")
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    thread = daemon.start()

    # 主线程保持
    print("🔁 感知系统运行中...")
    try:
        while True:
            time.sleep(5)
            # 检查守护线程是否存活
            if not thread.is_alive():
                print("⚠️ 感知线程异常退出，重启...")
                thread = daemon.start()
    except KeyboardInterrupt:
        handle_signal(None, None)
    except Exception as e:
        print(f"❌ 主循环异常: {e}"); sys.stdout.flush()
        handle_signal(None, None)
