"""
星辰大脑 v5.0 - 类脑皮层 (完整整合)
向量记忆 + API推理 + 主动学习回路
"""
import sys, os, json, time, threading, logging, random

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

log = logging.getLogger('BrainCortex')

from light_cortex import LightVectorStore, APICortex


class CortexEngine:
    """类脑神经网络引擎"""

    def __init__(self):
        self.vector = LightVectorStore()
        self.api = APICortex()
        self.learned_topics = set()
        self.cycle = 0
        self.running = True

        # 启动异步学习
        t = threading.Thread(target=self._auto_learn_loop, daemon=True)
        t.start()
        log.info("🧠 类脑皮层初始化  |  向量+API+主动学习")

    def think(self, query: str, context: str = "") -> dict:
        """完整思考链路: 检索记忆 → API推理 → 存储"""
        # 1. 检索相关记忆
        relevant = self.vector.search(query, limit=3)

        # 2. 用推理皮层做分析
        ctx_parts = [r["content"] for r in relevant]
        ctx_text = "\n".join(ctx_parts) if ctx_parts else "无相关记忆"
        full_prompt = (
            f"已知信息:\n{ctx_text}\n\n"
            f"问题: {query}\n"
            f"{context}\n\n"
            "请基于已知信息回答问题，如果信息不足则诚实说明。"
        )
        answer = self.api.reason(full_prompt, temperature=0.3)

        # 3. 存储新知识
        self.vector.store(
            content=f"[思考] Q:{query} A:{answer[:200]}",
            metadata={"query": query},
            domain="思考日志"
        )

        return {
            "query": query,
            "answer": answer,
            "retrieved": len(relevant),
            "sources": [r["domain"] for r in relevant],
        }

    def learn(self, topic: str) -> dict:
        """主动学习一个主题"""
        if topic in self.learned_topics:
            return {"topic": topic, "status": "already_learned"}

        self.cycle += 1
        knowledge = self.api.reason(
            f"请简要总结关于「{topic}」的核心知识要点，适合AI智能体学习和使用。控制在200字内。",
            temperature=0.3
        )

        self.vector.store(
            content=f"[主动学习] {topic}: {knowledge}",
            metadata={"topic": topic, "cycle": self.cycle},
            domain="知识"
        )

        # 发现子主题
        subtopics_text = self.api.reason(
            f"基于「{topic}」，列出2个相关的子主题，每行一个。"
        )
        subtopics = [s.strip("•-* 0123456789. ") 
                     for s in subtopics_text.strip().split("\n") if s.strip()]

        self.learned_topics.add(topic)
        log.info(f"  [{self.cycle}] 学会: {topic} → 子主题: {subtopics}")
        return {"topic": topic, "subtopics": subtopics}

    def _auto_learn_loop(self):
        """后台自动学习"""
        seed_pool = [
            "抖音爆款选品策略", "快手小店运营技巧", "头条热点文章写作",
            "短视频带货脚本结构", "达人对接洽谈话术", "MCN机构管理",
            "AI视频生成工具", "电商数据分析方法", "短视频平台算法",
        ]
        while self.running:
            time.sleep(random.randint(30, 90))
            if len(self.learned_topics) >= 15:
                break
            topic = random.choice([t for t in seed_pool if t not in self.learned_topics] or seed_pool)
            self.learn(topic)

    def enrich_task(self, task_type: str, payload: dict) -> dict:
        """增强任务：自动加入相关记忆和推理"""
        # 查相关记忆
        relevant = self.vector.search(f"{task_type} {payload.get('goal', '')}", limit=3)
        context = "\n".join(r["content"][:100] for r in relevant)

        # 推理增强
        if context:
            enhancement = self.api.reason(
                f"任务: {task_type}\n数据: {json.dumps(payload, ensure_ascii=False)}\n"
                f"相关经验:\n{context}\n\n"
                f"基于以上经验，是否有什么要提醒的？简短回答。"
            )
            payload["_cortex_advice"] = enhancement

        payload["_context_memories"] = len(relevant)
        return payload

    def stats(self) -> dict:
        return {
            "vector_memory": self.vector.stats(),
            "api_calls": self.api.calls,
            "learned_topics": len(self.learned_topics),
            "topics": list(self.learned_topics),
        }


# 全局
_cortex = None


def get_cortex_engine() -> CortexEngine:
    global _cortex
    if _cortex is None:
        _cortex = CortexEngine()
    return _cortex
