"""
技能评估系统
用于L7进化层的南斗培育和北斗淘汰
"""

import time
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class SkillLevel(Enum):
    """技能等级"""
    LV1 = 1  # 新手
    LV2 = 2  # 入门
    LV3 = 3  # 熟练
    LV4 = 4  # 专家
    LV5 = 5  # 大师


class SkillStatus(Enum):
    """技能状态"""
    ACTIVE = "活跃"
    EVOLVING = "进化中"
    DEPRECATED = "已废弃"
    PROTECTED = "保护期"


class SideEffectType(Enum):
    """副作用类型"""
    PERFORMANCE_DROP = "性能下降"
    MISJUDGE = "误判"
    EXCEPTION = "异常"
    DATA_ERROR = "数据错误"


@dataclass
class SideEffect:
    """副作用记录"""
    type: SideEffectType
    severity: float  # 0-1
    timestamp: float
    details: str = ""


@dataclass
class SkillMetrics:
    """技能指标"""
    skill_id: str
    name: str
    level: SkillLevel
    status: SkillStatus
    
    # 使用统计
    use_count: int = 0
    success_count: int = 0
    fail_count: int = 0
    
    # 性能指标
    avg_latency_ms: float = 0.0
    p99_latency_ms: float = 0.0
    
    # 副作用
    side_effects: List[SideEffect] = field(default_factory=list)
    
    # 时间
    created_at: float = 0.0
    last_used_at: float = 0.0
    
    # 计算属性
    @property
    def success_rate(self) -> float:
        """成功率"""
        if self.use_count == 0:
            return 0.0
        return self.success_count / self.use_count
    
    @property
    def days_since_last_use(self) -> int:
        """距上次使用天数"""
        if self.last_used_at == 0:
            return 999
        return int((time.time() - self.last_used_at) / 86400)
    
    @property
    def days_since_created(self) -> int:
        """距创建天数"""
        if self.created_at == 0:
            return 0
        return int((time.time() - self.created_at) / 86400)


@dataclass
class EvaluationResult:
    """评估结果"""
    skill_id: str
    can_upgrade: bool
    can_downgrade: bool
    should_retire: bool
    
    # 评分
    total_score: float
    dimension_scores: Dict[str, float]
    
    # 建议
    recommendations: List[str]
    
    # 原因
    upgrade_reason: str = ""
    downgrade_reason: str = ""
    retire_reason: str = ""


class SkillEvaluator:
    """技能评估器"""
    
    # 各维度权重
    WEIGHTS = {
        'usage_count': 0.2,
        'success_rate': 0.4,
        'side_effect': 0.3,
        'latency': 0.1,
    }
    
    # 各等级阈值
    LEVEL_THRESHOLDS = {
        2: {'min_score': 0.5, 'min_usage': 50, 'min_success': 0.6},
        3: {'min_score': 0.6, 'min_usage': 100, 'min_success': 0.7},
        4: {'min_score': 0.7, 'min_usage': 200, 'min_success': 0.75},
        5: {'min_score': 0.8, 'min_usage': 500, 'min_success': 0.8},
    }
    
    # 淘汰阈值
    RETIRE_THRESHOLDS = {
        'min_success_rate': 0.2,
        'max_p99_latency': 10000,
        'max_days_unused': 90,
        'max_side_effect_severity': 0.8,
    }
    
    def evaluate(self, metrics: SkillMetrics) -> EvaluationResult:
        """评估技能"""
        # 计算各维度得分
        usage_score = self._calc_usage_score(metrics)
        success_score = self._calc_success_score(metrics)
        side_effect_score = self._calc_side_effect_score(metrics)
        latency_score = self._calc_latency_score(metrics)
        
        # 综合得分
        total_score = (
            usage_score * self.WEIGHTS['usage_count'] +
            success_score * self.WEIGHTS['success_rate'] +
            side_effect_score * self.WEIGHTS['side_effect'] +
            latency_score * self.WEIGHTS['latency']
        )
        
        dimension_scores = {
            'usage': usage_score,
            'success': success_score,
            'side_effect': side_effect_score,
            'latency': latency_score,
        }
        
        # 判断升级/降级/淘汰
        can_upgrade, upgrade_reason = self._check_upgrade(metrics, total_score)
        can_downgrade, downgrade_reason = self._check_downgrade(metrics, total_score)
        should_retire, retire_reason = self._check_retire(metrics)
        
        # 生成建议
        recommendations = self._generate_recommendations(
            metrics, dimension_scores, can_upgrade, can_downgrade, should_retire
        )
        
        return EvaluationResult(
            skill_id=metrics.skill_id,
            can_upgrade=can_upgrade,
            can_downgrade=can_downgrade,
            should_retire=should_retire,
            total_score=round(total_score, 3),
            dimension_scores={k: round(v, 3) for k, v in dimension_scores.items()},
            recommendations=recommendations,
            upgrade_reason=upgrade_reason,
            downgrade_reason=downgrade_reason,
            retire_reason=retire_reason,
        )
    
    def _calc_usage_score(self, metrics: SkillMetrics) -> float:
        """计算使用次数得分"""
        # 新技能保护期30天
        if metrics.days_since_created < 30:
            return 0.5
        
        # 使用次数映射到得分
        if metrics.use_count >= 500:
            return 1.0
        elif metrics.use_count >= 200:
            return 0.8
        elif metrics.use_count >= 100:
            return 0.6
        elif metrics.use_count >= 50:
            return 0.5
        else:
            return metrics.use_count / 50 * 0.5
    
    def _calc_success_score(self, metrics: SkillMetrics) -> float:
        """计算成功率得分"""
        return metrics.success_rate
    
    def _calc_side_effect_score(self, metrics: SkillMetrics) -> float:
        """计算副作用得分"""
        if not metrics.side_effects:
            return 1.0
        
        # 副作用权重映射
        weight_map = {
            SideEffectType.PERFORMANCE_DROP: 0.2,
            SideEffectType.MISJUDGE: 0.4,
            SideEffectType.EXCEPTION: 0.6,
            SideEffectType.DATA_ERROR: 0.8,
        }
        
        total_penalty = 0.0
        for effect in metrics.side_effects:
            weight = weight_map.get(effect.type, 0.3)
            # 时间衰减
            age_days = (time.time() - effect.timestamp) / 86400
            decay = math.exp(-age_days / 30)  # 30天半衰期
            total_penalty += weight * effect.severity * decay
        
        return max(0, 1.0 - total_penalty / 10)
    
    def _calc_latency_score(self, metrics: SkillMetrics) -> float:
        """计算延迟得分"""
        if metrics.p99_latency_ms == 0:
            return 0.8
        
        # P99延迟映射到得分
        if metrics.p99_latency_ms < 100:
            return 1.0
        elif metrics.p99_latency_ms < 500:
            return 0.8
        elif metrics.p99_latency_ms < 1000:
            return 0.6
        elif metrics.p99_latency_ms < 5000:
            return 0.4
        else:
            return 0.2
    
    def _check_upgrade(self, metrics: SkillMetrics, total_score: float) -> tuple:
        """检查是否可以升级"""
        # 新技能保护期不升级
        if metrics.days_since_created < 30:
            return False, "保护期内"
        
        # 已是最高级
        if metrics.level == SkillLevel.LV5:
            return False, "已达最高级"
        
        # 检查阈值
        target_level = metrics.level.value + 1
        thresholds = self.LEVEL_THRESHOLDS.get(target_level)
        
        if not thresholds:
            return False, "无升级阈值"
        
        checks = {
            'score': total_score >= thresholds['min_score'],
            'usage': metrics.use_count >= thresholds['min_usage'],
            'success': metrics.success_rate >= thresholds['min_success'],
        }
        
        if all(checks.values()):
            return True, f"满足Lv.{target_level}升级条件"
        
        failed = [k for k, v in checks.items() if not v]
        return False, f"未满足: {', '.join(failed)}"
    
    def _check_downgrade(self, metrics: SkillMetrics, total_score: float) -> tuple:
        """检查是否需要降级"""
        # 已是最低级
        if metrics.level == SkillLevel.LV1:
            return False, "已是最低级"
        
        # 降级条件
        if metrics.success_rate < 0.5:
            return True, "成功率过低"
        
        if total_score < 0.4:
            return True, "综合得分过低"
        
        return False, "无需降级"
    
    def _check_retire(self, metrics: SkillMetrics) -> tuple:
        """检查是否需要淘汰"""
        # 连续失败
        if metrics.fail_count >= 5 and metrics.success_rate < self.RETIRE_THRESHOLDS['min_success_rate']:
            return True, "连续失败且成功率过低"
        
        # 性能问题
        if metrics.p99_latency_ms > self.RETIRE_THRESHOLDS['max_p99_latency']:
            return True, "P99延迟过高"
        
        # 长期未使用
        if metrics.days_since_last_use > self.RETIRE_THRESHOLDS['max_days_unused']:
            return True, "长期未使用"
        
        # 严重副作用
        for effect in metrics.side_effects:
            if effect.severity > self.RETIRE_THRESHOLDS['max_side_effect_severity']:
                if effect.type == SideEffectType.DATA_ERROR:
                    return True, "存在严重数据错误"
        
        return False, "无需淘汰"
    
    def _generate_recommendations(self, metrics: SkillMetrics, 
                                   scores: Dict[str, float],
                                   can_upgrade: bool, 
                                   can_downgrade: bool,
                                   should_retire: bool) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if should_retire:
            recommendations.append("建议淘汰此技能")
        elif can_downgrade:
            recommendations.append("建议降级此技能")
        elif can_upgrade:
            recommendations.append("建议升级此技能")
        
        # 各维度建议
        if scores['usage'] < 0.5:
            recommendations.append("增加使用频率")
        
        if scores['success'] < 0.7:
            recommendations.append("优化成功率")
        
        if scores['side_effect'] < 0.8:
            recommendations.append("减少副作用")
        
        if scores['latency'] < 0.6:
            recommendations.append("优化性能")
        
        return recommendations


def main():
    """测试技能评估系统"""
    print("=== 技能评估系统测试 ===\n")
    
    evaluator = SkillEvaluator()
    
    # 测试案例
    test_skills = [
        SkillMetrics(
            skill_id="skill_001",
            name="抖音选品分析",
            level=SkillLevel.LV2,
            status=SkillStatus.ACTIVE,
            use_count=150,
            success_count=120,
            fail_count=30,
            avg_latency_ms=200,
            p99_latency_ms=500,
            created_at=time.time() - 60 * 86400,  # 60天前
            last_used_at=time.time() - 1 * 86400,  # 1天前
        ),
        SkillMetrics(
            skill_id="skill_002",
            name="快手达人匹配",
            level=SkillLevel.LV3,
            status=SkillStatus.ACTIVE,
            use_count=50,
            success_count=10,
            fail_count=40,
            avg_latency_ms=5000,
            p99_latency_ms=15000,
            created_at=time.time() - 90 * 86400,
            last_used_at=time.time() - 100 * 86400,  # 100天前
        ),
        SkillMetrics(
            skill_id="skill_003",
            name="头条内容生成",
            level=SkillLevel.LV4,
            status=SkillStatus.ACTIVE,
            use_count=600,
            success_count=550,
            fail_count=50,
            avg_latency_ms=100,
            p99_latency_ms=300,
            created_at=time.time() - 180 * 86400,
            last_used_at=time.time() - 0.5 * 86400,
        ),
    ]
    
    for skill in test_skills:
        print(f"\n--- {skill.name} (Lv.{skill.level.value}) ---")
        print(f"使用次数: {skill.use_count}")
        print(f"成功率: {skill.success_rate:.1%}")
        print(f"P99延迟: {skill.p99_latency_ms}ms")
        print(f"距上次使用: {skill.days_since_last_use}天")
        
        result = evaluator.evaluate(skill)
        
        print(f"\n评估结果:")
        print(f"综合得分: {result.total_score}")
        print(f"维度得分: {result.dimension_scores}")
        print(f"可升级: {result.can_upgrade} ({result.upgrade_reason})")
        print(f"需降级: {result.can_downgrade} ({result.downgrade_reason})")
        print(f"应淘汰: {result.should_retire} ({result.retire_reason})")
        print(f"建议: {result.recommendations}")


if __name__ == "__main__":
    import math
    main()