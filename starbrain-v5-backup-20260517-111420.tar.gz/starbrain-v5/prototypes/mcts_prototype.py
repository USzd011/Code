"""
MCTS决策引擎原型
用于L5决策层的多方案推演
"""

import math
import random
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum


class ActionType(Enum):
    """动作类型"""
    SELECT_PRODUCT = "选品"
    MATCH_TALENT = "匹配达人"
    CREATE_CONTENT = "生成内容"
    ANALYZE_DATA = "分析数据"
    EXECUTE_TASK = "执行任务"


@dataclass
class GameState:
    """游戏状态"""
    # 当前状态
    step: int = 0
    max_steps: int = 10
    
    # 业务指标
    revenue: float = 0.0
    conversion: float = 0.0
    cost: float = 0.0
    risk: float = 0.0
    
    # 已执行动作
    actions: List[ActionType] = field(default_factory=list)
    
    def copy(self) -> 'GameState':
        """复制状态"""
        return GameState(
            step=self.step,
            max_steps=self.max_steps,
            revenue=self.revenue,
            conversion=self.conversion,
            cost=self.cost,
            risk=self.risk,
            actions=self.actions.copy()
        )
    
    def is_terminal(self) -> bool:
        """是否终止状态"""
        return self.step >= self.max_steps
    
    def get_valid_actions(self) -> List[ActionType]:
        """获取有效动作"""
        if self.is_terminal():
            return []
        return list(ActionType)
    
    def take_action(self, action: ActionType) -> 'GameState':
        """执行动作"""
        new_state = self.copy()
        new_state.step += 1
        new_state.actions.append(action)
        
        # 模拟动作效果
        if action == ActionType.SELECT_PRODUCT:
            new_state.revenue += random.uniform(100, 500)
            new_state.conversion += random.uniform(0.01, 0.05)
            new_state.cost += random.uniform(10, 50)
        elif action == ActionType.MATCH_TALENT:
            new_state.revenue += random.uniform(200, 800)
            new_state.conversion += random.uniform(0.02, 0.08)
            new_state.cost += random.uniform(50, 200)
        elif action == ActionType.CREATE_CONTENT:
            new_state.revenue += random.uniform(50, 300)
            new_state.conversion += random.uniform(0.005, 0.03)
            new_state.cost += random.uniform(5, 30)
        elif action == ActionType.ANALYZE_DATA:
            new_state.risk -= random.uniform(0.01, 0.05)
            new_state.cost += random.uniform(5, 20)
        elif action == ActionType.EXECUTE_TASK:
            new_state.revenue += random.uniform(100, 400)
            new_state.cost += random.uniform(20, 100)
        
        # 风险累积
        new_state.risk = max(0, new_state.risk + random.uniform(-0.02, 0.03))
        
        return new_state


@dataclass
class Node:
    """MCTS节点"""
    state: GameState
    parent: Optional['Node'] = None
    action: Optional[ActionType] = None
    children: List['Node'] = field(default_factory=list)
    visit_count: int = 0
    value: float = 0.0
    untried_actions: List[ActionType] = field(default_factory=list)
    
    def __post_init__(self):
        if not self.untried_actions:
            self.untried_actions = self.state.get_valid_actions()
    
    def is_fully_expanded(self) -> bool:
        """是否完全扩展"""
        return len(self.untried_actions) == 0
    
    def has_untried_actions(self) -> bool:
        """是否有未尝试动作"""
        return len(self.untried_actions) > 0
    
    def get_untried_action(self) -> Optional[ActionType]:
        """获取未尝试动作"""
        if self.untried_actions:
            return self.untried_actions.pop(random.randint(0, len(self.untried_actions) - 1))
        return None
    
    def is_terminal(self) -> bool:
        """是否终止"""
        return self.state.is_terminal()


class MCTSEngine:
    """MCTS决策引擎"""
    
    def __init__(self, 
                 exploration_constant: float = 1.414,
                 max_iterations: int = 3000,
                 simulation_depth: int = 10,
                 max_time: float = 5.0):
        self.exploration_constant = exploration_constant
        self.max_iterations = max_iterations
        self.simulation_depth = simulation_depth
        self.max_time = max_time
        self.root: Optional[Node] = None
    
    def search(self, initial_state: GameState) -> Dict[str, Any]:
        """主搜索流程"""
        self.root = Node(state=initial_state)
        
        start_time = time.time()
        iterations = 0
        
        while iterations < self.max_iterations and (time.time() - start_time) < self.max_time:
            # 1. 选择
            node = self._select(self.root)
            
            # 2. 扩展
            if not node.is_terminal() and node.has_untried_actions():
                node = self._expand(node)
            
            # 3. 模拟
            reward = self._simulate(node)
            
            # 4. 回溯
            self._backpropagate(node, reward)
            
            iterations += 1
        
        # 返回结果
        return self._get_best_result(iterations, time.time() - start_time)
    
    def _select(self, node: Node) -> Node:
        """选择节点"""
        while not node.is_terminal():
            if node.has_untried_actions():
                return node
            if node.children:
                node = self._best_child(node)
            else:
                break
        return node
    
    def _best_child(self, node: Node) -> Node:
        """UCB1选择最优子节点"""
        def ucb1(child: Node) -> float:
            if child.visit_count == 0:
                return float('inf')
            
            exploitation = child.value / child.visit_count
            exploration = self.exploration_constant * math.sqrt(
                math.log(node.visit_count) / child.visit_count
            )
            return exploitation + exploration
        
        return max(node.children, key=ucb1)
    
    def _expand(self, node: Node) -> Node:
        """扩展节点"""
        action = node.get_untried_action()
        if action is None:
            return node
        
        new_state = node.state.take_action(action)
        new_node = Node(state=new_state, parent=node, action=action)
        node.children.append(new_node)
        return new_node
    
    def _simulate(self, node: Node) -> float:
        """模拟推演"""
        state = node.state.copy()
        
        for _ in range(self.simulation_depth):
            if state.is_terminal():
                break
            
            actions = state.get_valid_actions()
            if not actions:
                break
            
            action = random.choice(actions)
            state = state.take_action(action)
        
        return self._evaluate(state)
    
    def _evaluate(self, state: GameState) -> float:
        """评估局面分数"""
        # 业务指标加权
        score = 0.0
        score += state.revenue * 0.4  # 收益权重40%
        score += state.conversion * 100 * 0.3  # 转化率权重30%
        score -= state.cost * 0.1  # 成本权重-10%
        score -= state.risk * 100 * 0.2  # 风险权重-20%
        
        return max(0, score)
    
    def _backpropagate(self, node: Node, reward: float):
        """回溯更新"""
        while node is not None:
            node.visit_count += 1
            node.value += reward
            node = node.parent
    
    def _get_best_result(self, iterations: int, elapsed_time: float) -> Dict[str, Any]:
        """获取最佳结果"""
        if not self.root.children:
            return {
                "success": False,
                "message": "无法生成方案",
                "iterations": iterations,
                "time": elapsed_time
            }
        
        # 按访问次数排序
        sorted_children = sorted(
            self.root.children,
            key=lambda c: c.visit_count,
            reverse=True
        )
        
        # TOP3方案
        top3 = []
        for i, child in enumerate(sorted_children[:3]):
            avg_value = child.value / child.visit_count if child.visit_count > 0 else 0
            top3.append({
                "rank": i + 1,
                "action": child.action.value if child.action else "未知",
                "visits": child.visit_count,
                "avg_value": round(avg_value, 2),
                "confidence": round(child.visit_count / iterations * 100, 1)
            })
        
        return {
            "success": True,
            "iterations": iterations,
            "time": round(elapsed_time, 3),
            "best_action": sorted_children[0].action.value if sorted_children[0].action else None,
            "top3_plans": top3,
            "total_nodes": self._count_nodes(self.root)
        }
    
    def _count_nodes(self, node: Node) -> int:
        """统计节点数"""
        count = 1
        for child in node.children:
            count += self._count_nodes(child)
        return count


def main():
    """测试MCTS引擎"""
    print("=== MCTS决策引擎测试 ===\n")
    
    # 初始状态
    initial_state = GameState(
        step=0,
        max_steps=10,
        revenue=0.0,
        conversion=0.0,
        cost=0.0,
        risk=0.0
    )
    
    # 创建引擎
    engine = MCTSEngine(
        exploration_constant=1.414,
        max_iterations=3000,
        simulation_depth=10,
        max_time=5.0
    )
    
    # 执行搜索
    print("开始推演...")
    result = engine.search(initial_state)
    
    # 输出结果
    print(f"\n推演完成!")
    print(f"迭代次数: {result['iterations']}")
    print(f"耗时: {result['time']}秒")
    print(f"节点数: {result['total_nodes']}")
    print(f"\n最佳动作: {result['best_action']}")
    print(f"\nTOP3方案:")
    for plan in result['top3_plans']:
        print(f"  {plan['rank']}. {plan['action']} - 访问{plan['visits']}次, 置信度{plan['confidence']}%")


if __name__ == "__main__":
    main()
