#!/usr/bin/env python3
"""GitMCP - 读取任意GitHub仓库文档工具"""
import urllib.request, json, sys, re

def read_repo(repo, path=""):
    url = f"https://gitmcp.io/{repo}"
    if path:
        url += f"/{path}"
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            html = resp.read().decode()
            # 提取可读文本
            texts = re.findall(r'>([^<]{3,})<', html)
            return "\n".join(t for t in texts if not t.startswith(("/", "http")))
    except Exception as e:
        return f"错误: {e}"

if __name__ == "__main__":
    repo = sys.argv[1] if len(sys.argv) > 1 else "microsoft/playwright-mcp"
    print(f"📚 GitMCP: {repo}")
    print("=" * 50)
    print(read_repo(repo)[:2000])
