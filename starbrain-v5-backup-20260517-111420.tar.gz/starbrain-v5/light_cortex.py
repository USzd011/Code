"""
星辰大脑 - 轻量向量记忆 (无模型下载)
使用 MinHash + 滚动哈希做近似语义搜索
零依赖，零下载，零额外存储
"""
import os, json, time, hashlib, re, math, struct
from typing import Optional, List
from collections import defaultdict


class LightVectorStore:
    """轻量向量存储 — 无模型版本"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), "data", "vector_store.json")
        self.db_path = db_path
        self.data = []
        self._load()

    def _load(self):
        if os.path.exists(self.db_path):
            with open(self.db_path) as f:
                self.data = json.load(f)

    def _save(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with open(self.db_path, "w") as f:
            json.dump(self.data, f, ensure_ascii=False, default=str)

    def _tokenize(self, text: str) -> set:
        """分词：中文词+英文词+字符级shingle混合"""
        tokens = set()
        # 中文双字词
        chinese = re.findall(r'[\u4e00-\u9fff]+', text)
        for c in chinese:
            for i in range(len(c) - 1):
                tokens.add('c:' + c[i:i+2])
            tokens.add('w:' + c)
        # 英文词
        words = re.findall(r'[a-zA-Z]+', text.lower())
        for w in words:
            tokens.add('e:' + w)
        # 数字
        nums = re.findall(r'\d+', text)
        for n in nums:
            tokens.add('n:' + n)
        return tokens

    def _similarity(self, a: set, b: set) -> float:
        """混合相似度：Jaccard + 关键词覆盖"""
        if not a or not b:
            return 0.0
        intersection = a & b
        if not intersection:
            return 0.0
        # Jaccard
        jaccard = len(intersection) / len(a | b)
        # 关键词覆盖（query覆盖doc的比例）
        coverage = len(intersection) / len(a) if a else 0
        # 混合得分
        return jaccard * 0.4 + coverage * 0.6

    def store(self, content: str, metadata: dict = None, domain: str = "通用"):
        """存储并更新索引"""
        doc_id = hashlib.md5(content.encode()).hexdigest()[:12]
        # 去重
        for d in self.data:
            if d["id"] == doc_id:
                d["accessed_at"] = time.time()
                d["access_count"] = d.get("access_count", 0) + 1
                self._save()
                return doc_id

        tokens = self._tokenize(content)
        doc = {
            "id": doc_id,
            "content": content,
            "shingles": list(tokens),
            "domain": domain,
            "metadata": metadata or {},
            "created_at": time.time(),
            "accessed_at": time.time(),
            "access_count": 1,
            "length": len(content),
        }
        self.data.append(doc)
        self._save()
        return doc_id

    def search(self, query: str, domain: str = None, limit: int = 5) -> List[dict]:
        """语义搜索"""
        query_tokens = self._tokenize(query)
        scored = []

        for doc in self.data:
            if domain and doc["domain"] != domain:
                continue
            doc_tokens = set(doc.get("shingles", []))
            sim = self._similarity(query_tokens, doc_tokens)
            if sim > 0.01:
                scored.append((sim, doc))

        scored.sort(key=lambda x: -x[0])

        results = []
        for sim, doc in scored[:limit]:
            doc["accessed_at"] = time.time()
            results.append({
                "id": doc["id"],
                "content": doc["content"][:200],
                "domain": doc["domain"],
                "score": round(sim, 3),
                "length": doc["length"],
            })
        self._save()
        return results

    def search_by_domain(self, domain: str, limit: int = 20) -> List[dict]:
        """按域搜索"""
        results = [d for d in self.data if d["domain"] == domain]
        results.sort(key=lambda x: -x["created_at"])
        return [{"id": r["id"], "content": r["content"][:200],
                 "domain": r["domain"]} for r in results[:limit]]

    def stats(self) -> dict:
        domains = defaultdict(int)
        for d in self.data:
            domains[d["domain"]] += 1
        return {
            "total": len(self.data),
            "domains": dict(domains),
            "db_size_kb": round(os.path.getsize(self.db_path) / 1024, 1) if os.path.exists(self.db_path) else 0,
        }

    def delete_old(self, max_age_hours: int = 168):
        """删除旧数据"""
        cutoff = time.time() - max_age_hours * 3600
        before = len(self.data)
        self.data = [d for d in self.data if d["created_at"] > cutoff]
        self._save()
        return before - len(self.data)


# 轻量推理皮层
class APICortex:
    """API推理皮层 — 调用免费API做实时推理"""

    def __init__(self):
        self.gh_token = "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"
        self.gemini_key = "AIzaSyDiu56VV24fj-QwxBthiSXpIGZ33EK9Lbk"
        self.cache = {}
        self.calls = 0

    def reason(self, prompt: str, temperature: float = 0.3) -> str:
        self.calls += 1
        cache_key = hashlib.md5(prompt.encode()).hexdigest()
        if cache_key in self.cache:
            return self.cache[cache_key]

        import urllib.request
        data = json.dumps({
            "messages": [{"role": "user", "content": prompt}],
            "model": "gpt-4o-mini",
            "temperature": temperature,
            "max_tokens": 600,
        }).encode()
        req = urllib.request.Request(
            "https://models.inference.ai.azure.com/chat/completions",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.gh_token}",
            },
        )
        try:
            resp = urllib.request.urlopen(req, timeout=20)
            result = json.loads(resp.read())
            text = result["choices"][0]["message"]["content"]
            self.cache[cache_key] = text
            if len(self.cache) > 200:
                self.cache.clear()
            return text
        except Exception as e:
            return self._fallback(prompt, temperature)

    def _fallback(self, prompt: str, temperature: float) -> str:
        """备用 Gemini"""
        import urllib.request
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={self.gemini_key}"
        data = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": temperature, "maxOutputTokens": 600},
        }).encode()
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(req, timeout=20)
            result = json.loads(resp.read())
            return result["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e:
            return f"[推理暂不可用: {e}]"


# 全局
vector_store = None
cortex = None


def get_vector_store() -> LightVectorStore:
    global vector_store
    if vector_store is None:
        vector_store = LightVectorStore()
    return vector_store


def get_cortex() -> APICortex:
    global cortex
    if cortex is None:
        cortex = APICortex()
    return cortex
