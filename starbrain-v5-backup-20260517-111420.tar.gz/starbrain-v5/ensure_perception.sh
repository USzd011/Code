#!/bin/bash
# 感知系统保活检查 - 每1分钟由cron调用
PID_FILE="/tmp/perception.pid"
LOG="/tmp/perception.log"
SCRIPT_DIR="/root/.openclaw/workspace/starbrain-v5"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        exit 0
    fi
fi

# 感知进程挂了，重启
echo "[$(date)] 感知进程重启" >> "$LOG"
cd "$SCRIPT_DIR" && nohup python3 -u perception.py >> "$LOG" 2>&1 &
echo $! > "$PID_FILE"
