"""
星辰大脑 v5.0 - 核心大脑
集成：轻量算力 + FTS5记忆 + MCTS决策 + 技能评估 + 自进化
"""
import os, sys, json, time, logging, threading

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [StarBrain] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('StarBrain')

from star_compute import get_compute, skill
from star_memory import get_memory


# ============================================================
# 二十八宿域定义
# ============================================================
DOMAINS = {
    "宿1-抖音商品": ["抖音", "选品", "爆款", "带货", "douyin"],
    "宿2-快手商品": ["快手", "小店", "kuaishou"],
    "宿3-头条内容": ["头条", "文章", "写作", "toutiao"],
    "宿4-达人资源": ["达人", "匹配", "合作", "KOL"],
    "宿5-用户画像": ["用户", "画像", "粉丝", "受众"],
    "宿6-竞品分析": ["竞品", "竞争", "对比", "市场"],
    "宿7-趋势预测": ["趋势", "预测", "热点", "风向"],
    "宿8-风险控制": ["风险", "合规", "安全", "风控"],
}


def route_domain(task: str) -> str:
    """路由到宿域"""
    for domain, keywords in DOMAINS.items():
        for kw in keywords:
            if kw in task:
                return domain
    return "通用"


# ============================================================
# 业务处理器注册
# ============================================================

@skill("ping", "心跳检测")
def _ping(payload):
    return {"pong": True, "time": time.time()}


@skill("echo", "回显测试")
def _echo(payload):
    return payload


@skill("domain_route", "二十八宿路由")
def _route(payload):
    task = payload.get("task", "")
    return {"domain": route_domain(task), "task": task}


@skill("mcts_decision", "MCTS推演决策")
def _mcts(payload):
    """MCTS决策"""
    sys.path.insert(0, os.path.join(BASE, "prototypes"))
    from mcts_prototype import MCTSEngine, GameState

    engine = MCTSEngine(max_iterations=payload.get("iterations", 1000))
    state = GameState(
        revenue=payload.get("revenue", 100),
        conversion=payload.get("conversion", 0.05),
        cost=payload.get("cost", 50),
        risk=payload.get("risk", 0.1),
    )
    result = engine.search(state)
    return {
        "best_action": result.get("best_action", "?"),
        "iterations": result.get("iterations", 0),
        "time_s": round(result.get("time", 0), 3),
        "top3": [
            {"rank": p["rank"], "action": p["action"], "confidence": p["confidence"]}
            for p in result.get("top3_plans", [])
        ],
    }


@skill("skill_evaluate", "技能评估")
def _evaluate(payload):
    """技能评估"""
    sys.path.insert(0, os.path.join(BASE, "prototypes"))
    from skill_evaluator import SkillEvaluator, SkillMetrics, SkillLevel, SkillStatus

    evaluator = SkillEvaluator()
    metrics = SkillMetrics(
        skill_id=payload.get("skill_id", "unknown"),
        name=payload.get("name", "?"),
        level=SkillLevel.LV3,
        status=SkillStatus.ACTIVE,
        use_count=payload.get("use_count", 1),
        success_count=payload.get("success_count", 1),
        fail_count=payload.get("fail_count", 0),
        avg_latency_ms=payload.get("avg_latency", 100),
        p99_latency_ms=payload.get("p99_latency", 500),
    )
    result = evaluator.evaluate(metrics)
    return {
        "score": round(result.total_score, 2),
        "can_upgrade": result.can_upgrade,
        "should_retire": result.should_retire,
        "recommendations": result.recommendations[:3],
    }


@skill("memory_store", "记忆存储")
def _mem_store(payload):
    mem = get_memory()
    mem.store(
        content=payload.get("content", ""),
        source=payload.get("source", "agent"),
        domain=payload.get("domain", "通用"),
        tags=payload.get("tags", ""),
    )
    return {"stored": True}


@skill("memory_search", "记忆搜索")
def _mem_search(payload):
    mem = get_memory()
    query = payload.get("query", "")
    domain = payload.get("domain", "")
    if domain and not query:
        results = mem.search_by_domain(domain)
    else:
        results = mem.search(query)
    return {"results": results, "count": len(results)}


@skill("plan", "生成行动计划/方案")
def _plan(payload):
    """根据目标生成行动计划"""
    goal = payload.get("goal", "通用任务")
    domain = route_domain(goal)
    return {
        "goal": goal,
        "domain": domain,
        "steps": [
            {"step": 1, "action": f"分析情况: {goal}"},
            {"step": 2, "action": "收集相关数据"},
            {"step": 3, "action": "执行并反馈"},
        ],
        "estimated_time": "5-15分钟",
    }


@skill("self_evolve", "自我评估进化")
def _self_evolve(payload):
    """自进化：检查所有技能的使用情况，给出升级建议"""
    compute = get_compute()
    handlers = compute.registry.stats()
    # 过滤出使用次数>0的
    active = {k: v for k, v in handlers.items() if v["calls"] > 0}
    suggestions = []
    for name, stats in sorted(active.items(), key=lambda x: -x[1]["calls"]):
        if stats["calls"] >= 5:
            suggestions.append(f"{name}: 使用{stats['calls']}次，建议升为常驻技能")
        elif stats["calls"] >= 2:
            suggestions.append(f"{name}: 使用{stats['calls']}次，继续观察")

    unused = {k: v for k, v in handlers.items() if v["calls"] == 0}
    return {
        "total_skills": len(handlers),
        "active_skills": len(active),
        "unused_skills": len(unused),
        "suggestions": suggestions[:5],
        "unused": list(unused.keys())[:5],
    }


# ============================================================
# 自进化循环
# ============================================================
class EvolutionLoop:
    """每N次调用后自动评估"""

    def __init__(self, interval: int = 10):
        self.interval = interval
        self.count = 0

    def tick(self):
        self.count += 1
        if self.count >= self.interval:
            self.count = 0
            return self._evolve()
        return None

    def _evolve(self):
        compute = get_compute()
        mem = get_memory()
        handlers = compute.registry.list()
        used = [h for h in handlers if h["calls"] > 0]
        unused = [h["name"] for h in handlers if h["calls"] == 0]

        # 存一条记忆
        mem.store(
            content=f"自进化检查: {len(used)}个活跃技能, {len(unused)}个未使用",
            source="evolution",
            domain="系统",
        )
        log.info(f"🔄 自进化: {len(used)}活跃 / {len(unused)}未用")
        return {"active": len(used), "unused": unused}


# ============================================================
# 主入口
# ============================================================
def start_brain():
    """启动星辰大脑"""
    compute = get_compute()
    mem = get_memory()

    log.info("=" * 50)
    log.info("🔱 星辰大脑 v5.0 已上线")
    log.info(f"   处理器: {len(compute.registry.list())}个")
    log.info(f"   记忆库: {mem.stats()['total']}条")
    log.info(f"   八宿域: {len(DOMAINS)}个")
    log.info("=" * 50)

    # 自进化循环
    evo = EvolutionLoop(interval=10)

    # 启动收集协程
    def collect_loop():
        while True:
            results = compute.collect()
            for r in results:
                mem.store(
                    content=f"完成任务 {r.get('task_id', '?')}: {r.get('result', {})}",
                    source="task_result",
                )
            evo.tick()
            time.sleep(0.5)

    t = threading.Thread(target=collect_loop, daemon=True)
    t.start()

    return compute


# 模块导入时自动启动
if __name__ != "__main__":
    # 被import时静默初始化
    pass

if __name__ == "__main__":
    start_brain()
    try:
        while True:
            time.sleep(10)
    except KeyboardInterrupt:
        log.info("🛑 停止")
