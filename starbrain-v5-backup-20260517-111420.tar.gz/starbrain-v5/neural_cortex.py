"""
星辰大脑 v5.0 - 神经皮层 (类脑网络)
向量记忆 + 主动学习 + API推理皮层
"""
import os, sys, json, time, logging, threading, hashlib, re
from typing import Optional

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

log = logging.getLogger('NeuralCortex')


# ============================================================
# 向量记忆 (ChromaDB)
# ============================================================
class VectorMemory:
    """向量记忆皮层"""

    def __init__(self):
        persist_dir = os.path.join(BASE, "data", "vector_store")
        os.makedirs(persist_dir, exist_ok=True)
        self._initialized = False

    def init(self):
        import chromadb
        persist_dir = os.path.join(BASE, "data", "vector_store")
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.collections = {}
        self._initialized = True
        log.info(f"🧠 向量记忆已初始化: {persist_dir}")

    def _get_collection(self, domain: str = "通用"):
        if not self._initialized:
            self.init()
        if domain not in self.collections:
            raw = re.sub(r'[^a-zA-Z0-9_-]', '_', domain)
            safe_name = raw.strip('_')[:60] or 'general_kb'
            if len(safe_name) < 3:
                safe_name = 'kb_' + safe_name
            try:
                self.collections[domain] = self.client.get_collection(safe_name)
            except:
                self.collections[domain] = self.client.create_collection(safe_name)
        return self.collections[domain]

    def store(self, content: str, metadata: dict = None, domain: str = "通用"):
        """存一条记忆（自动向量化）"""
        if not self._initialized:
            self.init()
        col = self._get_collection(domain)
        doc_id = hashlib.md5(content.encode()).hexdigest()[:16]
        meta = {"source": "neural", "time": time.time(), "domain": domain}
        if metadata:
            meta.update(metadata)
        try:
            col.add(documents=[content], metadatas=[meta], ids=[doc_id])
            return doc_id
        except Exception as e:
            # 跳过id重复
            log.debug(f"向量存储跳过: {e}")
            return doc_id

    def search(self, query: str, domain: str = None, limit: int = 5) -> list:
        """语义搜索"""
        if not self._initialized:
            self.init()
        domains = [domain] if domain else list(self.collections.keys()) or ["通用"]
        results = []
        for d in domains:
            col = self._get_collection(d)
            try:
                r = col.query(query_texts=[query], n_results=limit)
                for i, doc in enumerate(r.get("documents", [[]])[0]):
                    results.append({
                        "content": doc[:200],
                        "domain": d,
                        "score": r.get("distances", [[]])[0][i] if r.get("distances") else 0,
                    })
            except:
                pass
            if len(results) >= limit:
                    break
        results.sort(key=lambda x: x["score"])
        return results[:limit]

    def stats(self) -> dict:
        if not self._initialized:
            return {"total": 0, "collections": {}}
        cols = {}
        total = 0
        for name, col in self.collections.items():
            try:
                c = col.count()
                cols[name] = c
                total += c
            except:
                pass
        return {"total": total, "collections": cols}


# ============================================================
# API推理皮层 (GitHub Models / Gemini)
# ============================================================
class NeuralInference:
    """神经网络推理皮层 — 调用免费API做实时推理"""

    def __init__(self):
        # GitHub Models Token (来自TOOLS.md)
        self.gh_token = "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"
        # Gemini API Key
        self.gemini_key = "AIzaSyDiu56VV24fj-QwxBthiSXpIGZ33EK9Lbk"
        self.cache = {}
        self.calls = 0

    def reason(self, prompt: str, context: str = "", temperature: float = 0.3) -> str:
        """推理皮层调用"""
        self.calls += 1
        cache_key = hashlib.md5((prompt + context[:100]).encode()).hexdigest()

        if cache_key in self.cache:
            return self.cache[cache_key]

        full_prompt = f"{context}\n\n---\n\n{prompt}" if context else prompt

        result = self._call_github(full_prompt, temperature)
        self.cache[cache_key] = result
        if len(self.cache) > 200:
            self.cache.clear()
        return result

    def _call_github(self, prompt: str, temperature: float) -> str:
        """调用 GitHub Models API (免费)"""
        import urllib.request, urllib.error
        data = json.dumps({
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": 500,
        }).encode()
        req = urllib.request.Request(
            "https://models.inference.ai.azure.com/chat/completions",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.gh_token}",
            },
        )
        try:
            resp = urllib.request.urlopen(req, timeout=15)
            result = json.loads(resp.read())
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            log.warning(f"GitHub模型失败: {e}")
            return self._call_gemini(prompt, temperature)

    def _call_gemini(self, prompt: str, temperature: float) -> str:
        """备用: Gemini API"""
        import urllib.request, urllib.parse
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={self.gemini_key}"
        data = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": temperature, "maxOutputTokens": 500},
        }).encode()
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(req, timeout=15)
            result = json.loads(resp.read())
            return result["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e:
            return f"[推理失败: {e}]"


# ============================================================
# 主动学习回路
# ============================================================
class ActiveLearning:
    """主动学习 — 发现盲区→搜索→学习→内化"""

    def __init__(self, vector_memory: VectorMemory, inference: NeuralInference):
        self.vm = vector_memory
        self.inference = inference
        self.learned_topics = set()
        self.cycle_count = 0

    def learn(self, topic: str):
        """主动学习一个主题"""
        if topic in self.learned_topics:
            log.info(f"  ↺ 跳过已学: {topic}")
            return

        log.info(f"  📖 学习: {topic}")
        self.cycle_count += 1

        # 1. 用推理皮层生成知识摘要
        knowledge = self.inference.reason(
            f"请简要总结关于「{topic}」的核心知识要点，适合AI智能体学习。"
        )

        # 2. 存到向量记忆
        self.vm.store(
            content=f"[主动学习] {topic}: {knowledge}",
            metadata={"topic": topic, "cycle": self.cycle_count},
            domain="知识"
        )

        # 3. 标记已学
        self.learned_topics.add(topic)

        log.info(f"  ✅ 已完成主题 [{self.cycle_count}]: {topic}")
        return {"topic": topic, "summary": knowledge[:100]}

    def discover_gaps(self, query: str) -> list:
        """发现知识盲区"""
        # 搜索现有记忆
        existing = self.vm.search(query, domain="知识")
        existing_topics = set()
        for r in existing:
            meta = r.get("content", "")
            # 提取主题
            import re
            m = re.search(r'\[主动学习\] (.+?):', meta)
            if m:
                existing_topics.add(m.group(1))

        # 用推理皮层发现需要补充的知识
        gaps_prompt = (
            f"基于'{query}'这个主题，列出3个相关的知识子主题，"
            f"最好是当前缺乏的、有价值的方向。只需列出名称，每个一行。"
        )
        gap_result = self.inference.reason(gaps_prompt, temperature=0.5)
        gaps = [g.strip("•-*0123456789. ") for g in gap_result.strip().split("\n") if g.strip()]

        return [g for g in gaps if g not in existing_topics][:3]

    def auto_learn_cycle(self, seed_topics: list):
        """自动学习循环：给一批初始主题→自动发现→自动学习"""
        for topic in seed_topics:
            self.learn(topic)
            gaps = self.discover_gaps(topic)
            for gap in gaps:
                self.learn(gap)

    def stats(self):
        return {
            "learned": len(self.learned_topics),
            "cycles": self.cycle_count,
            "recent": list(self.learned_topics)[-5:],
        }


# ============================================================
# 全局实例
# ============================================================
_vector_memory = None
_inference = None
_active_learning = None


def get_vector_memory() -> VectorMemory:
    global _vector_memory
    if _vector_memory is None:
        _vector_memory = VectorMemory()
    return _vector_memory


def get_inference() -> NeuralInference:
    global _inference
    if _inference is None:
        _inference = NeuralInference()
    return _inference


def get_active_learning() -> ActiveLearning:
    global _active_learning
    if _active_learning is None:
        vm = get_vector_memory()
        inf = get_inference()
        _active_learning = ActiveLearning(vm, inf)
    return _active_learning
