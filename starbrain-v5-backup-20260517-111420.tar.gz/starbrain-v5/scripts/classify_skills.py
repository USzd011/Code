#!/usr/bin/env python3
"""
二十八宿技能分类脚本
将430个技能按业务域分类到8个宿域
"""

import os
import re
from pathlib import Path

# 宿域关键词映射
DOMAIN_KEYWORDS = {
    "宿1-抖音商品": ["抖音", "douyin", "商品", "选品", "爆款", "带货", "tiktok"],
    "宿2-快手商品": ["快手", "kuaishou", "小店", "快手小店"],
    "宿3-头条内容": ["头条", "toutiao", "文章", "内容", "写作", "自媒体"],
    "宿4-达人资源": ["达人", "talent", "KOL", "网红", "博主", "influencer"],
    "宿5-用户画像": ["用户", "画像", "profile", "人群", "受众", "customer"],
    "宿6-竞品分析": ["竞品", "competitor", "竞争", "对手", "benchmark"],
    "宿7-趋势预测": ["趋势", "trend", "预测", "forecast", "预测", "趋势分析"],
    "宿8-风险控制": ["风险", "risk", "合规", "compliance", "风控", "审核"],
}

def classify_skill(skill_name: str, skill_content: str = None) -> str:
    """分类技能到宿域"""
    text = skill_name.lower()
    if skill_content:
        text += " " + skill_content.lower()
    
    # 按关键词匹配
    for domain, keywords in DOMAIN_KEYWORDS.items():
        for keyword in keywords:
            if keyword.lower() in text:
                return domain
    
    return "通用技能"

def main():
    skills_dir = Path("/root/.openclaw/workspace/skills")
    
    # 统计
    stats = {domain: 0 for domain in DOMAIN_KEYWORDS.keys()}
    stats["通用技能"] = 0
    
    classified = []
    
    # 遍历所有技能目录
    for skill_dir in skills_dir.iterdir():
        if not skill_dir.is_dir():
            continue
        
        skill_name = skill_dir.name
        
        # 跳过宿域目录
        if skill_name.startswith("宿"):
            continue
        
        # 读取SKILL.md内容
        skill_file = skill_dir / "SKILL.md"
        content = ""
        if skill_file.exists():
            content = skill_file.read_text(encoding="utf-8", errors="ignore")
        
        # 分类
        domain = classify_skill(skill_name, content)
        stats[domain] += 1
        
        classified.append({
            "name": skill_name,
            "domain": domain,
            "path": str(skill_dir)
        })
    
    # 输出统计
    print("=== 技能分类统计 ===")
    for domain, count in stats.items():
        print(f"{domain}: {count}个")
    
    print(f"\n总计: {sum(stats.values())}个技能")
    
    # 保存分类结果
    output_file = skills_dir / "技能分类结果.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("# 技能分类结果\n\n")
        f.write("== 统计 ==\n")
        for domain, count in stats.items():
            f.write(f"{domain}: {count}个\n")
        f.write(f"\n总计: {sum(stats.values())}个\n\n")
        f.write("== 详细列表 ==\n\n")
        
        for domain in list(stats.keys()):
            f.write(f"\n### {domain}\n")
            for item in classified:
                if item["domain"] == domain:
                    f.write(f"- {item['name']}\n")
    
    print(f"\n分类结果已保存到: {output_file}")

if __name__ == "__main__":
    main()
