#!/bin/bash
# 自动化内容流水线启动脚本 V1.0
# 用法: ./start.sh [start|stop|restart|status]

PIPELINE_DIR="/root/.openclaw/workspace/auto-content-pipeline"
PID_FILE="$PIPELINE_DIR/pipeline.pid"
LOG_FILE="$PIPELINE_DIR/logs/$(date +%Y%m%d).log"

start() {
    if pgrep -f "pipeline.py" > /dev/null; then
        echo "✅ 已在运行 (PID: $(cat $PID_FILE))"
        return 0
    fi
    echo "🚀 启动自动化内容流水线..."
    nohup python3 "$PIPELINE_DIR/pipeline.py" >> "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    echo "✅ 已启动，PID: $(cat $PID_FILE)"
}

stop() {
    if ! pgrep -f "pipeline.py" > /dev/null; then
        echo "❌ 未运行"
        rm -f "$PID_FILE"
        return 0
    fi
    kill $(cat "$PID_FILE") && echo "✅ 已停止"
    rm -f "$PID_FILE"
}

status() {
    if pgrep -f "pipeline.py" > /dev/null; then
        echo "✅ 运行中 (PID: $(cat $PID_FILE))"
        curl -s http://127.0.0.1:8000/health | python3 -m json.tool
    else
        echo "❌ 未运行"
    fi
}

case "$1" in
    start) start ;;
    stop) stop ;;
    restart) stop; sleep 1; start ;;
    status) status ;;
    *) echo "用法: $0 {start|stop|restart|status}"; exit 1 ;;
esac
