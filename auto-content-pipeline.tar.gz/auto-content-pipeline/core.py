"""
热点采集 → AI创作 → 视频生成 → 多平台发布
完整版自动化内容流水线 V1.1
"""
import os, json, time, hashlib, logging, asyncio, aiohttp, sqlite3, requests
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass

# ========== 配置 ==========
BASE_DIR = Path("/root/.openclaw/workspace/auto-content-pipeline")
DB_PATH = BASE_DIR / "data" / "content.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# 模型配置（优先使用免费/低成本）
MODELS = {
    "chat": "qwen/Qwen-7B-Chat",      # 阿里通义千问
    "image": "qwen/Qwen-Image-2512",   # 文生图
    "video": "ZhipuAI/CogVideoX-5b",   # 智谱视频生成
}

# 平台配置（需用户自行填写AppID/Secret）
PLATFORMS = {
    "douyin": {"name": "抖音", "app_id": "", "secret": "", "note": "需在抖音开放平台申请"},
    "jianshu": {"name": "小红书", "cookie": "", "note": "需登录后获取Cookie"},
    "toutiao": {"name": "今日头条", "access_key": "", "note": "需在头条开发者平台申请"},
}

# ========== 数据库初始化 ==========
def init_db():
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS topics
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         title TEXT, content TEXT, status TEXT,
         platform TEXT, created_at TIMESTAMP, updated_at TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS videos
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         title TEXT, file_path TEXT, duration INTEGER,
         status TEXT, created_at TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS publish_logs
        (id INTEGER PRIMARY KEY AUTOINCREMENT,
         content_id INTEGER, platform TEXT, status TEXT,
         note TEXT, created_at TIMESTAMP)''')
    conn.commit()
    conn.close()

init_db()

# ========== 日志 ==========
logger = logging.getLogger("pipeline")
logger.setLevel(logging.INFO)
handler = logging.FileHandler(BASE_DIR / "logs" / f"pipeline_{datetime.now().strftime('%Y%m%d')}.log")
handler.setFormatter(logging.%(asctime)s | %(levelname)s | %(message)s)
logger.addHandler(handler)
